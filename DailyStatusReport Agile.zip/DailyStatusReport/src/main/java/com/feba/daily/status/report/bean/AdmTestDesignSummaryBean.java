package com.feba.daily.status.report.bean;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class AdmTestDesignSummaryBean
{

	private long id;
	
	private String smtDirect;
	
	private String rag;
	
	private String applicationTrackType;
	
	private long total;
	
	private long inProgress;
	
	private long onHold;
	
	private long completed;
	
	private long severity1;
	
	private long severity2;
	
	private long severity3;
	
	private long severity4;
	
	private long totalSeverity;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date insertedDate;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date modifiedDate;
	
	private boolean isEnabled;
	
	private boolean isDeleted;
	
	public long getId()
	{
		return id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	public String getSmtDirect()
	{
		return smtDirect;
	}

	public void setSmtDirect(String smtDirect)
	{
		this.smtDirect = smtDirect;
	}

	public String getRag()
	{
		return rag;
	}

	public void setRag(String rag)
	{
		this.rag = rag;
	}

	public String getApplicationTrackType()
	{
		return applicationTrackType;
	}

	public void setApplicationTrackType(String applicationTrackType)
	{
		this.applicationTrackType = applicationTrackType;
	}

	public long getTotal()
	{
		return total;
	}

	public void setTotal(long total)
	{
		this.total = total;
	}

	public long getInProgress()
	{
		return inProgress;
	}

	public void setInProgress(long inProgress)
	{
		this.inProgress = inProgress;
	}

	public long getOnHold()
	{
		return onHold;
	}

	public void setOnHold(long onHold)
	{
		this.onHold = onHold;
	}

	public long getCompleted()
	{
		return completed;
	}

	public void setCompleted(long completed)
	{
		this.completed = completed;
	}

	public long getSeverity1()
	{
		return severity1;
	}

	public void setSeverity1(long severity1)
	{
		this.severity1 = severity1;
	}

	public long getSeverity2()
	{
		return severity2;
	}

	public void setSeverity2(long severity2)
	{
		this.severity2 = severity2;
	}

	public long getSeverity3()
	{
		return severity3;
	}

	public void setSeverity3(long severity3)
	{
		this.severity3 = severity3;
	}

	public long getSeverity4()
	{
		return severity4;
	}

	public void setSeverity4(long severity4)
	{
		this.severity4 = severity4;
	}

	public long getTotalSeverity()
	{
		return totalSeverity;
	}

	public void setTotalSeverity(long totalSeverity)
	{
		this.totalSeverity = totalSeverity;
	}

	public Date getInsertedDate()
	{
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate)
	{
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate()
	{
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate)
	{
		this.modifiedDate = modifiedDate;
	}

	public boolean isEnabled()
	{
		return isEnabled;
	}

	public void setEnabled(boolean isEnabled)
	{
		this.isEnabled = isEnabled;
	}

	public boolean isDeleted()
	{
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted)
	{
		this.isDeleted = isDeleted;
	}
}
