package com.feba.daily.status.report.persistance;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="GIW_DAILY_STATUS_REPORT", uniqueConstraints = { @UniqueConstraint( columnNames = { "REPORT_DATE", "LOBS" } )})
public class GIWDailyStatusReport 
{
	@Id
	@GeneratedValue
	@Column(name = "GIW_DAILY_STS_RPT_ID")
	private long id;
	
	@Column(name = "GO_LIVE_DATE_1")
	@Temporal(TemporalType.DATE)
	private Date goLiveDate1;
	
	@Column(name = "GO_LIVE_DATE_2")
	@Temporal(TemporalType.DATE)
	private Date goLiveDate2;
	
	@Column(name = "GO_LIVE_DATE_3")
	@Temporal(TemporalType.DATE)
	private Date goLiveDate3;
	
	@Column(name = "GO_LIVE_DATE_4")
	@Temporal(TemporalType.DATE)
	private Date goLiveDate4;
		 
	@Column(name = "EXECUTION_COMPLETION_1")
	private double executionCompletion1;
	
	@Column(name = "EXECUTION_COMPLETION_2")
	private double executionCompletion2;
	
	@Column(name = "EXECUTION_COMPLETION_3")
	private double executionCompletion3;
	
	@Column(name = "EXECUTION_COMPLETION_4")
	private double executionCompletion4;
	
	@Column(name = "GIW_RAG_1")
	private String giwRag1;
	
	@Column(name = "GIW_RAG_2")
	private String giwRag2;
	
	@Column(name = "GIW_RAG_3")
	private String giwRag3;
	
	@Column(name = "GIW_RAG_4")
	private String giwRag4;
	
	@Column(name = "GIW_OVR_ALL_PT_COMLTION_STS1")
	private String giwOverAllPtCompletionStatus1;
	
	@Column(name = "GIW_OVR_ALL_PT_COMLTION_STS2")
	private String giwOverAllPtCompletionStatus2;
	
	@Column(name = "GIW_OVR_ALL_PT_COMLTION_STS3")
	private String giwOverAllPtCompletionStatus3;
	
	@Column(name = "GIW_OVR_ALL_PT_COMLTION_STS4")
	private String giwOverAllPtCompletionStatus4;
	
	@Column(name = "INSERTED_DATE", updatable=false)
	@Temporal(TemporalType.DATE)
	private Date insertedDate;
	
	@Column(name = "MODIFIED_DATE")
	@Temporal(TemporalType.DATE)
	private Date modifiedDate;
	
	@Column(name = "REPORT_DATE", updatable=false)
	@Temporal(TemporalType.DATE)
	private Date reportDate;
	
	@Column(name = "LOBS")
	private String loB;
	
	@Column(name = "PROJECT_RELEASE")
	private String projectRelease;
	
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="FK_GIW_EXEC_SMRY_RPT_ID")
	private Set<GIWExecutionSummary> giwExecutionSummaries;
	
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="FK_GIW_RAID_LOG_RPT_ID")
	private Set<GiwRaidLog> giwRaidLogs;
	
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_GIW_TEST_DEFECT_SMRY_ID")
	private Set<GiwTestDefectSummary> giwtestDefectSummaries;
	

	public long getId()
	{
		return id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	
	public Date getGoLiveDate1()
	{
		return goLiveDate1;
	}

	public void setGoLiveDate1(Date goLiveDate1)
	{
		this.goLiveDate1 = goLiveDate1;
	}

	public Date getGoLiveDate2()
	{
		return goLiveDate2;
	}

	public void setGoLiveDate2(Date goLiveDate2)
	{
		this.goLiveDate2 = goLiveDate2;
	}

	public Date getGoLiveDate3()
	{
		return goLiveDate3;
	}

	public void setGoLiveDate3(Date goLiveDate3)
	{
		this.goLiveDate3 = goLiveDate3;
	}

	public Date getGoLiveDate4()
	{
		return goLiveDate4;
	}

	public void setGoLiveDate4(Date goLiveDate4)
	{
		this.goLiveDate4 = goLiveDate4;
	}

	public double getExecutionCompletion1()
	{
		return executionCompletion1;
	}

	public void setExecutionCompletion1(double executionCompletion1)
	{
		this.executionCompletion1 = executionCompletion1;
	}

	public double getExecutionCompletion2()
	{
		return executionCompletion2;
	}

	public void setExecutionCompletion2(double executionCompletion2)
	{
		this.executionCompletion2 = executionCompletion2;
	}

	public double getExecutionCompletion3()
	{
		return executionCompletion3;
	}

	public void setExecutionCompletion3(double executionCompletion3)
	{
		this.executionCompletion3 = executionCompletion3;
	}

	public double getExecutionCompletion4()
	{
		return executionCompletion4;
	}

	public void setExecutionCompletion4(double executionCompletion4)
	{
		this.executionCompletion4 = executionCompletion4;
	}

	public String getGiwRag1()
	{
		return giwRag1;
	}

	public void setGiwRag1(String giwRag1)
	{
		this.giwRag1 = giwRag1;
	}

	public String getGiwRag2()
	{
		return giwRag2;
	}

	public void setGiwRag2(String giwRag2)
	{
		this.giwRag2 = giwRag2;
	}

	public String getGiwRag3()
	{
		return giwRag3;
	}

	public void setGiwRag3(String giwRag3)
	{
		this.giwRag3 = giwRag3;
	}

	public String getGiwRag4()
	{
		return giwRag4;
	}

	public void setGiwRag4(String giwRag4)
	{
		this.giwRag4 = giwRag4;
	}

	public String getGiwOverAllPtCompletionStatus1()
	{
		return giwOverAllPtCompletionStatus1;
	}

	public void setGiwOverAllPtCompletionStatus1(String giwOverAllPtCompletionStatus1)
	{
		this.giwOverAllPtCompletionStatus1 = giwOverAllPtCompletionStatus1;
	}

	public String getGiwOverAllPtCompletionStatus2()
	{
		return giwOverAllPtCompletionStatus2;
	}

	public void setGiwOverAllPtCompletionStatus2(String giwOverAllPtCompletionStatus2)
	{
		this.giwOverAllPtCompletionStatus2 = giwOverAllPtCompletionStatus2;
	}

	public String getGiwOverAllPtCompletionStatus3()
	{
		return giwOverAllPtCompletionStatus3;
	}

	public void setGiwOverAllPtCompletionStatus3(String giwOverAllPtCompletionStatus3)
	{
		this.giwOverAllPtCompletionStatus3 = giwOverAllPtCompletionStatus3;
	}

	public String getGiwOverAllPtCompletionStatus4()
	{
		return giwOverAllPtCompletionStatus4;
	}

	public void setGiwOverAllPtCompletionStatus4(String giwOverAllPtCompletionStatus4)
	{
		this.giwOverAllPtCompletionStatus4 = giwOverAllPtCompletionStatus4;
	}

	public Date getInsertedDate()
	{
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate)
	{
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate()
	{
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate)
	{
		this.modifiedDate = modifiedDate;
	}

	public Date getReportDate()
	{
		return reportDate;
	}

	public void setReportDate(Date reportDate)
	{
		this.reportDate = reportDate;
	}

	public String getLoB()
	{
		return loB;
	}

	public void setLoB(String loB)
	{
		this.loB = loB;
	}

	public String getProjectRelease()
	{
		return projectRelease;
	}

	public void setProjectRelease(String projectRelease)
	{
		this.projectRelease = projectRelease;
	}

	public Set<GIWExecutionSummary> getGiwExecutionSummaries()
	{
		return giwExecutionSummaries;
	}

	public void setGiwExecutionSummaries(Set<GIWExecutionSummary> giwExecutionSummaries)
	{
		this.giwExecutionSummaries = giwExecutionSummaries;
	}

	public Set<GiwRaidLog> getGiwRaidLogs()
	{
		return giwRaidLogs;
	}

	public void setGiwRaidLogs(Set<GiwRaidLog> giwRaidLogs)
	{
		this.giwRaidLogs = giwRaidLogs;
	}

		public Set<GiwTestDefectSummary> getGiwtestDefectSummaries()
	{
		return giwtestDefectSummaries;
	}

	public void setGiwtestDefectSummaries(Set<GiwTestDefectSummary> giwtestDefectSummaries)
	{
		this.giwtestDefectSummaries = giwtestDefectSummaries;
	}

	
	
}
