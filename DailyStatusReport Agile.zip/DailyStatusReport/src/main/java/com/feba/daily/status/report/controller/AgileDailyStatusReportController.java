package com.feba.daily.status.report.controller;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.feba.daily.status.report.bean.AdmRaidLogBean;
import com.feba.daily.status.report.bean.AdmTestDesignSummaryBean;
import com.feba.daily.status.report.bean.AdmTestExecutionSummaryBean;
import com.feba.daily.status.report.bean.DailyStatusReportBean;
import com.feba.daily.status.report.bean.RtsTestDesignSummaryBean;
import com.feba.daily.status.report.bean.RtsTestExecutionSummaryBean;
import com.feba.daily.status.report.service.CommonService;
import com.feba.daily.status.report.util.DailyStatusReportUtil;
import com.feba.daily.status.report.util.DropDownMenu;
import com.feba.daily.status.report.validator.InputValidator;


@Controller
public class AgileDailyStatusReportController 
{
	final static Logger logger = Logger.getLogger(AgileDailyStatusReportController.class);
		
	@Autowired
	CommonService commonService;
	
	@Autowired(required=true)
	InputValidator inputValidator;
	
	boolean isFirstTimeSearch = false;
	
	public AgileDailyStatusReportController()
	{
		BasicConfigurator.configure();
	}
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(inputValidator);
	}
	
	@RequestMapping(value = "/agileInput.html", method = RequestMethod.GET)
	public ModelAndView loadAgileDailyStatusReportNFT(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean)
	{
		logger.debug("loadAgileDailyStatusReportNFT() - START");
		DropDownMenu dropDownMenu = new DropDownMenu();
		ModelAndView modelAndView = new ModelAndView("agileInput");
		dailyStatusReportBean.setReportDate(new Date());
		String todayDate = DailyStatusReportUtil.getDateToStringDate(new Date(), "MM/dd/yyyy");
		modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
		modelAndView.addObject("todayDate", todayDate);
		logger.debug("loadAgileDailyStatusReportNFT() - END");
		return modelAndView;
	}
	
	@RequestMapping(value = "/submitAgileDailyStatusReport.html", method = RequestMethod.POST)
	public ModelAndView submitAgileDailyStatusReportNFT(@ModelAttribute("userForm") @Validated DailyStatusReportBean dailyStatusReportBean, 
			BindingResult result, Model model, final RedirectAttributes redirectAttributes, HttpServletRequest request)
	{
		logger.debug("submitAgileDailyStatusReportNFT() - START");
		ModelAndView modelAndView = null;
		if (result.hasErrors()) 
		{
			DropDownMenu dropDownMenu = new DropDownMenu();
			modelAndView = new ModelAndView("input");
			modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
		} 
		else 
		{
			try
			{
				List<AdmRaidLogBean> admRaidLogBeanList = new LinkedList<AdmRaidLogBean>();
				List<AdmTestExecutionSummaryBean> admTestExecutionSummaryBeansList = new LinkedList<AdmTestExecutionSummaryBean>();
				List<AdmTestDesignSummaryBean> admTestDesignSummaryBeansList = new LinkedList<AdmTestDesignSummaryBean>();
				List<RtsTestDesignSummaryBean> rtsTestDesignSummaryBeansList = new LinkedList<RtsTestDesignSummaryBean>();
				List<RtsTestExecutionSummaryBean> rtsTestExecutionSummaryBeansList = new LinkedList<RtsTestExecutionSummaryBean>();
				
				AdmRaidLogBean admRaidLogBean = null;
				AdmTestDesignSummaryBean admTestDesignSummaryBean = null;
				AdmTestExecutionSummaryBean admTestExecutionSummaryBean = null;
				RtsTestDesignSummaryBean rtsTestDesignSummaryBean = null;
				RtsTestExecutionSummaryBean rtsTestExecutionSummaryBean = null;
				
				if(request.getParameter("rowCount") != null && !"".equals(request.getParameter("rowCount")) && request.getParameter("rowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("rowCount"));
					System.out.println("Row Count Value "+rowCount);
					logger.debug("Row Count Value "+rowCount);
					for(int i = 1; i <= rowCount; i++)
					{
						System.out.println("Type Value : "+request.getParameter("type"+i));
						logger.debug("Type Value : "+request.getParameter("type"+i));
						admRaidLogBean = new AdmRaidLogBean();
						admRaidLogBean.setType(request.getParameter("type"+i));
						admRaidLogBean.setScrum(request.getParameter("scrum"+i));
						admRaidLogBean.setScrumManager(request.getParameter("scrumManager"+i));
						admRaidLogBean.setImpactedApp(request.getParameter("impactedApp"+i));
						admRaidLogBean.setIssueOwner(request.getParameter("issueOwner"+i));
						admRaidLogBean.setPriority(request.getParameter("priority"+i));
						admRaidLogBean.setDescription(request.getParameter("description"+i));
						admRaidLogBean.setStatus(request.getParameter("status"+i));
						admRaidLogBean.setPortfolioManager(request.getParameter("portfolioManager"+i));
						admRaidLogBean.setRadiOwner(request.getParameter("radiOwner"+i));
						admRaidLogBean.setRag(request.getParameter("rag"+i));
						logger.debug("Logged Date : "+request.getParameter("dateLogged"+i));
						Date loggedDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("dateLogged"+i));
						admRaidLogBean.setDateLogged(loggedDate);
						Date targetClosureDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("targetClosureDate"+i));
						admRaidLogBean.setTargetClosureDate(targetClosureDate);
						admRaidLogBean.setAge(request.getParameter("age"+i));
						admRaidLogBean.setMileStoneImpacted(request.getParameter("mileStoneImpacted"+i));
						admRaidLogBean.setRaidBackToGreenPlan(request.getParameter("raidBackToGreenPlan"+i));
						admRaidLogBeanList.add(admRaidLogBean);
					}
					dailyStatusReportBean.setAdmRaidLogBeanList(admRaidLogBeanList);
				}
				
				if(request.getParameter("admTestDesignSummaryRowCount") != null && !"".equals(request.getParameter("admTestDesignSummaryRowCount")) && request.getParameter("admTestDesignSummaryRowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("admTestDesignSummaryRowCount"));
					for(int i = 1; i <= rowCount; i++)
					{
						admTestDesignSummaryBean = new AdmTestDesignSummaryBean();
						admTestDesignSummaryBean.setSmtDirect((request.getParameter("admTdsSmtDirect"+i) == null ) ? "NA" : request.getParameter("admTdsSmtDirect"+i));
						admTestDesignSummaryBean.setRag((request.getParameter("admTdsRag"+i) == null ) ? "NA" : request.getParameter("admTdsRag"+i));
						admTestDesignSummaryBean.setTotal((request.getParameter("admTdsTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsTotal"+i)));
						admTestDesignSummaryBean.setInProgress((request.getParameter("admTdsInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsInProgress"+i)));
						admTestDesignSummaryBean.setOnHold((request.getParameter("admTdsOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsOnHold"+i)));
						admTestDesignSummaryBean.setCompleted((request.getParameter("admTdsCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsCompleted"+i)));						
						admTestDesignSummaryBean.setSeverity1((request.getParameter("admTdsSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev1"+i)));
						admTestDesignSummaryBean.setSeverity2((request.getParameter("admTdsSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev2"+i)));
						admTestDesignSummaryBean.setSeverity3((request.getParameter("admTdsSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev3"+i)));
						admTestDesignSummaryBean.setSeverity4((request.getParameter("admTdsSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev4"+i)));
						admTestDesignSummaryBean.setTotalSeverity((request.getParameter("admTdsTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsTotalSeverity"+i)));
						
						admTestDesignSummaryBeansList.add(admTestDesignSummaryBean);
					}
					dailyStatusReportBean.setAdmTestDesignSummaryList(admTestDesignSummaryBeansList);
				}
				
				if(request.getParameter("admTestExectuionSummaryRowCount") != null && !"".equals(request.getParameter("admTestExectuionSummaryRowCount")) && request.getParameter("admTestExectuionSummaryRowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("admTestExectuionSummaryRowCount"));
					for(int i = 1; i <= rowCount; i++)
					{
						admTestExecutionSummaryBean = new AdmTestExecutionSummaryBean();
						admTestExecutionSummaryBean.setSmtDirect((request.getParameter("admTesSmtDirect"+i) == null ) ? "NA" : request.getParameter("admTesSmtDirect"+i));
						admTestExecutionSummaryBean.setRag((request.getParameter("admTesRag"+i) == null ) ? "NA" : request.getParameter("admTesRag"+i));
						admTestExecutionSummaryBean.setTotal((request.getParameter("admTesTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesTotal"+i)));
						admTestExecutionSummaryBean.setInProgress((request.getParameter("admTesInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesInProgress"+i)));
						admTestExecutionSummaryBean.setOnHold((request.getParameter("admTesOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesOnHold"+i)));
						admTestExecutionSummaryBean.setCompleted((request.getParameter("admTesCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesCompleted"+i)));						
						admTestExecutionSummaryBean.setSeverity1((request.getParameter("admTesSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev1"+i)));
						admTestExecutionSummaryBean.setSeverity2((request.getParameter("admTesSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev2"+i)));
						admTestExecutionSummaryBean.setSeverity3((request.getParameter("admTesSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev3"+i)));
						admTestExecutionSummaryBean.setSeverity4((request.getParameter("admTesSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev4"+i)));
						admTestExecutionSummaryBean.setTotalSeverity((request.getParameter("admTesTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesTotalSeverity"+i)));
												
						admTestExecutionSummaryBeansList.add(admTestExecutionSummaryBean);
					}
					dailyStatusReportBean.setAdmTestExecutionSummaryList(admTestExecutionSummaryBeansList);
				}
				//RTS
				if(request.getParameter("rtsTestDesignSummaryRowCount") != null && !"".equals(request.getParameter("rtsTestDesignSummaryRowCount")) && request.getParameter("rtsTestDesignSummaryRowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("rtsTestDesignSummaryRowCount"));
					for(int i = 1; i <= rowCount; i++)
					{
						rtsTestDesignSummaryBean = new RtsTestDesignSummaryBean();
						rtsTestDesignSummaryBean.setSmtDirect((request.getParameter("rtsTdsSmtDirect"+i) == null ) ? "NA" : request.getParameter("rtsTdsSmtDirect"+i));
						rtsTestDesignSummaryBean.setRag((request.getParameter("rtsTdsRag"+i) == null ) ? "NA" : request.getParameter("rtsTdsRag"+i));
						rtsTestDesignSummaryBean.setTotal((request.getParameter("rtsTdsTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsTotal"+i)));
						rtsTestDesignSummaryBean.setInProgress((request.getParameter("rtsTdsInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsInProgress"+i)));
						rtsTestDesignSummaryBean.setOnHold((request.getParameter("rtsTdsOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsOnHold"+i)));
						rtsTestDesignSummaryBean.setCompleted((request.getParameter("rtsTdsCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsCompleted"+i)));						
						rtsTestDesignSummaryBean.setSeverity1((request.getParameter("rtsTdsSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev1"+i)));
						rtsTestDesignSummaryBean.setSeverity2((request.getParameter("rtsTdsSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev2"+i)));
						rtsTestDesignSummaryBean.setSeverity3((request.getParameter("rtsTdsSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev3"+i)));
						rtsTestDesignSummaryBean.setSeverity4((request.getParameter("rtsTdsSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev4"+i)));
						rtsTestDesignSummaryBean.setTotalSeverity((request.getParameter("rtsTdsTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsTotalSeverity"+i)));
						
						rtsTestDesignSummaryBeansList.add(rtsTestDesignSummaryBean);
					}
					dailyStatusReportBean.setRtsTestDesignSummaryList(rtsTestDesignSummaryBeansList);
				}
				
				if(request.getParameter("rtsTestExectuionSummaryRowCount") != null && !"".equals(request.getParameter("rtsTestExectuionSummaryRowCount")) && request.getParameter("rtsTestExectuionSummaryRowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("rtsTestExectuionSummaryRowCount"));
					for(int i = 1; i <= rowCount; i++)
					{
						rtsTestExecutionSummaryBean = new RtsTestExecutionSummaryBean();
						rtsTestExecutionSummaryBean.setSmtDirect((request.getParameter("rtsTesSmtDirect"+i) == null ) ? "NA" : request.getParameter("rtsTesSmtDirect"+i));
						rtsTestExecutionSummaryBean.setRag((request.getParameter("rtsTesRag"+i) == null ) ? "NA" : request.getParameter("rtsTesRag"+i));
						rtsTestExecutionSummaryBean.setTotal((request.getParameter("rtsTesTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesTotal"+i)));
						rtsTestExecutionSummaryBean.setInProgress((request.getParameter("rtsTesInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesInProgress"+i)));
						rtsTestExecutionSummaryBean.setOnHold((request.getParameter("rtsTesOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesOnHold"+i)));
						rtsTestExecutionSummaryBean.setCompleted((request.getParameter("rtsTesCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesCompleted"+i)));						
						rtsTestExecutionSummaryBean.setSeverity1((request.getParameter("rtsTesSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev1"+i)));
						rtsTestExecutionSummaryBean.setSeverity2((request.getParameter("rtsTesSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev2"+i)));
						rtsTestExecutionSummaryBean.setSeverity3((request.getParameter("rtsTesSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev3"+i)));
						rtsTestExecutionSummaryBean.setSeverity4((request.getParameter("rtsTesSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev4"+i)));
						rtsTestExecutionSummaryBean.setTotalSeverity((request.getParameter("rtsTesTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesTotalSeverity"+i)));
												
						rtsTestExecutionSummaryBeansList.add(rtsTestExecutionSummaryBean);
					}
					dailyStatusReportBean.setRtsTestExecutionSummaryList(rtsTestExecutionSummaryBeansList);
				}
				modelAndView = new ModelAndView("agileInput");
				commonService.saveAgileDailStatusReport(dailyStatusReportBean);
				modelAndView.addObject("css", "success");
				modelAndView.addObject("msg", "Record inserted successfully!");
				
				logger.debug("submitDailyStatusReportNFT() - END");
			} catch (Exception e)
			{
				logger.error("Error Occured during saving data : ", e);
				modelAndView = new ModelAndView("input");
				modelAndView.addObject("css", "success");
				modelAndView.addObject("msg", "Duplicate Entry please insert uniqueu record!");
			}
			
		}
		return modelAndView;
	}
	
	
	/*@RequestMapping(value = "/agileDsrSearch.html", method = RequestMethod.GET)
	public ModelAndView agileDsrSearch(@ModelAttribute("searchForm") DailyStatusReportBean dailyStatusReportBean)
	{
		logger.debug("loadDailyStatusReportNFT() - START");
		
		ModelAndView modelAndView = new ModelAndView("search");
		isFirstTimeSearch = true;
		modelAndView.addObject("isFirstTimeSearch", isFirstTimeSearch);
		logger.debug("loadDailyStatusReportNFT() - END");
		return modelAndView;
	}
	
	@RequestMapping(value = "/loadAgileDsrUpdateDelete.html", method = RequestMethod.GET)
	public ModelAndView loadAgileDsrUpdateDelete(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("loadDailyStatusReportNFT() - START");
		ModelAndView modelAndView = new ModelAndView("updateDelete");
		try
		{
			String dateIn = request.getParameter("searchDate");
			String searchSdpId = request.getParameter("searchSdpId");
			Date searchDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", dateIn);
			this.searchDate = dateIn;
			this.searchSdpId = searchSdpId;
			
			List<DailyStatusReportNFT> dailyStatusReportNFTs;
			dailyStatusReportNFTs =  commonService.searchByInsertedDateAndSPDId(searchDate, searchSdpId);
			DailyStatusReportNFT dailyStatusReportNFT = dailyStatusReportNFTs.get(0);
			BeanUtils.copyProperties(dailyStatusReportNFT, dailyStatusReportBean);
			
			System.out.println("loadDailyStatusReportNFT Object Id : "+ dailyStatusReportBean.getId());
			
			Set<TestDesignSummary> testDesignSummariesSet = dailyStatusReportNFT.getTestDesignSummaries();
			Iterator<TestDesignSummary> testDesignSummariesIterator = testDesignSummariesSet.iterator();
			List<TestDesignSummary> testDesignSummaryList = new ArrayList<TestDesignSummary>();
			while(testDesignSummariesIterator.hasNext())
			{
				testDesignSummaryList.add(testDesignSummariesIterator.next());
			}
			for(TestDesignSummary var : testDesignSummaryList)
			{
				if(var.getApplicationTrackType() != null && var.getApplicationTrackType().equals("CD"))
				{
					dailyStatusReportBean.setApplicationTrackCdId(var.getId());
					dailyStatusReportBean.setApplicationTrackCdTotal(var.getTotal());
					dailyStatusReportBean.setApplicationTrackCdInProgress(var.getInProgress());
					dailyStatusReportBean.setApplicationTrackCdOnHold(var.getOnHold());
					dailyStatusReportBean.setApplicationTrackCdCompleted(var.getCompleted());
				}
				if(var.getApplicationTrackType() != null && var.getApplicationTrackType().equals("STATE STREET"))
				{
					dailyStatusReportBean.setApplicationTrackStateStreetId(var.getId());
					dailyStatusReportBean.setApplicationTrackStateStreetTotal(var.getTotal());
					dailyStatusReportBean.setApplicationTrackStateStreetInProgress(var.getInProgress());
					dailyStatusReportBean.setApplicationTrackStateStreetOnHold(var.getOnHold());
					dailyStatusReportBean.setApplicationTrackStateStreetCompleted(var.getCompleted());
				}
				if(var.getApplicationTrackType() != null && var.getApplicationTrackType().equals("SHARED SERVICES"))
				{
					dailyStatusReportBean.setApplicationTrackSharedServicesId(var.getId());
					dailyStatusReportBean.setApplicationTrackSharedServicesTotal(var.getTotal());
					dailyStatusReportBean.setApplicationTrackSharedServicesInProgress(var.getInProgress());
					dailyStatusReportBean.setApplicationTrackSharedServicesOnHold(var.getOnHold());
					dailyStatusReportBean.setApplicationTrackSharedServicesCompleted(var.getCompleted());
				}
				if(var.getApplicationTrackType() != null && var.getApplicationTrackType().equals("CITI CONNECT"))
				{
					dailyStatusReportBean.setApplicationTrackCitiConnectId(var.getId());
					dailyStatusReportBean.setApplicationTrackCitiConnectTotal(var.getTotal());
					dailyStatusReportBean.setApplicationTrackCitiConnectInProgress(var.getInProgress());
					dailyStatusReportBean.setApplicationTrackCitiConnectOnHold(var.getOnHold());
					dailyStatusReportBean.setApplicationTrackCitiConnectCompleted(var.getCompleted());
				}
			}
			
			
			//======================================
			Set<TestExecutionSummary> testExecutionSummariesSet = dailyStatusReportNFT.getTestExecutionSummaries();
			Iterator<TestExecutionSummary> testExecutionSummaryIterator = testExecutionSummariesSet.iterator();
			List<TestExecutionSummary> testExecutionSummariesList = new ArrayList<TestExecutionSummary>();
			while(testExecutionSummaryIterator.hasNext())
			{
				testExecutionSummariesList.add(testExecutionSummaryIterator.next());
			}
			for(TestExecutionSummary var : testExecutionSummariesList)
			{
				if(var.getApplicationTrackType() != null && var.getApplicationTrackType().equals("CD"))
				{
					dailyStatusReportBean.setTedsAppTrackCdId(var.getId());
					dailyStatusReportBean.setTedsAppTrackCdTotalScenario(var.getTotatlScenario());
					dailyStatusReportBean.setTedsAppTrackCdTotalTestRuns(var.getTotalTestRun());
					dailyStatusReportBean.setTedsAppTrackCdTotalRunPass(var.getTotalTestPass());
					dailyStatusReportBean.setTedsAppTrackCdTotalRunFailed(var.getTotalTestFailed());
				}
				if(var.getApplicationTrackType() != null && var.getApplicationTrackType().equals("STATE STREET"))
				{
					dailyStatusReportBean.setTedsAppTrackStateStreetId(var.getId());
					dailyStatusReportBean.setTedsAppTrackStateStreetTotalScenario(var.getTotatlScenario());
					dailyStatusReportBean.setTedsAppTrackStateStreetTotalTestRuns(var.getTotalTestRun());
					dailyStatusReportBean.setTedsAppTrackStateStreetTotalRunPass(var.getTotalTestPass());
					dailyStatusReportBean.setTedsAppTrackStateStreetTotalRunFailed(var.getTotalTestFailed());
				}
				if(var.getApplicationTrackType() != null && var.getApplicationTrackType().equals("SHARED SERVICES"))
				{
					dailyStatusReportBean.setTedsAppTrackSharedServicesId(var.getId());
					dailyStatusReportBean.setTedsAppTrackSharedServicesTotalScenario(var.getTotatlScenario());
					dailyStatusReportBean.setTedsAppTrackSharedServicesTotalTestRuns(var.getTotalTestRun());
					dailyStatusReportBean.setTedsAppTrackSharedServicesTotalRunPass(var.getTotalTestPass());
					dailyStatusReportBean.setTedsAppTrackSharedServicesTotalRunFailed(var.getTotalTestFailed());
				}
				if(var.getApplicationTrackType() != null && var.getApplicationTrackType().equals("CITI CONNECT"))
				{
					dailyStatusReportBean.setTedsAppTrackCitiConnectId(var.getId());
					dailyStatusReportBean.setTedsAppTrackCitiConnectTotalScenario(var.getTotatlScenario());
					dailyStatusReportBean.setTedsAppTrackCitiConnectTotalTestRuns(var.getTotalTestRun());
					dailyStatusReportBean.setTedsAppTrackCitiConnectTotalRunPass(var.getTotalTestPass());
					dailyStatusReportBean.setTedsAppTrackCitiConnectTotalRunFailed(var.getTotalTestFailed());
				}
				if(var.getApplicationTrackType() != null && var.getApplicationTrackType().equals("E2E"))
				{
					dailyStatusReportBean.setTedsAppTrackE2EId(var.getId());
					dailyStatusReportBean.setTedsAppTrackE2ETotalScenario(var.getTotatlScenario());
					dailyStatusReportBean.setTedsAppTrackE2ETotalTestRuns(var.getTotalTestRun());
					dailyStatusReportBean.setTedsAppTrackE2ETotalRunPass(var.getTotalTestPass());
					dailyStatusReportBean.setTedsAppTrackE2ETotalRunFailed(var.getTotalTestFailed());
				}
			}
			//======================================
			Set<TestDefectSummary> testDefectSummarySet = dailyStatusReportNFT.getTestDefectSummaries();
			Iterator<TestDefectSummary> testDefectSummaryIterator = testDefectSummarySet.iterator();
			List<TestDefectSummary> testDefectSummaryList = new ArrayList<TestDefectSummary>();
			while(testDefectSummaryIterator.hasNext())
			{
				testDefectSummaryList.add(testDefectSummaryIterator.next());
			}
			for(TestDefectSummary var : testDefectSummaryList)
			{
				if(var.getSeverity() == 1L)
				{
					dailyStatusReportBean.setFirstRowId(var.getId());
					dailyStatusReportBean.setFirstRowOpen(var.getOpne());
					dailyStatusReportBean.setFirstRowClosed(var.getClosed());
					dailyStatusReportBean.setFirstRowRejected(var.getRejected());
					dailyStatusReportBean.setFirstRowDefered(var.getDefered());
					dailyStatusReportBean.setFirstRowReOpned(var.getReOpened());
				}
				if(var.getSeverity() == 2L)
				{
					dailyStatusReportBean.setSecondRowId(var.getId());
					dailyStatusReportBean.setSecondRowOpen(var.getOpne());
					dailyStatusReportBean.setSecondRowClosed(var.getClosed());
					dailyStatusReportBean.setSecondRowRejected(var.getRejected());
					dailyStatusReportBean.setSecondRowDefered(var.getDefered());
					dailyStatusReportBean.setSecondRowReOpned(var.getReOpened());
				}
				if(var.getSeverity() == 3L)
				{
					dailyStatusReportBean.setThirdRowId(var.getId());
					dailyStatusReportBean.setThirdRowOpen(var.getOpne());
					dailyStatusReportBean.setThirdRowClosed(var.getClosed());
					dailyStatusReportBean.setThirdRowRejected(var.getRejected());
					dailyStatusReportBean.setThirdRowDefered(var.getDefered());
					dailyStatusReportBean.setThirdRowReOpned(var.getReOpened());
				}
				if(var.getSeverity() == 4L)
				{
					dailyStatusReportBean.setFourthRowId(var.getId());
					dailyStatusReportBean.setFourthRowOpen(var.getOpne());
					dailyStatusReportBean.setFourthRowClosed(var.getClosed());
					dailyStatusReportBean.setFourthRowRejected(var.getRejected());
					dailyStatusReportBean.setFourthRowDefered(var.getDefered());
					dailyStatusReportBean.setFourthRowReOpned(var.getReOpened());
				}
			}
			
			DropDownMenu dropDownMenu = new DropDownMenu();
			
			modelAndView.addObject("userForm", dailyStatusReportBean);
			modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
			modelAndView.addObject("raidLogStausDropDownList", dropDownMenu.raidLogStausDropDownList());
			logger.debug("RaidLog list size : "+dailyStatusReportNFT.getRaidLogs().size());
			modelAndView.addObject("raidLogsList", dailyStatusReportNFT.getRaidLogs());
			modelAndView.addObject("testDesignSummary", dailyStatusReportNFT.getTestDesignSummaries());
			modelAndView.addObject("testExecutionSummary", dailyStatusReportNFT.getTestExecutionSummaries());
			
		} catch (NoResultException e)
		{
			modelAndView.addObject("userForm", dailyStatusReportBean);
			modelAndView.addObject("css", "success");
			modelAndView.addObject("msg", "No Record Found!");
		} catch (BeansException e)
		{
		}
		
		logger.debug("loadDailyStatusReportNFT() - END");
		return modelAndView;
	}
	
	
	@RequestMapping(value = "/updateDeleteAgileDsr.html", method = {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView updateDeleteAgileDsr(@ModelAttribute("userForm") @Validated DailyStatusReportBean dailyStatusReportBean, 
			BindingResult result, Model model, final RedirectAttributes redirectAttributes, HttpServletRequest request)
	{
		logger.debug("updateOrDeleteDailyStatusReport() - START");
		logger.debug("updateOrDeleteDailyStatusReport Object Id : "+ dailyStatusReportBean.getId());
		ModelAndView modelAndView = new ModelAndView("updateDelete");
		if (result.hasErrors()) 
		{
			DropDownMenu dropDownMenu = new DropDownMenu();
			modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
			return modelAndView;
		} 
		else 
		{
			try
			{
				String addAsANewRecord = request.getParameter("addAsANewRecord");
				if("Yes".equals(addAsANewRecord))
				{
					List<RaidLogBean> raidLogBeanList = new LinkedList<RaidLogBean>();
					List<TestExecutionSummaryBean> testExecutionSummaryBeansList = new LinkedList<TestExecutionSummaryBean>();
					List<TestDesignSummaryBean> testDesignSummaryBeansList = new LinkedList<TestDesignSummaryBean>();
					
					RaidLogBean raidLogBean = null;
					TestDesignSummaryBean testDesignSummaryBean = null;
					TestExecutionSummaryBean testExecutionSummaryBean = null;
					
					if(request.getParameter("rowCount") != null && !"".equals(request.getParameter("rowCount")) && request.getParameter("rowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("rowCount"));
						System.out.println("Row Count Value "+rowCount);
						logger.debug("Row Count Value "+rowCount);
						for(int i = 1; i <= rowCount; i++)
						{
							System.out.println("Type Value : "+request.getParameter("type"+i));
							logger.debug("Type Value : "+request.getParameter("type"+i));
							raidLogBean = new RaidLogBean();
							logger.debug("RaidLog Id : "+request.getParameter("id"+i));
							System.out.println("RaidLog Id : "+request.getParameter("id"+i));
	//						raidLogBean.setId(Long.parseLong(request.getParameter("id"+i)));
	//						raidLogBean.setType(request.getParameter("type"+i));
							raidLogBean.setImpactedApp(request.getParameter("impactedApp"+i));
							raidLogBean.setDescription(request.getParameter("description"+i));
							raidLogBean.setStatus(request.getParameter("status"+i));
							raidLogBean.setPortfolioManager(request.getParameter("portfolioManager"+i));
							raidLogBean.setRadiOwner(request.getParameter("radiOwner"+i));
							raidLogBean.setRag(request.getParameter("rag"+i));
							logger.debug("Logged Date : "+request.getParameter("dateLogged"+i));
							Date loggedDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("dateLogged"+i));
							raidLogBean.setDateLogged(loggedDate);
							Date targetClosureDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("targetClosureDate"+i));
							raidLogBean.setTargetClosureDate(targetClosureDate);
							raidLogBean.setAge(request.getParameter("age"+i));
							raidLogBean.setMileStoneImpacted(request.getParameter("mileStoneImpacted"+i));
							raidLogBean.setRaidBackToGreenPlan(request.getParameter("raidBackToGreenPlan"+i));
							raidLogBeanList.add(raidLogBean);
						}
						dailyStatusReportBean.setRaidLogBeanList(raidLogBeanList);
					}
					
					if(request.getParameter("testDesignSummaryRowCount") != null && !"".equals(request.getParameter("testDesignSummaryRowCount")) && request.getParameter("testDesignSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("testDesignSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							testDesignSummaryBean = new TestDesignSummaryBean();
							testDesignSummaryBean.setApplicationTrackType((request.getParameter("applicationTrack"+i) == null ) ? "NA" : request.getParameter("applicationTrack"+i));
							testDesignSummaryBean.setTotal((request.getParameter("tdsTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("tdsTotal"+i)));
							testDesignSummaryBean.setInProgress((request.getParameter("tdsInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("tdsInProgress"+i)));
							testDesignSummaryBean.setOnHold((request.getParameter("tdsOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("tdsOnHold"+i)));
							testDesignSummaryBean.setCompleted((request.getParameter("tdsCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("tdsCompleted"+i)));
							
							testDesignSummaryBeansList.add(testDesignSummaryBean);
						}
						dailyStatusReportBean.setTestDesignSummaryList(testDesignSummaryBeansList);
					}
					
					if(request.getParameter("testExectuionSummaryRowCount") != null && !"".equals(request.getParameter("testExectuionSummaryRowCount")) && request.getParameter("testExectuionSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("testExectuionSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							testExecutionSummaryBean = new TestExecutionSummaryBean();
							testExecutionSummaryBean.setApplicationTrackType((request.getParameter("tesApplicationTrack"+i) == null ) ? "NA" : request.getParameter("tesApplicationTrack"+i));
							testExecutionSummaryBean.setTotatlScenario((request.getParameter("totalScenario"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("totalScenario"+i)));
							testExecutionSummaryBean.setTotalTestRun((request.getParameter("totalTestRun"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("totalTestRun"+i)));
							testExecutionSummaryBean.setTotalTestPass((request.getParameter("totalTestRunPass"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("totalTestRunPass"+i)));
							testExecutionSummaryBean.setTotalTestFailed((request.getParameter("totalTestRunFailed"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("totalTestRunFailed"+i)));
													
							testExecutionSummaryBeansList.add(testExecutionSummaryBean);
						}
						dailyStatusReportBean.setTestExecutionSummaryList(testExecutionSummaryBeansList);
					}
					
					commonService.saveDailStatusReport(dailyStatusReportBean);
					modelAndView.addObject("css", "success");
					modelAndView.addObject("msg", "Record inserted successfully!");
				}
				else
				{
					List<RaidLogBean> raidLogBeanList = new LinkedList<RaidLogBean>();
					List<TestExecutionSummaryBean> testExecutionSummaryBeansList = new LinkedList<TestExecutionSummaryBean>();
					List<TestDesignSummaryBean> testDesignSummaryBeansList = new LinkedList<TestDesignSummaryBean>();
					
					RaidLogBean raidLogBean = null;
					TestDesignSummaryBean testDesignSummaryBean = null;
					TestExecutionSummaryBean testExecutionSummaryBean = null;
					
					if(request.getParameter("rowCount") != null && !"".equals(request.getParameter("rowCount")) && request.getParameter("rowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("rowCount"));
						System.out.println("Row Count Value "+rowCount);
						logger.debug("Row Count Value "+rowCount);
						for(int i = 1; i <= rowCount; i++)
						{
							System.out.println("Type Value : "+request.getParameter("type"+i));
							logger.debug("Type Value : "+request.getParameter("type"+i));
							raidLogBean = new RaidLogBean();
							logger.debug("RaidLog Id : "+request.getParameter("id"+i));
							System.out.println("RaidLog Id : "+request.getParameter("id"+i));
							if(request.getParameter("id"+i) != null && !request.getParameter("id"+i).equals("") && request.getParameter("id"+i).length() > 0)
							{
								raidLogBean.setId(Long.parseLong(request.getParameter("id"+i)));
							}
							raidLogBean.setType(request.getParameter("type"+i));
							raidLogBean.setImpactedApp(request.getParameter("impactedApp"+i));
							raidLogBean.setDescription(request.getParameter("description"+i));
							raidLogBean.setStatus(request.getParameter("status"+i));
							raidLogBean.setPortfolioManager(request.getParameter("portfolioManager"+i));
							raidLogBean.setRadiOwner(request.getParameter("radiOwner"+i));
							raidLogBean.setRag(request.getParameter("rag"+i));
							logger.debug("Logged Date : "+request.getParameter("dateLogged"+i));
							Date loggedDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("dateLogged"+i));
							raidLogBean.setDateLogged(loggedDate);
							Date targetClosureDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("targetClosureDate"+i));
							raidLogBean.setTargetClosureDate(targetClosureDate);
							raidLogBean.setAge(request.getParameter("age"+i));
							raidLogBean.setMileStoneImpacted(request.getParameter("mileStoneImpacted"+i));
							raidLogBean.setRaidBackToGreenPlan(request.getParameter("raidBackToGreenPlan"+i));
							raidLogBeanList.add(raidLogBean);
						}
						dailyStatusReportBean.setRaidLogBeanList(raidLogBeanList);
					}
					
					if(request.getParameter("testDesignSummaryRowCount") != null && !"".equals(request.getParameter("testDesignSummaryRowCount")) && request.getParameter("testDesignSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("testDesignSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							testDesignSummaryBean = new TestDesignSummaryBean();
							if(request.getParameter("tdsId"+i) != null && !request.getParameter("tdsId"+i).equals("") && request.getParameter("tdsId"+i).length() > 0)
							{
								testDesignSummaryBean.setId(Long.parseLong(request.getParameter("tdsId"+i)));
							}
							testDesignSummaryBean.setApplicationTrackType((request.getParameter("applicationTrack"+i) == null ) ? "NA" : request.getParameter("applicationTrack"+i));
							testDesignSummaryBean.setTotal((request.getParameter("tdsTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("tdsTotal"+i)));
							testDesignSummaryBean.setInProgress((request.getParameter("tdsInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("tdsInProgress"+i)));
							testDesignSummaryBean.setOnHold((request.getParameter("tdsOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("tdsOnHold"+i)));
							testDesignSummaryBean.setCompleted((request.getParameter("tdsCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("tdsCompleted"+i)));
							
							testDesignSummaryBeansList.add(testDesignSummaryBean);
						}
						dailyStatusReportBean.setTestDesignSummaryList(testDesignSummaryBeansList);
					}
					
					if(request.getParameter("testExectuionSummaryRowCount") != null && !"".equals(request.getParameter("testExectuionSummaryRowCount")) && request.getParameter("testExectuionSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("testExectuionSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							testExecutionSummaryBean = new TestExecutionSummaryBean();
							if(request.getParameter("tedId"+i) != null && !request.getParameter("tedId"+i).equals("") && request.getParameter("tedId"+i).length() > 0)
							{
								testExecutionSummaryBean.setId(Long.parseLong(request.getParameter("tedId"+i)));
							}
							testExecutionSummaryBean.setApplicationTrackType((request.getParameter("tesApplicationTrack"+i) == null ) ? "NA" : request.getParameter("tesApplicationTrack"+i));
							testExecutionSummaryBean.setTotatlScenario((request.getParameter("totalScenario"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("totalScenario"+i)));
							testExecutionSummaryBean.setTotalTestRun((request.getParameter("totalTestRun"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("totalTestRun"+i)));
							testExecutionSummaryBean.setTotalTestPass((request.getParameter("totalTestRunPass"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("totalTestRunPass"+i)));
							testExecutionSummaryBean.setTotalTestFailed((request.getParameter("totalTestRunFailed"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("totalTestRunFailed"+i)));
													
							testExecutionSummaryBeansList.add(testExecutionSummaryBean);
						}
						dailyStatusReportBean.setTestExecutionSummaryList(testExecutionSummaryBeansList);
					}
					
					commonService.updateDailyStatusReport(dailyStatusReportBean);
					modelAndView.addObject("css", "success");
					modelAndView.addObject("msg", "Record has been updated!");
				}
			
			} 
			catch (Exception e)
			{
				modelAndView.addObject("css", "fail");
				modelAndView.addObject("msg", "Duplicate Entry please insert uniqueu record!");
				e.printStackTrace();
			}
		}
		
		logger.debug("updateOrDeleteDailyStatusReport() - START");
		
		return modelAndView;
	}
	
	@RequestMapping(value = "/deleteAgileDailyStatusReport.html", method = RequestMethod.GET)
	public ModelAndView deleteAgileDailyStatusReport(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("deleteDailyStatusReport() - START");
		logger.debug("Object Id : "+ request.getParameter("objectId"));
		String objectId = request.getParameter("objectId");
		Long longObjectId = Long.parseLong(objectId);
		commonService.deleteDailySatuReport(longObjectId);
		ModelAndView modelAndView = new ModelAndView("updateDelete");
		modelAndView.addObject("css", "success");
		modelAndView.addObject("msg", "Record has been deleted!");
		logger.debug("deleteDailyStatusReport() - END");
		return modelAndView;
	}
	
	@RequestMapping(value = "/deleteAgileRaidLogById.html", method = RequestMethod.GET)
	public String deleteAgileRaidLogById(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("deleteDailyStatusReport() - START");
		logger.debug("Object Id : "+ request.getParameter("objectId"));
		String raidLogIdStr = request.getParameter("raidLogId");
		Long raidLogId = Long.parseLong(raidLogIdStr);
		commonService.deleteRaidLogById(raidLogId);
		ModelAndView modelAndView = new ModelAndView("updateDelete");
//		modelAndView.addObject("css", "success");
//		modelAndView.addObject("msg", "Record has been deleted!");
		logger.debug("deleteDailyStatusReport() - END");
		return "redirect:loadUpdateDelete.html?searchDate="+searchDate+"&searchSdpId="+searchSdpId+"";
	}
	
	@RequestMapping(value = "/deleteAgileTestDesignSummaryById.html", method = RequestMethod.GET)
	public String deleteAgileTestDesignSummaryById(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("deleteDailyStatusReport() - START");
		String tdsIdStr = request.getParameter("tdsId");
		Long tdsId = Long.parseLong(tdsIdStr);
		commonService.deleteTestDesignSummaryById(tdsId);
		ModelAndView modelAndView = new ModelAndView("updateDelete");
//		modelAndView.addObject("css", "success");
//		modelAndView.addObject("msg", "Record has been deleted!");
		logger.debug("deleteDailyStatusReport() - END");
		return "redirect:loadUpdateDelete.html?searchDate="+searchDate+"&searchSdpId="+searchSdpId+"";
	}
	
	@RequestMapping(value = "/deleteAgileTestExecutionSummaryById.html", method = RequestMethod.GET)
	public String deleteAgileTestExecutionSummaryById(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		//loadUpdateDelete.html?searchDate=2018-05-07&searchSdpId=4444
		logger.debug("deleteDailyStatusReport() - START");
		String tedIdStr = request.getParameter("tedId");
		Long tedId = Long.parseLong(tedIdStr);
		commonService.deleteTestExecutionSummaryById(tedId);
		ModelAndView modelAndView = new ModelAndView("updateDelete");
//		modelAndView.addObject("css", "success");
//		modelAndView.addObject("msg", "Record has been deleted!");
		logger.debug("deleteDailyStatusReport() - END");
		return "redirect:loadUpdateDelete.html?searchDate="+searchDate+"&searchSdpId="+searchSdpId+"";
	}*/
	
}
