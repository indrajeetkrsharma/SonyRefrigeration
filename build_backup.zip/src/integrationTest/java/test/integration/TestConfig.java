package test.integration;

/**
 * Test configuration -- provides required beans
 */
@Configuration
@ComponentScan("com.ge.bm.springExtensions.auth")
public class TestConfig {
	private static final String TEST_AUTHORIZATION_TOKEN_PROPERTY = "${test.authToken:}";
	/**
	 * Authorization tokens for integration tests. Expires 2019.
	 */
	public static final String defaultAuthorizationToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI4ZTM1ZjM1MjQ3NDc0ZWQ2OGM5OWMzMzM1OGM4MmUxNyIsInN1YiI6IjQ0NmJhOTE4LWQ4ZWMtNDU1Mi1hYTViLWY4MDlmYWI5NGM3YiIsInNjb3BlIjpbInNjaW0udXNlcmlkcyIsIm9wZW5pZCIsImJtLW9wZXJhdG9ycyIsImNsb3VkX2NvbnRyb2xsZXIucmVhZCIsInBhc3N3b3JkLndyaXRlIiwiY2xvdWRfY29udHJvbGxlci53cml0ZSJdLCJjbGllbnRfaWQiOiJhcHAiLCJjaWQiOiJhcHAiLCJhenAiOiJhcHAiLCJncmFudF90eXBlIjoicGFzc3dvcmQiLCJ1c2VyX2lkIjoiNDQ2YmE5MTgtZDhlYy00NTUyLWFhNWItZjgwOWZhYjk0YzdiIiwib3JpZ2luIjoidWFhIiwidXNlcl9uYW1lIjoiYm1fb3BlcmF0b3JfMSIsImVtYWlsIjoiYm1fb3BlcmF0b3JfMSIsImF1dGhfdGltZSI6MTU1MzUyMzQ3MiwicmV2X3NpZyI6IjIzNmQ2YjJjIiwiaWF0IjoxNTUzNTIzNDcyLCJleHAiOjE1NTM1NjY2NzIsImlzcyI6Imh0dHBzOi8vMTAuMTgxLjIxMy4xNzk6ODQ0My91YWEvb2F1dGgvdG9rZW4iLCJ6aWQiOiJ1YWEiLCJhdWQiOlsiYXBwIiwic2NpbSIsImNsb3VkX2NvbnRyb2xsZXIiLCJwYXNzd29yZCIsIm9wZW5pZCJdfQ.eXqjIZiltY5gVuH7HJpv-u6MjbEnOp0wBZh9Y4BKTKtt9h6tkpuuy6sKte5rtezuS3DEWNEtt_Ibv5aD3KRmVX4J4AOYTVt35pBZb4EbALTs-CdVDCXkSgGPbRSqhXWMWgayd-Y7qq9-xx5Bq5t0zoKWZFRKFcbF5UIjbnh4iWLQXjvsCtQ9A8tiKT-PDZ6EwTWybSCebao-OGDY_YTnzBG-qyj_i_SkYZ2Eh6Uqbsy3P0lbOprS3X5K_VmHLJGyV_08tDuPNCKnCdXcFzOhZ-ZpYBE_rtnECrM-bgshbE-bZZpgXvNSGXrQdg_LcCqq4QYguUcVZfpzPW73jlBYww";
	public static final String defaultNonPaUserAuthorizationToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI4ZTM1ZjM1MjQ3NDc0ZWQ2OGM5OWMzMzM1OGM4MmUxNyIsInN1YiI6IjQ0NmJhOTE4LWQ4ZWMtNDU1Mi1hYTViLWY4MDlmYWI5NGM3YiIsInNjb3BlIjpbInNjaW0udXNlcmlkcyIsIm9wZW5pZCIsImJtLW9wZXJhdG9ycyIsImNsb3VkX2NvbnRyb2xsZXIucmVhZCIsInBhc3N3b3JkLndyaXRlIiwiY2xvdWRfY29udHJvbGxlci53cml0ZSJdLCJjbGllbnRfaWQiOiJhcHAiLCJjaWQiOiJhcHAiLCJhenAiOiJhcHAiLCJncmFudF90eXBlIjoicGFzc3dvcmQiLCJ1c2VyX2lkIjoiNDQ2YmE5MTgtZDhlYy00NTUyLWFhNWItZjgwOWZhYjk0YzdiIiwib3JpZ2luIjoidWFhIiwidXNlcl9uYW1lIjoiYm1fb3BlcmF0b3JfMSIsImVtYWlsIjoiYm1fb3BlcmF0b3JfMSIsImF1dGhfdGltZSI6MTU1MzUyMzQ3MiwicmV2X3NpZyI6IjIzNmQ2YjJjIiwiaWF0IjoxNTUzNTIzNDcyLCJleHAiOjE1NTM1NjY2NzIsImlzcyI6Imh0dHBzOi8vMTAuMTgxLjIxMy4xNzk6ODQ0My91YWEvb2F1dGgvdG9rZW4iLCJ6aWQiOiJ1YWEiLCJhdWQiOlsiYXBwIiwic2NpbSIsImNsb3VkX2NvbnRyb2xsZXIiLCJwYXNzd29yZCIsIm9wZW5pZCJdfQ.eXqjIZiltY5gVuH7HJpv-u6MjbEnOp0wBZh9Y4BKTKtt9h6tkpuuy6sKte5rtezuS3DEWNEtt_Ibv5aD3KRmVX4J4AOYTVt35pBZb4EbALTs-CdVDCXkSgGPbRSqhXWMWgayd-Y7qq9-xx5Bq5t0zoKWZFRKFcbF5UIjbnh4iWLQXjvsCtQ9A8tiKT-PDZ6EwTWybSCebao-OGDY_YTnzBG-qyj_i_SkYZ2Eh6Uqbsy3P0lbOprS3X5K_VmHLJGyV_08tDuPNCKnCdXcFzOhZ-ZpYBE_rtnECrM-bgshbE-bZZpgXvNSGXrQdg_LcCqq4QYguUcVZfpzPW73jlBYww";

	@Bean
	@Primary
	public RestTemplate getAuthorizedRestTemplate() {
		return new AuthorizingRestTemplate("Bearer " + getAuthorizationToken());
	}

	@Value(TEST_AUTHORIZATION_TOKEN_PROPERTY)
	public String authTokenOverride;

	@Value("${test.client.id:app}")
	public String testClientId;

	@Value("${test.client.secret:appclientsecret}")
	public String testClientSecret;

	@Value("${test.user.name:bm_operator_1}")
	public String testUsername;

	@Value("${test.user.password:bm_operator_1}")
	public String testUserPassword;

	@Value("${uaa.service.origin}")
	private String uaaServiceOrigin;

	@Autowired
	private UaaTokenClient uaaTokenClient;

	private String getAuthorizationToken() {
		if (!StringUtils.isEmpty(authTokenOverride)) {
			System.out.println("Using specified authorization token from property 'test.authToken' for tests.");
			return authTokenOverride;
		}
		SSLUtil.disableSslVerification();
		if (!StringUtils.isEmpty(testClientId)) {
			System.out.println(
					"Using specified client ID '" + testClientId + "' and user '" + testUsername + "' for tests.");
			UaaToken token = uaaTokenClient.getNewTokenViaPasswordGrantType(testClientId, testClientSecret,
					testUsername, testUserPassword);

			return token.getAccessToken();
		}

		System.out.println("Using default authorization token for tests.");
		return defaultAuthorizationToken;
	}

	@Bean
	public ValidationServiceUrlGenerator getRouteServiceUrlGenerator() {
		return new ValidationServiceUrlGenerator();
	}

	@Bean
	public MesServiceUrlGenerator getMesServiceUrlGenerator() {
		return new MesServiceUrlGenerator();
	}
}