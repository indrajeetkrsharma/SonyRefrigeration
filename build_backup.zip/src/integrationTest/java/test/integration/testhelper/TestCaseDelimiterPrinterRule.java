package test.integration.testhelper;

/**
 * Helper class to print delimiters before and after each test. Includes test name, timestamps, and elapsed time.
 */
public class TestCaseDelimiterPrinterRule implements TestRule{
	
	private static final String timeFormat = "HH:mm:ss.SSS";
	private static final String beforeFormat = "\n***\n*** [TEST START %s] %s\n***\n";
	private static final String afterFormat = "***\n*** [TEST ENDED %s] Time elapsed: %s sec\n***\n\n";
	
	private OutputStream out = null;
	private final TestCasePrinter printer = new TestCasePrinter();
	
	private String testName = null;
	private long timeStart;
	
	public TestCaseDelimiterPrinterRule(OutputStream os) {
		out = os;
	}

	/**
	 * Modifies the method-running {@link Statement} to implement this
	 * test-running rule.
	 *
	 * @param base        The {@link Statement} to be modified
	 * @param description A {@link Description} of the test implemented in {@code base}
	 * @return a new statement, which may be the same as {@code base},
	 * a wrapper around {@code base}, or a completely new Statement.
	 */
	@Override
	public org.junit.runners.model.Statement apply(org.junit.runners.model.Statement base, Description description) {
		testName = String.format("%s.%s", description.getClassName(), description.getMethodName());
		return printer.apply(base, description);
	}
	
	private class TestCasePrinter extends ExternalResource {
		
		@Override
		protected void before() throws Throwable {
			timeStart = System.currentTimeMillis();
			out.write(String.format(beforeFormat, getTimestamp(), testName).getBytes());
		}

		@Override
		protected void after() {
			try {
				long timeEnd = System.currentTimeMillis();
				double seconds = (timeEnd - timeStart) / 1000.0;
				out.write(String.format(afterFormat, getTimestamp(), new DecimalFormat("0.000").format(seconds)).getBytes());
			} catch (IOException ioe) { /* ignore */
			}
		}
		
	}
	
	private static String getTimestamp() {
		return LocalTime.now().format(DateTimeFormatter.ofPattern(timeFormat));
	}
	
	
}
