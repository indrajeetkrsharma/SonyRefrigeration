package test.integration.testhelper;

public class ExceptionsHandlers {

	protected ObjectMapper mapper = new ObjectMapper();
	
	public void assertExpectedInvalidDataError(HttpClientErrorException e, InvalidDataErrorType errorType, String invalidParameterName,String errorCode ) {

		try{
			HttpErrorResponse errorResponse = mapper.readValue(e.getResponseBodyAsByteArray(), HttpErrorResponse.class);
			HttpErrorResponse.Error err = errorResponse.getError();
		    assertEquals(errorCode, err.getCode());
			assertNotNull(err.getDetails());
			assertEquals( errorType.toString(), ((HashMap) err.getDetails()).get("errorType"));
			assertEquals( invalidParameterName, ((HashMap) err.getDetails()).get("propertyName1"));
		
		} catch (IOException e1){
			fail("IOException in deserializing HttpErrorResponse");
		}
	}
	
	
	public void assertExpectedInvalidLength(HttpClientErrorException e) {

		try {
			HttpErrorResponse errorResponse = mapper.readValue(e.getResponseBodyAsByteArray(), HttpErrorResponse.class);
			HttpErrorResponse.Error err = errorResponse.getError();
			assertEquals("InvalidCharacterLength", err.getCode());

		} catch (IOException e1) {
			fail("IOException in deserializing HttpErrorResponse");
		}
	}
	
	public void assertExpectedKeyConflict(HttpClientErrorException e) {

		try {
			HttpErrorResponse errorResponse = mapper.readValue(e.getResponseBodyAsByteArray(), HttpErrorResponse.class);
			HttpErrorResponse.Error err = errorResponse.getError();
			assertEquals("KeyConflict", err.getCode());

		} catch (IOException e1) {
			fail("IOException in deserializing HttpErrorResponse");
		}
	}
	
	
	public void assertExpectedInvalidProperty(HttpClientErrorException e) {

		try {
			HttpErrorResponse errorResponse = mapper.readValue(e.getResponseBodyAsByteArray(), HttpErrorResponse.class);
			HttpErrorResponse.Error err = errorResponse.getError();
			assertEquals("InvalidParameterValue", err.getCode());

		} catch (IOException e1) {
			fail("IOException in deserializing HttpErrorResponse");
		}
	}	
	
	
	public void assertExpectedResourceNotFound(HttpClientErrorException e) {

		try {
			HttpErrorResponse errorResponse = mapper.readValue(e.getResponseBodyAsByteArray(), HttpErrorResponse.class);
			HttpErrorResponse.Error err = errorResponse.getError();
			assertEquals("ResourceNotFound", err.getCode());

		} catch (IOException e1) {
			fail("IOException in deserializing HttpErrorResponse");
		}
	}
	
	public void assertExpectedUpdateConstarint(HttpClientErrorException e) {

		try {
			HttpErrorResponse errorResponse = mapper.readValue(e.getResponseBodyAsByteArray(), HttpErrorResponse.class);
			HttpErrorResponse.Error err = errorResponse.getError();
			assertEquals("IncorrectStatus", err.getCode());

		} catch (IOException e1) {
			fail("IOException in deserializing HttpErrorResponse");
		}
	}
	
	public void assertExpectedException(HttpClientErrorException e,String msg) {

		try {
			HttpErrorResponse errorResponse = mapper.readValue(e.getResponseBodyAsByteArray(), HttpErrorResponse.class);
			HttpErrorResponse.Error err = errorResponse.getError();
			assertEquals(msg, err.getCode());

		} catch (IOException e1) {
			fail("IOException in deserializing HttpErrorResponse");
		}
	}
}
