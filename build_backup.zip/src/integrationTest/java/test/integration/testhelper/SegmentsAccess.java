package test.integration.testhelper;

public class SegmentsAccess {
	
	private RestTemplate restTemplate;

	private int port;

	/**
	 * Construct the access helpers for non-conformances endpoint
	 * 
	 * @param restTemplate
	 *            Rest template to make requests on
	 * @param port
	 *            Port that the service resides on.
	 */
	public SegmentsAccess(RestTemplate restTemplate, int port) {
		this.port = port;
		this.restTemplate = restTemplate;
	}
	
	
	public SegmentsDefinitionInfo validateCreateSegments(String createSegmentUrl, SegmentsDefinitionInfo segmentsDefInfo) {
		ResponseEntity<SegmentsDefinitionInfo> segment;
		segmentsDefInfo.getSegments().add(SegmentInfoTestData.getSegmentsInfo())	;
		
		//Add operation  info
		OperationsInfo operations = new OperationsInfo();
		operations.setId(1L);
		operations.setSequenceNumber(1);
		segmentsDefInfo.getStructure().getOperations().add(operations);
		HttpEntity<?> req = new HttpEntity<>(segmentsDefInfo);
		HttpStatus expectedStatus = HttpStatus.CREATED;
		try{
			segment = restTemplate.exchange(createSegmentUrl, HttpMethod.PUT , req , new ParameterizedTypeReference<SegmentsDefinitionInfo>() {});
			
		}catch (HttpClientErrorException ex) {
			assertEquals("Unexpected HTTP status", expectedStatus, ex.getStatusCode());
			return null;
		}
		
		//Validate segments
		assertNotNull("RouteSegment should be non-null", segment);
		assertEquals("RouteSegment Schema version", "1" , segment.getBody().getSchemaVersion().toString());
		assertEquals("RouteSegment Structure type", "simple" , segment.getBody().getStructureType());
		assertEquals("RouteSegment Segments lenth", 2 , segment.getBody().getSegments().size());
		assertEquals("RouteSegment Operations lenth", 1 , segment.getBody().getStructure().getOperations().size());
		assertEquals("RouteSegment ID", "0" , segment.getBody().getSegments().get(0).getId().toString());
		assertEquals("RouteSegment ID", "Route Level" , segment.getBody().getSegments().get(0).getName());
		
		//Validate operation segments	
		assertEquals("Segment Operation SequenceNumber", "1" , segment.getBody().getStructure().getOperations().get(0).getSequenceNumber().toString());
		assertEquals("Segment ID", "1" , segment.getBody().getSegments().get(1).getId().toString());
		assertEquals("Segment Name", "Op10" , segment.getBody().getSegments().get(1).getName());
		
		return segment.getBody();
		
	}
	
	
	public SegmentsDefinitionInfo validateGetAllSegments200(String url) {
		// Arrange
		HttpStatus expectedStatus = HttpStatus.OK;

		// Act - contact the service
		ResponseEntity<SegmentsDefinitionInfo> segment = restTemplate.exchange(url, HttpMethod.GET, null,
				new ParameterizedTypeReference<SegmentsDefinitionInfo>() {
				});
		// Assert - validate the response
		assertNotNull("Unexpected request failure; no response", segment);
		assertEquals("Unexpected HTTP status", expectedStatus, segment.getStatusCode());
		
		@SuppressWarnings("unchecked")
		SegmentsDefinitionInfo segmentsDefInfo = (SegmentsDefinitionInfo) segment.getBody();
		return segmentsDefInfo;

	}
	
	
	public SegmentsDefinitionInfo validateDeleteAllSegments200(String url) {
		// Arrange
		HttpStatus expectedStatus = HttpStatus.SEE_OTHER;

		// Act - contact the service
		ResponseEntity<SegmentsDefinitionInfo> segment = restTemplate.exchange(url, HttpMethod.DELETE, null,
				new ParameterizedTypeReference<SegmentsDefinitionInfo>() {
				});
		// Assert - validate the response
		assertNotNull("Unexpected request failure; no response", segment);
		assertEquals("Unexpected HTTP status", expectedStatus, segment.getStatusCode());
		
		@SuppressWarnings("unchecked")
		SegmentsDefinitionInfo segmentsDefInfo = (SegmentsDefinitionInfo) segment.getBody();
		return segmentsDefInfo;

	}
}
