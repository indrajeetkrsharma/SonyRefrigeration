package test.integration;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = { "test.authToken=" })
public class IntegrationTestsBase {

	@Rule
	public TestCaseDelimiterPrinterRule prl = new TestCaseDelimiterPrinterRule(System.out);

	@Autowired
	protected RestTemplate restTemplate = new RestTemplate();

	@Autowired
	protected ValidationServiceUrlGenerator urlGenerator;

	@Value("${local.server.port}")
	protected int randomPort;
	
	ObjectMapper mapper = new ObjectMapper();	
	
	protected ParameterizedTypeReference<String> msg = new ParameterizedTypeReference<String>() {
	};
	
	protected ParameterizedTypeReference<ResponseEntity> validationResults = new ParameterizedTypeReference<ResponseEntity>() {
	};
	
	protected static final String DEFAULT_HOST_LOCATION_HOSTNAME = "http://localhost";
	
	protected SegmentsAccess segmentsAccess;
	
	protected ExceptionsHandlers exceptionsHandlers;
	

	@Before
	public void initializeServiceLocation() {

		// Set url generator to use our hostname + the random port. We want to
		// replace any environment variables we might
		// have set here, because the service we want is running wherever the
		// test started it, we don't care about where
		// else it might be hosted

		urlGenerator.setServiceLocation(DEFAULT_HOST_LOCATION_HOSTNAME + ":" + randomPort);		
		segmentsAccess = new SegmentsAccess(restTemplate, randomPort);
		exceptionsHandlers = new ExceptionsHandlers();		 
	}
	
	@Test
	public void sampleTest() {
		assertEquals(true,true);		
	}
}