package com.example.Test;

import javax.annotation.PostConstruct;

import org.poc.laborservice.springextension.UrlGenerator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponentsBuilder;

public class ValidationServiceUrlGenerator extends UrlGenerator {

	// This syntax means, if property found, use it. Else return "". Basically
	// sets the default to empty string.
	@Value("${routemanagement.service.origin:}")
	private String OverrideHostLocationUrl;

	/**
	 * Set service location based on environment variable
	 */
	@PostConstruct
	public void init() {
		if (!StringUtils.isEmpty(OverrideHostLocationUrl)) {
			setServiceLocation(OverrideHostLocationUrl);
		}

	}	
	
	private static final String VALIDATE_SEGMENTS = "validateSegmentsDocument";	
	private static final String VALIDATE_SCHEMA_ONLY = "validateSchemaOnly";

	/**
	 * Generate the URL to add Route record
	 * 
	 * @return the url
	 */
	public String generateValidationSegmentsUrl() {
		UriComponentsBuilder builder = getBuilder();
		builder.pathSegment(VALIDATE_SEGMENTS);
		builder.queryParam(VALIDATE_SCHEMA_ONLY, true);
		return builder.build().toUriString();
	}
	
	public String generateValidationSegmentsContentUrl() {
		UriComponentsBuilder builder = getBuilder();
		builder.pathSegment(VALIDATE_SEGMENTS);
		builder.queryParam(VALIDATE_SCHEMA_ONLY, false);
		return builder.build().toUriString();
	}

}
