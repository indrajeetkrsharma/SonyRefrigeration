package com.example.swagger;

import java.io.IOException;

import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;

/**
 * Small test runner application to execute the SwaggerJsonGenerator 'test'.
 */
public class SwaggerRunner {
	public static void main(String... args) throws IOException {
		JUnitCore core = new JUnitCore();
		Request request = Request.classes(
				SwaggerJsonGenerator.class);

		Result results = core.run(request);

		// return 0 on succ and 99 on fail so we can distinguish from execution failure
		System.exit(results.wasSuccessful() ? 0 : 99);
	}

}
