package com.example.swagger;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

/**
 * This is not really a test but a tool to gather the API info from the service
 * to provide as input to the Swagger API generator.
 */
@RunWith(SpringRunner.class)
@WebAppConfiguration
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK, properties = {
		"springfox.documentation.swagger.v2.path=/docs", "test.authToken=" })
public class SwaggerJsonGenerator {
	private MockMvc service;

	@Autowired
	private WebApplicationContext wac;

	@Before
	public void init() {
		service = MockMvcBuilders.webAppContextSetup(wac).build();
	}
	
	@Test
	public void test() throws Exception {
		// Needs to match springfox.documentation.swagger.v2.path from above.
		String apiDocsUrlTemplate = "/docs";
		System.err.println("--> Fetching API docs from service " + apiDocsUrlTemplate); // use STDERR so that this is visible to console

		String responseBody = this.service
				.perform(get(apiDocsUrlTemplate))
				.andReturn().getResponse().getContentAsString();

		Path path = Paths.get("build/api/service.json");

		try (BufferedWriter writer = Files.newBufferedWriter(path)) {
			writer.write(responseBody);
		}

		System.err.println("--> Wrote API docs to " + path); // use STDERR so that this is visible to console
	}

}