package org.poc.laborservice.controllers;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Encapsulates an HTTP response payload intended for returning detailed error
 * information.
 *
 * The payload format borrows ideas from OData (see section 19 of
 * http://go.microsoft.com/fwlink/?LinkId=301473) and RFC7807
 * (https://tools.ietf.org/html/rfc7807) as well as existing GE BMS code.
 *
 * Response Format ---------------
 *
 * The error response format consists of application/JSON data with the
 * following fields:
 *
 * Timestamp (string) Timestamp of error in ISO8601 format.
 *
 * Path (string) HTTP request path where the error occurred.
 *
 * Error (class) A single error structure consisting of the following fields:
 *
 * Code (string) Enumeration value of the error classification or type. The
 * possible values should be well documented in the API docs. This value should
 * not be localized. This should be enough information for an automated caller
 * to determine the next action and what to display to the user.
 *
 * Details (class) An optional class (may be null) containing arbitrary details
 * about the specific error occurrence. The exact format should be the same for
 * any other error of the same Code. The details should specify enough
 * information for the caller to correct the error.
 *
 * Notes -----
 *
 * - We considered keeping a Message string inside the Error class, similar to
 * OData and RFC7807 but rejected the ida for two reasons: 1) The message
 * describes the error type and is thus redundant. 2) Localization of the
 * message is not always needed because it is up to the caller to decide if the
 * message is appropriate to pass to the user. Besides, localization may be
 * performed by an external service thus there is no advantage to providing a
 * human readable localized message here.
 *
 * - Returning the HTTP status code in the response body is redundant because it
 * must already be passed in the response headers.
 *
 * TODO ----
 *
 * - Bring to the BMS Rest Board for review and feedback.
 *
 * - Review how Spring's error handling and make sure this scheme jives and
 * figure out how to use Spring to provide constructs to aid development use of
 * this response type. See
 * http://www.baeldung.com/exception-handling-for-rest-with-spring and
 * 
 * @ControllerAdvice
 *
 * 					- Validate this response type with other errors and, more
 *                   importantly, aggregated error returns.
 */
@ApiModel(value="HttpErrorResponse", description="Http Error response.")
public class HttpErrorResponse {

	@ApiModelProperty(value = "Error details")
	private Error error;
	
	@ApiModelProperty(value = "Timestamp at which error occured")
	private String timestamp;
	
	@ApiModelProperty(value = "URL at which error occured.")
	private String path;

	/**
	 * Construct a new HttpErrorResponse object.
	 * 
	 * @param requestPath
	 *            the request path URL
	 * @param errorType
	 *            error type (should be documented in a public API)
	 * @param details
	 *            arbitrary error details; must be JSON serializable
	 */
	public HttpErrorResponse(String requestPath, String errorType, Object details) {
		error = new Error(errorType, details);
		timestamp = ZonedDateTime.now().format(DateTimeFormatter.ISO_INSTANT); // use ISO 8601 format with UTC
		path = requestPath;
	}

	/**
	 * Default constructor for construction purposes.
	 */
	public HttpErrorResponse() {
	}

	/**
	 * Get the error object. Used to format the HTTP response.
	 * 
	 * @return Error
	 */
	public Error getError() {
		return error;
	}

	/**
	 * Get the error timestamp.
	 * 
	 * @return timestamp in ISO 8601 format
	 */
	public String getTimestamp() {
		return timestamp;
	}

	/**
	 * Get the request path.
	 * 
	 * @return request path URL
	 */
	public String getPath() {
		return path;
	}
	
	/**
	 * Setter required for JSON conversion
	 * @param path error type code
	 */
	public void setPath(String path) {
		this.path = path;
	}

	/**
	 * Encapsulates an HTTP error. Used to format the HTTP response.
	 */
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@ApiModel(value="Error", description="Error details.")
	public class Error {
		@ApiModelProperty(value = "Classification of the error.")
		private String classification;
		
		@ApiModelProperty(value = "Details of the error.")
		private Object details;

		/**
		 * Construct a new error object.
		 * 
		 * @param classification
		 *            error type (should be documented in a public API)
		 * @param details
		 *            error details
		 */
		public Error(String classification, Object details) {
			this.classification = classification;
			this.details = details;
		}

		/**
		 * Simple constructor for JSON conversion.
		 */
		public Error() {
		}

		/**
		 * Setter required for JSON conversion
		 * 
		 * @param code
		 *            error type code
		 */
		public void setCode(String code) {
			classification = code;
		}

		/**
		 * Setter required for JSON conversion
		 * 
		 * @param details
		 *            error details
		 */
		public void setDetails(Object details) {
			this.details = details;
		}

		/**
		 * Get the error type code
		 * 
		 * @return error type code.
		 */
		public String getCode() {
			return classification;
		}

		/**
		 * Get the error details.
		 * 
		 * @return error details
		 */
		public Object getDetails() {
			return details;
		}
	}
}