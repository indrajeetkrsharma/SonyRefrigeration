package org.poc.laborservice.controllers;

import java.text.ParseException;
import java.util.List;

import org.poc.laborservice.apis.LaborRecordAddInfo;
import org.poc.laborservice.apis.LaborRecordInfo;
import org.poc.laborservice.apis.LaborRecordUpdateInfo;
import org.poc.laborservice.constant.ControllerConstants;
import org.poc.laborservice.exceptions.DateTimeRangeException;
import org.poc.laborservice.exceptions.ErrorCode;
import org.poc.laborservice.exceptions.InvalidInputException;
import org.poc.laborservice.exceptions.ResourceNotFoundException;
import org.poc.laborservice.manager.LaborRecordManager;
import org.poc.laborservice.mappers.assemblers.LaborRecordResourceAssembler;
import org.poc.laborservice.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.PagedResources;
import org.springframework.hateoas.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/v1/laborRecords")
public class LaborRecordController {

	private static final Logger LOGGER = LoggerFactory.getLogger(LaborRecordController.class);

	@Autowired
	private LaborRecordManager manager;

	@Autowired
	private LaborRecordResourceAssembler resourceAssembler;

	@Autowired
	private PagedResourcesAssembler<LaborRecordInfo> pagedResourcesAssembler;
	
	/**
	 * Used to provide a class definition for Swagger
	 */
	private static class LaborRecordInfoResult extends Resource<LaborRecordInfo> {
		public LaborRecordInfoResult(LaborRecordInfo content,
							   @ApiParam(value="Set of links on the resource.", required = true)   Link... links) {
			super(content, links);
		}
	}

	/**
	 * Used to provide a class definition for Swagger 
	 */
	private static class LaborRecordInfoResults extends PagedResources<Resource<LaborRecordInfo>> {
	}
	
	/**
	 * Returns all labor records on the page requested in the Pageable parameter
	 *
	 * @param page
	 *            Defines which page of data to return
	 * @return PagedResources object containing the page of records
	 */

	@ApiOperation(value = "Get labor records", response=LaborRecordInfoResults.class)
    @ApiResponses(value = { 
    		@ApiResponse(code = 401, message = "Unauthorized"),
    		@ApiResponse(code = 500, message = "Internal Server Error", response = HttpErrorResponse.class )
    		})
    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getLaborRecords(
            @RequestParam(required = false) List<String> userName,
            @RequestParam(required = false) List<Long> laborTypeId,
            @RequestParam(required = false) String likeOnColumn,
            @RequestParam(required = false) String likeSearchValue,
            @RequestParam(value = "orderByColumn", defaultValue = "startTime", required = false) String orderByColumn,
            @RequestParam(value = "orderBy", defaultValue = "asc", required = false) String orderBy,
            Pageable page,
            @RequestParam(value = "size", defaultValue = "20", required = false) int size,
            @RequestParam(value = "page", defaultValue = "0", required = false) int pageNo) {

		String requestPath = getRequestPath();

		try {
			LOGGER.info("Request to get all labor records");
	        Page<LaborRecordInfo> laborPage = manager.getLaborRecordsByColumnSearchCriteria(userName, laborTypeId, 
	        		likeOnColumn, likeSearchValue, orderByColumn, orderBy, page);
	        PagedResources<Resource<LaborRecordInfo>> pagedResources = pagedResourcesAssembler
	                .toResource(laborPage, resourceAssembler);
	        LOGGER.info("Completed request to get all labor records");
	        return new ResponseEntity<>(pagedResources, HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, ControllerConstants.INTERNAL_SERVER_ERROR,
					e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

    }

	/**
	 * Get labor record by id
	 *
	 * @param laborRecordId
	 * @return
	 */
	@ApiOperation(value = "Get a labor record by id", response = LaborRecordInfoResult.class)
	@ApiResponses(value = { 
			@ApiResponse(code = 401, message = "Unauthorized", response = HttpErrorResponse.class),
			@ApiResponse(code = 404, message = "Not Found", response = HttpErrorResponse.class ),
			@ApiResponse(code = 500, message = "Internal Server Error", response = HttpErrorResponse.class)
			})
	@RequestMapping(path = "/{laborRecordId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getLaborRecord(
			@ApiParam(value="Id of the labor record", required = true) @PathVariable Long laborRecordId,
			Authentication authentication) {

		String requestPath = getRequestPath();

		try {
			LOGGER.debug("+get labor record");
			LaborRecordInfo laborRecordInfo = manager.getLaborRecord(laborRecordId);
			Resource<LaborRecordInfo> laborRecordResource = resourceAssembler.toResource(laborRecordInfo);
			LOGGER.debug("-get labor record");
			return new ResponseEntity<>(laborRecordResource, HttpStatus.OK);
		} catch (ResourceNotFoundException e) {
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, e.getErrorCode().name(), e.getMessage()),
					HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, ControllerConstants.INTERNAL_SERVER_ERROR,
					e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@ApiOperation(value = "Create Labor Record")
	@ResponseStatus(value = HttpStatus.CREATED)
	@ApiResponses(value = {
			@ApiResponse(code = 201, message = "Created", response = LaborRecordInfo.class),
			@ApiResponse(code = 422, message = "Unprocessable Entity", response = HttpErrorResponse.class),
			@ApiResponse(code = 400, message = "Bad Request", response = HttpErrorResponse.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = HttpErrorResponse.class)
			})
	@RequestMapping(name = "/", method = RequestMethod.POST, 
	produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> createLaborRecord(
			@ApiParam(value = "Details of the labor record to create", required = true) @RequestBody LaborRecordAddInfo laborRecordAddInfo,
			Authentication authentication) {

		String requestPath = getRequestPath();
		String errorMessage = null;

		try {

			String logContext = "Labor Record details ==> " + laborRecordAddInfo;
			LOGGER.debug("+" + logContext);
	
			//  checking required fields below
			if (laborRecordAddInfo.getLaborTypeId() == null || 
					laborRecordAddInfo.getLaborTypeId() == 0L || 
					laborRecordAddInfo.getLaborTypeId() < 0L) {
				LOGGER.error(ControllerConstants.LABOR_TYPE_ID_NULLCHECK_MESSAGE);
				if (errorMessage == null) { 
					errorMessage = ControllerConstants.LABOR_TYPE_ID_NULLCHECK_MESSAGE;
				} 
				//else {
				//	errorMessage = errorMessage + "; " + ControllerConstants.LABOR_TYPE_ID_NULLCHECK_MESSAGE;
				//}	

			}
	
			if (laborRecordAddInfo.getSegmentActualId() == null || 
					laborRecordAddInfo.getSegmentActualId() == 0L || 
					laborRecordAddInfo.getSegmentActualId() < 0L) {
				LOGGER.error(ControllerConstants.SEGMENT_ACTUAL_ID_NULLCHECK_MESSAGE);
				if (errorMessage == null) { 
					errorMessage = ControllerConstants.SEGMENT_ACTUAL_ID_NULLCHECK_MESSAGE;
				} else {
					errorMessage = errorMessage + "; " + ControllerConstants.SEGMENT_ACTUAL_ID_NULLCHECK_MESSAGE;
				}	
				
			}
	
			if (StringUtils.isEmpty(laborRecordAddInfo.getUserName())) {
				LOGGER.error(ControllerConstants.USER_NAME_NULLCHECK_MESSAGE);
				if (errorMessage == null) { 
					errorMessage = ControllerConstants.USER_NAME_NULLCHECK_MESSAGE;
				} else {
					errorMessage = errorMessage + "; " + ControllerConstants.USER_NAME_NULLCHECK_MESSAGE;
				}	
				
			}

			if (StringUtils.isEmpty(laborRecordAddInfo.getCreatedBy())) {
				LOGGER.error(ControllerConstants.CREATED_BY_NULLCHECK_MESSAGE);
				if (errorMessage == null) { 
					errorMessage = ControllerConstants.CREATED_BY_NULLCHECK_MESSAGE;
				} else {
					errorMessage = errorMessage + "; " + ControllerConstants.CREATED_BY_NULLCHECK_MESSAGE;
				}	
			}

			// StartTime and EndTime validation against ISO 8601
			// "yyyy-MM-dd'T'HH:mm:ss.fff'Z'"
			if (StringUtils.isEmpty(laborRecordAddInfo.getStartTime())) {
				LOGGER.error(ControllerConstants.START_DATE_TIME_NULLCHECK_MESSAGE);
				if (errorMessage == null) { 
					errorMessage = ControllerConstants.START_DATE_TIME_NULLCHECK_MESSAGE;
				} else {
					errorMessage = errorMessage + "; " + ControllerConstants.START_DATE_TIME_NULLCHECK_MESSAGE;
				}	
				
			} else {			
				if (!DateUtil.isValidISO8601DateString(laborRecordAddInfo.getStartTime())) {
					LOGGER.error(ControllerConstants.DATE_TIME_FORMAT_ERROR);
					if (errorMessage == null) { 
						errorMessage = ControllerConstants.DATE_TIME_FORMAT_ERROR;
					} else {
						errorMessage = errorMessage + "; " + ControllerConstants.DATE_TIME_FORMAT_ERROR;
					}	
				}
				else {
					if (!StringUtils.isEmpty(laborRecordAddInfo.getEndTime())) {
						if (!DateUtil.isValidISO8601DateString(laborRecordAddInfo.getEndTime())) {
							if (errorMessage == null) { 
								errorMessage = ControllerConstants.DATE_TIME_FORMAT_ERROR;
							} else {
								errorMessage = errorMessage + "; " + ControllerConstants.DATE_TIME_FORMAT_ERROR;
							}	
						}
						else {
							if (!DateUtil.isValidDateRange(laborRecordAddInfo.getStartTime(), laborRecordAddInfo.getEndTime())) {
								LOGGER.error(ControllerConstants.START_DATE_TIME_AND_END_DATE_TIME_CHECK_MESSAGE);
								if (errorMessage == null) { 
									errorMessage = ControllerConstants.START_DATE_TIME_AND_END_DATE_TIME_CHECK_MESSAGE;
								} else {
									errorMessage = errorMessage + "; " + ControllerConstants.START_DATE_TIME_AND_END_DATE_TIME_CHECK_MESSAGE;
								}	
	
							}
						}
					}
				}
			}
			
			// all inputs have been checked, if error found, throw it
			if (errorMessage != null) {
				throw new InvalidInputException(errorMessage);
			}

			// use manager class to create labor record
			LaborRecordInfo laborRecordCreated = manager.createLaborRecord(laborRecordAddInfo, authentication);
			//LOGGER.debug(laborRecordCreated.toString());
			Resource<LaborRecordInfo> laborRecordResource = resourceAssembler.toResource(laborRecordCreated);
			

			LOGGER.debug("LaborRecord successfully created : " + laborRecordCreated);
			LOGGER.debug("-" + logContext);
			return new ResponseEntity<>(laborRecordResource, HttpStatus.CREATED);
			
		} catch (InvalidInputException e) {
			LOGGER.error(errorMessage);
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, e.getErrorCode().name(),
					e.getMessage()), HttpStatus.BAD_REQUEST);			
		} catch (DataIntegrityViolationException e) {
			LOGGER.error(ControllerConstants.DATA_ACCESS_VIOLATION_ERROR);
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, ControllerConstants.DATA_ACCESS_VIOLATION_ERROR,
					e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, ControllerConstants.INTERNAL_SERVER_ERROR,
					e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Update labor record with a PUT to /laborRecords with JSON body containing a
	 * labor record object
	 * 
	 * @param input LaborRecordInfo object
	 * @throws ParseException
	 */

	@ApiOperation(value = "Update labor record", response = LaborRecordInfo.class)
	@ResponseStatus(value = HttpStatus.OK)
	@ApiResponses(value = {
			@ApiResponse(code = 400, message = "Bad Request", response = HttpErrorResponse.class),
			@ApiResponse(code = 404, message = "Not Found", response = HttpErrorResponse.class),
			@ApiResponse(code = 422, message = "Unprocessable Entity", response = HttpErrorResponse.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = HttpErrorResponse.class),
			})
	@RequestMapping(path = "/{laborRecordId}", method = RequestMethod.PUT, 
	consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateLaborRecord(
			@ApiParam(value = "Labor Record Id", required = true) @PathVariable Long laborRecordId,
			@ApiParam(value = "Update Labor Record", required = true) @RequestBody LaborRecordUpdateInfo laborRecordUpdateInfo,
			Authentication authentication) {

		String requestPath = getRequestPath();
		String errorMessage = null;

		try {

			String logContext = "Update labor record=" + laborRecordId + " details= "
					+ laborRecordUpdateInfo;
			LOGGER.debug("+" + logContext);
			
			if (StringUtils.isEmpty(laborRecordUpdateInfo.getUserName())) {
				LOGGER.error(ControllerConstants.USER_NAME_NULLCHECK_MESSAGE);
				if (errorMessage == null) { 
					errorMessage = ControllerConstants.USER_NAME_NULLCHECK_MESSAGE;
				} 
				//else {
				//	errorMessage = errorMessage + "; " + ControllerConstants.USER_NAME_NULLCHECK_MESSAGE;
				//}				
				
			}


			if (StringUtils.isEmpty(laborRecordUpdateInfo.getModifiedBy())) {
				LOGGER.error(ControllerConstants.MODIFIED_BY_NULLCHECK_MESSAGE);
				if (errorMessage == null) { 
					errorMessage = ControllerConstants.MODIFIED_BY_NULLCHECK_MESSAGE;
				} else {
					errorMessage = errorMessage + "; " + ControllerConstants.MODIFIED_BY_NULLCHECK_MESSAGE;
				}				
				
			}

			if (StringUtils.isEmpty(laborRecordUpdateInfo.getEndTime())) {
				LOGGER.error(ControllerConstants.END_DATE_TIME_NULLCHECK_MESSAGE);
				if (errorMessage == null) { 
					errorMessage = ControllerConstants.END_DATE_TIME_NULLCHECK_MESSAGE;
				} else {
					errorMessage = errorMessage + "; " + ControllerConstants.END_DATE_TIME_NULLCHECK_MESSAGE;
				}				
			} else {
	
				if (!DateUtil.isValidISO8601DateString(laborRecordUpdateInfo.getEndTime())) {
					LOGGER.error(ControllerConstants.DATE_TIME_FORMAT_ERROR);
					if (errorMessage == null) { 
						errorMessage = ControllerConstants.DATE_TIME_FORMAT_ERROR;
					} else {
						errorMessage = errorMessage + "; " + ControllerConstants.DATE_TIME_FORMAT_ERROR;
					}	
				}
			}
			
			// all inputs have been checked, if error found, throw it
			if (errorMessage != null) {
				throw new InvalidInputException(errorMessage);
			}
			// use manager class to update labor record
			LaborRecordInfo laborRecordInfo = manager.updateLaborRecord(laborRecordId, laborRecordUpdateInfo,
					authentication);
			Resource<LaborRecordInfo> laborRecordResource = resourceAssembler.toResource(laborRecordInfo);

			LOGGER.debug("-" + logContext);
			return new ResponseEntity<>(laborRecordResource, HttpStatus.OK);
		} catch (InvalidInputException e) {
			LOGGER.error(errorMessage);
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, e.getErrorCode().name(),
					e.getMessage()), HttpStatus.BAD_REQUEST);

		} catch (DataIntegrityViolationException e) {
			LOGGER.error(ControllerConstants.DATA_ACCESS_VIOLATION_ERROR);
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, ControllerConstants.DATA_ACCESS_VIOLATION_ERROR,
					e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (ResourceNotFoundException e) {
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, e.getErrorCode().name(), e.getMessage()),
					HttpStatus.NOT_FOUND);
		} catch (DateTimeRangeException e) {
			LOGGER.error(ControllerConstants.START_DATE_TIME_AND_END_DATE_TIME_CHECK_MESSAGE);
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, ErrorCode.InvalidInput.name(),
					ControllerConstants.START_DATE_TIME_AND_END_DATE_TIME_CHECK_MESSAGE), HttpStatus.BAD_REQUEST);			
		}  catch (Exception e) {
			LOGGER.error(e.getMessage());
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, ControllerConstants.INTERNAL_SERVER_ERROR,
					e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Delete a labor record with a DELETE to /laborRecordId
	 *
	 * @param laborRecordId
	 * 
	 * @return 204
	 */ 
	@ApiOperation(value = "Delete a labor record")
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	@ApiResponses(value = { 
			@ApiResponse(code = 404, message = "Not Found", response = HttpErrorResponse.class),
			@ApiResponse(code = 500, message = "Internal Server Error", response = HttpErrorResponse.class) 
			})
	@RequestMapping(path = "/{laborRecordId}", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteLaborRecord(
			@ApiParam(value = "Labor record Id to be deleted", required = true) @PathVariable Long laborRecordId,
			Authentication authentication) {
		String requestPath = getRequestPath();
		try {
			LOGGER.debug("+delete labor record");
			manager.deleteLaborRecord(laborRecordId);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (ResourceNotFoundException e) {
			LOGGER.error(ControllerConstants.DELETE_LABOR_ERROR);
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, e.getErrorCode().name(), e.getMessage()),
					HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			return new ResponseEntity<>(new HttpErrorResponse(requestPath, ControllerConstants.INTERNAL_SERVER_ERROR,
					e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Return the URI from the current request. Returns null if there is no current
	 * request
	 * 
	 * @return URI from the current request.
	 */
	private String getRequestPath() {
		return ServletUriComponentsBuilder.fromCurrentRequest().build().getPath();
	}
}