package org.poc.laborservice.config;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.poc.laborservice.springextension.BuilderCache;
import org.springframework.context.annotation.Bean;

public class ConverterConfig  {

	@Bean
	public ModelMapper modelMapper() {
		ModelMapper mapper = new ModelMapper();

		// Strict mapping strategy ensures that only properties who names match exactly
		// are considered for mapping.
		// Without it you can get a property named getOriginId mapped to a property
		// named getId. Not ideal.
		// See http://modelmapper.org/user-manual/configuration/#matching-strategies
		mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		return mapper;
	}

	@Bean
	public BuilderCache builderCache() {
		BuilderCache builder = new BuilderCache();
		return builder;
	}
}
