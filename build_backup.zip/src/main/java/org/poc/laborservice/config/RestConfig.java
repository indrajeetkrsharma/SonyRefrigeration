package org.poc.laborservice.config;

import java.util.Collections;

import javax.servlet.http.HttpServletRequest;

import org.poc.laborservice.springextension.UaaTokenClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

/**
 * Provide a RestTemplate that contains the authorization token from the current request.
 * This allows one to make child requests using the authorization token of a parent request.
 */
@Configuration
public class RestConfig {

	@Autowired
	private HttpServletRequest servletRequest;

	@Autowired
	private UaaTokenClient tokenClient;


	/**
	 * RestTemplate bean, initialized to use access token for authentication on all requests
	 * @return rest template instance
	 */
	@Bean
	public RestTemplate restTemplate() {
		RestTemplate restTemplate = new RestTemplate();
		//Read the token off of the current request and forward it along on any requests made with this template
		// (replacing any existing authorization header)
		restTemplate.setInterceptors(Collections.singletonList((request, body, execution) -> {
			if(servletRequest != null) {
				String authorization = null;
				try {
					authorization = servletRequest.getHeader(HttpHeaders.AUTHORIZATION);

					if (authorization != null) {
						request.getHeaders().put(HttpHeaders.AUTHORIZATION, Collections.singletonList(authorization));
					}
				} catch (IllegalStateException ex) {
					//if there is no current servletRequest, attempting to retrieve headers off of it will throw an
					//IllegalStateException.

					//IF we don't already have an auth header on our rest template (can occur when we make multiple rest calls
					//in one thread

					if(!request.getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
						//AND IF we have a cached token
						String accessToken = tokenClient.getServiceUserToken().getAccessToken();
						if(accessToken != null) {
							//THEN add the token to our rest template
							request.getHeaders().put(HttpHeaders.AUTHORIZATION, Collections.singletonList("Bearer " + accessToken));
						}
					}
				}
			}
			request.getHeaders().put(HttpHeaders.CONTENT_TYPE, Collections.singletonList("application/json"));
			return execution.execute(request, body);
		}));
		return restTemplate;
	}

	/**
	 * RestTemplate that does not attempt authorization
	 * @return rest template
	 */
	@Bean
	public RestTemplate noAuthRestTemplate() {
		return new RestTemplate();
	}


}
