package org.poc.laborservice.config;

import org.poc.laborservice.springextension.OAuth2ResourceServerConfigurerAdapter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

@Configuration
@EnableResourceServer
public class SecurityConfig extends OAuth2ResourceServerConfigurerAdapter {

	@Value("${labor.service.openapi.path}")
	private String openapiPath;

	@Value("${springfox.documentation.swagger.v2.path}")
	private String swaggerPath;

	@Override
	public void configure(HttpSecurity http) throws Exception {
		// http.authorizeRequests().anyRequest().permitAll();
		http.authorizeRequests()
				// These are opened up to support swagger doc access without a token
				.antMatchers(HttpMethod.GET,
						openapiPath + swaggerPath + "/**",
						openapiPath + "/swagger-resources/**",
						openapiPath + "/swagger-ui.html",
						openapiPath + "/webjars/**",
						swaggerPath + "/**",
						"/swagger-resources/**",
						"/swagger-ui.html",
						"/webjars/**")
				.permitAll()
				.antMatchers(HttpMethod.GET).authenticated()
				.antMatchers(HttpMethod.POST).authenticated()
				.antMatchers(HttpMethod.PUT).authenticated()
				.antMatchers(HttpMethod.PATCH).authenticated()
				.antMatchers(HttpMethod.DELETE).authenticated()
				.and().exceptionHandling().authenticationEntryPoint((request, response, accessDeniedException) -> response
						.sendError(HttpStatus.UNAUTHORIZED.value(), accessDeniedException.getMessage()));

	}
}
