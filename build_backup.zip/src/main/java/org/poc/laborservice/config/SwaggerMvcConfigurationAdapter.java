package org.poc.laborservice.config;

import org.poc.laborservice.Application;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.util.UriComponentsBuilder;

public class SwaggerMvcConfigurationAdapter  extends WebMvcConfigurerAdapter {
	@Value("${labor.service.openapi.path}")
	private String openapiPath;

	@Value("${springfox.documentation.swagger.v2.path}")
	private String swaggerPath;

	public static final Logger LOGGER = LoggerFactory.getLogger(Application.class);

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		super.addViewControllers(registry);

		// Setup redirects for the swagger resource to put it under the requested api docs base path.
		// See https://github.com/springfox/springfox/issues/1080#issuecomment-169185653
		// Swagger-ui expects the Swagger API data to be under itself at swaggerPath but actually lives
		// at just swaggerPath.
		// If these redirects fail, the online documentation shows 'Failed to load API definition'
		registerSubPathRedirect(registry, openapiPath, swaggerPath);
		registerSubPathRedirect(registry, openapiPath, "/swagger-resources/configuration/ui");
		registerSubPathRedirect(registry, openapiPath, "/swagger-resources/configuration/security");
		registerSubPathRedirect(registry, openapiPath, "/swagger-resources");
		LOGGER.debug("Using mes.service.openapi.path='{}'", openapiPath);
		LOGGER.debug("Using springfox.documentation.swagger.v2.path='{}'", swaggerPath);
		LOGGER.info("Swagger API.JSON available at '{}{}'", openapiPath, swaggerPath);
	}

	/**
	 * Register a redirect from a subpath of the root to a subpath of a subpath.
	 * @param registry ViewControllerRegistry
	 * @param newRootPath New root path for the subpath
	 * @param subPath Subpath to be redirected under newRootPath
	 */
	private void registerSubPathRedirect(ViewControllerRegistry registry, String newRootPath, String subPath) {
		// Use UriComponentsBuilder to normalize, clean up extra spaces and slashes, handle encoding etc.
		registry.addRedirectViewController(
				UriComponentsBuilder.fromPath(newRootPath).path(subPath).build().getPath(),
				UriComponentsBuilder.fromPath(subPath).build().getPath());
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		super.addResourceHandlers(registry);

		// Setup redirects for the swagger resource to put it under the requested api docs base path.
		// The webjars are part of the springfox-swagger-ui component.
		registry.addResourceHandler(
				UriComponentsBuilder.fromPath(openapiPath).path("/swagger-ui.html**").build().getPath())
				.addResourceLocations("classpath:/META-INF/resources/swagger-ui.html");
		registry.addResourceHandler(
				UriComponentsBuilder.fromPath(openapiPath).path("/webjars/**").build().getPath())
				.addResourceLocations("classpath:/META-INF/resources/webjars/");
		LOGGER.info("Online api documentation is available at '{}/swagger-ui.html'",
				openapiPath);
	}
}
