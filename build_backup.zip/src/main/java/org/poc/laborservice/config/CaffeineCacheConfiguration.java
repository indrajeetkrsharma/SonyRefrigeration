package org.poc.laborservice.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.github.benmanes.caffeine.cache.CaffeineSpec;

@Configuration
@EnableCaching
public class CaffeineCacheConfiguration {
	
	@Value("#{'${maximumMaterialCacheSize}'.trim()}")
	private int maximumMaterialCacheSize;
	
	@Value("#{'${cacheMaterialExpireAfterAccess}'.trim()}")
	private String cacheMaterialExpireAfterAccess;


	@Bean
	public CaffeineCacheManager sdsCacheManager() {

		CaffeineCacheManager manager = new CaffeineCacheManager();
		CaffeineSpec spec = CaffeineSpec
				.parse("maximumSize=" + maximumMaterialCacheSize + ",expireAfterWrite=" + cacheMaterialExpireAfterAccess);
		manager.setCaffeineSpec(spec);
		return manager;

	}
}
