package org.poc.laborservice.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.orm.jpa.JpaBaseConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.vendor.AbstractJpaVendorAdapter;
import org.springframework.orm.jpa.vendor.OpenJpaVendorAdapter;
import org.springframework.transaction.jta.JtaTransactionManager;

@Configuration
public class DataSourceConfiguration extends JpaBaseConfiguration {
	@Value("${ls.openjpa.jdbc.MappingDefaults}")
	private String mappingDefaults;

	@Value("${ls.openjpa.jdbc.Schema}")
	private String dbSchema;

	@Value("${ls.openjpa.jdbc.SynchronizeMapping}")
	private String syncMappings;

	@Value("${ls.openjpa.RuntimeUnenhancedClasses}")
	private String unenhancedClasses;

	@Value("${ls.openjpa.DynamicEnhancementAgent}")
	private String dynamicEnhanceAgent;
	
	@Value("${ls.openjpa.jdbc.SchemaFactory}")
	private String schemaFactory;

	/**
	 * @param dataSource                    dataSource
	 * @param properties                    properties
	 * @param jtaTransactionManager         jtaTransactionManager
	 * @param transactionManagerCustomizers transactionManagerCustomizers
	 */
	protected DataSourceConfiguration(DataSource dataSource, JpaProperties properties,
			ObjectProvider<JtaTransactionManager> jtaTransactionManager,
			ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
		super(dataSource, properties, jtaTransactionManager, transactionManagerCustomizers);
	}

	/**
	 * Create JPAVendorAdapter
	 * 
	 * @return jpaVendorAdapter
	 */
	@Override
	protected AbstractJpaVendorAdapter createJpaVendorAdapter() {
		OpenJpaVendorAdapter jpaVendorAdapter = new OpenJpaVendorAdapter();
		jpaVendorAdapter.setShowSql(true);
		return jpaVendorAdapter;
	}

	/**
	 * Set openJPA Properties
	 * 
	 * @return properties map
	 */
	@Override
	protected Map<String, Object> getVendorProperties() {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("openjpa.jdbc.MappingDefaults", mappingDefaults);
		map.put("openjpa.jdbc.SynchronizeMappings", syncMappings);
		map.put("openjpa.jdbc.Schema", dbSchema);
		map.put("openjpa.jdbc.SchemaFactory", schemaFactory);
		map.put("openjpa.RuntimeUnenhancedClasses", unenhancedClasses);
		map.put("openjpa.DynamicEnhancementAgent", dynamicEnhanceAgent);
		
		return map;
	}

}
