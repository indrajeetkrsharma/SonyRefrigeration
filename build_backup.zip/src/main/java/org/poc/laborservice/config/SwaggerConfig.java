package org.poc.laborservice.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.util.UriComponentsBuilder;

import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.AuthorizationCodeGrant;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.ClientCredentialsGrant;
import springfox.documentation.service.GrantType;
import springfox.documentation.service.ImplicitGrant;
import springfox.documentation.service.LoginEndpoint;
import springfox.documentation.service.OAuth;
import springfox.documentation.service.ResourceOwnerPasswordCredentialsGrant;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.service.TokenEndpoint;
import springfox.documentation.service.TokenRequestEndpoint;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

	@Value("${uaa.service.origin}")
	private String uaaOrigin;

	/**
	 * Security scheme names
	 */
	private String accessTokenSchemeName = "access_token";
	private String clientCredentialSchemeName = "client_creds";
	private String resourceOwnerPasswordSchemeName = "resource_owner";
	private String implicitGrantSchemeName = "implicit_grant";

	/**
	 * Swagger needs a scope. Authorization using UAA is not currently implemented
	 * so just provide a default.
	 */
	private AuthorizationScope defaultScope = new AuthorizationScope("default", "Default oauth2 scope.");

	/**
	 * Swagger bean
	 * 
	 * @return bean
	 */
	@Bean
	public Docket api() {
		// License and other info can go into the ApiInfo. Adding just the name for now.
		ApiInfo apiInfo = new ApiInfo("labor-service",
				"Microservice containing the business logic for managing labor-service." + "\n\n"
						+ "Descriptions of these functions can be found in the section headers for each collection of "
						+ "relevant resources.",
				null, null, null, null, null, new ArrayList<>());
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.ge.bm.laborservice")).paths(PathSelectors.any())
				.build().apiInfo(apiInfo).securitySchemes(oauthScheme()).securityContexts(securityContexts())
				.useDefaultResponseMessages(false);
	}

	private List<SecurityContext> securityContexts() {
		List<SecurityContext> securityContexts = new ArrayList<>();
		securityContexts
				.add(SecurityContext.builder().securityReferences(defaultAuth()).forPaths(PathSelectors.any()).build());
		return securityContexts;
	}

	private List<SecurityReference> defaultAuth() {
		AuthorizationScope[] authorizationScopes = { defaultScope };
		List<SecurityReference> securityReferences = new ArrayList<>();
		securityReferences.add(new SecurityReference(accessTokenSchemeName, authorizationScopes));
		securityReferences.add(new SecurityReference(clientCredentialSchemeName, authorizationScopes));
		securityReferences.add(new SecurityReference(resourceOwnerPasswordSchemeName, authorizationScopes));
		securityReferences.add(new SecurityReference(implicitGrantSchemeName, authorizationScopes));
		return securityReferences;
	}

	private List<SecurityScheme> oauthScheme() {
		List<SecurityScheme> securitySchemes = new ArrayList<>();
		List<AuthorizationScope> authorizationScopes = new ArrayList<>();
		authorizationScopes.add(defaultScope);
		// workaround for http to https
		//SSLUtil.disableSslVerification(); // not for production

		// Setup Auth code grant
		UriComponentsBuilder authorizeUriBuilder = UriComponentsBuilder.fromHttpUrl(uaaOrigin).pathSegment("oauth",
				"authorize");
		TokenRequestEndpoint requestEndpoint = new TokenRequestEndpoint(authorizeUriBuilder.toUriString(), null, null);
		UriComponentsBuilder tokenUriBuilder = UriComponentsBuilder.fromHttpUrl(uaaOrigin).pathSegment("oauth",
				"token");
		TokenEndpoint tokenEndpoint = new TokenEndpoint(tokenUriBuilder.toUriString(), "access_token");
		GrantType authorizationCodeGrant = new AuthorizationCodeGrant(requestEndpoint, tokenEndpoint);
		List<GrantType> authCodeGrantTypes = new ArrayList<>();
		authCodeGrantTypes.add(authorizationCodeGrant);
		securitySchemes.add(new OAuth(accessTokenSchemeName, authorizationScopes, authCodeGrantTypes));

		// Setup client credentials grant
		GrantType clientCredentialsGrant = new ClientCredentialsGrant(tokenUriBuilder.toUriString());
		List<GrantType> clientCredentialGrantTypes = new ArrayList<>();
		clientCredentialGrantTypes.add(clientCredentialsGrant);
		securitySchemes.add(new OAuth(clientCredentialSchemeName, authorizationScopes, clientCredentialGrantTypes));

		// Setup Resource Owner Password Grant
		GrantType resourceOwnerGrant = new ResourceOwnerPasswordCredentialsGrant(tokenUriBuilder.toUriString());
		List<GrantType> resourceOwnerGrantTypes = new ArrayList<>();
		resourceOwnerGrantTypes.add(resourceOwnerGrant);
		securitySchemes.add(new OAuth(resourceOwnerPasswordSchemeName, authorizationScopes, resourceOwnerGrantTypes));

		// Setup implicit grant
		LoginEndpoint loginEndpoint = new LoginEndpoint(authorizeUriBuilder.toUriString());
		GrantType implicitGrant = new ImplicitGrant(loginEndpoint, "login");
		List<GrantType> implicitGrantTypes = new ArrayList<>();
		implicitGrantTypes.add(implicitGrant);
		securitySchemes.add(new OAuth(implicitGrantSchemeName, authorizationScopes, implicitGrantTypes));

		return securitySchemes;
	}

}