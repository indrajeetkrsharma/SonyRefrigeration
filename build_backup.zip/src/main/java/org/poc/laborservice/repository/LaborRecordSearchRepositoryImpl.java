package org.poc.laborservice.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.poc.laborservice.apis.LaborRecordInfo;
import org.poc.laborservice.mappers.builders.LaborRecordBuilder;
import org.poc.laborservice.models.LaborRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

@Repository
public class LaborRecordSearchRepositoryImpl implements ILaborRecordSearchRepository {

	private static final Logger LOGGER = LoggerFactory.getLogger(LaborRecordSearchRepositoryImpl.class);

	@PersistenceContext
	private EntityManager em;

	@Autowired
	private LaborRecordBuilder laborRecordBuilder;
	
//	@Transactional
//	public List<LaborRecord> findLaborRecordsBySearchCriteria(LaborRecordInfo info, Pageable page) {
//
//		CriteriaBuilder cb = em.getCriteriaBuilder();
//		CriteriaQuery<LaborRecord> cq = cb.createQuery(LaborRecord.class);
//
//		Root<LaborRecord> laborRoot = cq.from(LaborRecord.class);
//		List<Predicate> predicates = new ArrayList<>();
//
//		if (info.getUserName() != null && !StringUtils.isEmpty(info.getUserName())) {
//			String userName=info.getUserName();
//			if(userName.contains("%"))
//			{
//				userName=userName.replaceAll("%", "[%]");
//			}
//			predicates.add(cb.like(laborRoot.get("userName"), "%" + userName + "%"));
//		}
//		if (info.getLaborTypeId() != null && info.getLaborTypeId() != 0) {
//			predicates.add(cb.equal(laborRoot.get("laborTypeId"), info.getLaborTypeId()));
//		}
//
//		cq.where(predicates.toArray(new Predicate[0]));
//		cq.orderBy(toOrders(page.getSort(), laborRoot, cb));
//		LOGGER.info("LaborRecordSearchRepositoryImpl::findLaborRecordsBySearchCriteria-SearchLaborRecordsQuery: " + cq);
//
//		return em.createQuery(cq).getResultList();
//	}

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Page<LaborRecordInfo> findLaborRecordsByColumnSearch(List<String> userName, List<Long> laborTypeId, 
			String likeOnColumn, String likeSearchValue, String orderByColumn, String orderBy,
			Pageable pageable) {

		LOGGER.debug("++get Labor Records From DB");

		List<Order> orderList = new ArrayList<Order>();
		CriteriaBuilder cb = em.getCriteriaBuilder();

		Predicate userNamePredicate = cb.and();
		Predicate laborTypeIdPredicate = cb.and();
		Predicate likeColPredicate = cb.and();
		Predicate combinedPredicate = cb.conjunction();
		CriteriaQuery<Long> countCriteria = cb.createQuery(Long.class);

		Root  root = null;
		CriteriaQuery  cq;

		countCriteria.select(cb.count(countCriteria.from(LaborRecord.class)));
		cq = cb.createQuery(LaborRecord.class);
		root = cq.from(LaborRecord.class);


		if (!orderByColumn.isEmpty() && orderByColumn != null) {
			if (orderBy.equals("asc")) {
				orderList.add(cb.asc(root.get(orderByColumn)));
			} else {
				orderList.add(cb.desc(root.get(orderByColumn)));
			}
		}
		//// Where condition-------> starts

		if (userName != null) {
			userNamePredicate = cb.in(root.get("userName")).value(userName);
		}
		if (laborTypeId != null) {
			laborTypeIdPredicate = cb.in(root.get("laborTypeId")).value(laborTypeId);
		}
		if (likeOnColumn != null) {
			likeColPredicate = cb.like(root.<String>get(likeOnColumn), "%" + likeSearchValue + "%");
		}
		combinedPredicate = cb.and(userNamePredicate, laborTypeIdPredicate, likeColPredicate);
		cq.select(root).where(combinedPredicate).orderBy(orderList);
		countCriteria.where(combinedPredicate);
		TypedQuery typedQuery = em.createQuery(cq);
		Long totalPages = em.createQuery(countCriteria).getSingleResult();
		LOGGER.debug("pages:" + totalPages);
		// Getting the result list according to the pageable meta data
		List laborRecordList = typedQuery.setMaxResults(pageable.getPageSize())
				.setFirstResult((pageable.getPageNumber()) * (pageable.getPageSize())).getResultList();
		List<LaborRecordInfo> infos = new ArrayList<LaborRecordInfo>();
		
		infos = laborRecordBuilder.buildInfos(laborRecordList);

		return new PageImpl<>(infos, pageable, totalPages);
	}
}

