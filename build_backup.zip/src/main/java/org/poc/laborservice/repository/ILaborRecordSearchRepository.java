package org.poc.laborservice.repository;

import java.util.List;

import org.poc.laborservice.apis.LaborRecordInfo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ILaborRecordSearchRepository {

	Page<LaborRecordInfo> findLaborRecordsByColumnSearch(List<String> userName, List<Long> laborTypeId, 
														String likeOnColumn, String likeSearchValue, 
														String orderByColumn, String orderBy,Pageable pageable);

//	List<LaborRecord> findLaborRecordsBySearchCriteria(LaborRecordInfo info,Pageable page);
//
//	Page<String> findDistinctColumnResultSet(String columnName, String searchValue, String orderBy,
//                                             List<String> userName, List<Long> laborTypeId, Pageable pageable);

}
