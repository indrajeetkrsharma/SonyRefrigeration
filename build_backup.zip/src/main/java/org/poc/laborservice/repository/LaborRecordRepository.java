package org.poc.laborservice.repository;

import org.poc.laborservice.models.LaborRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LaborRecordRepository extends JpaRepository<LaborRecord, Long> {
}
