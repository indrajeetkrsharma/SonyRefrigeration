package org.poc.laborservice.apis;

import org.springframework.hateoas.Identifiable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "LaborRecordUpdateInfo", description = "Labor Record update data tranfer object ")
public class LaborRecordUpdateInfo implements Identifiable<Long> {

	@ApiModelProperty(value = "id of the laborRecord ", hidden = true)
	private Long id;

	// Below annotation not validating complete Date format, its only validating Z
	// suffix,
	// So as of now we are using endTime data type as string and validating through
	// regular expression.
	// @JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.fff'Z'")
	@ApiModelProperty(value = "end time for the labor record", required = true)
	private String endTime;

	@ApiModelProperty(value = "applied time for the labor record", required = true)
	private Long appliedTime;

	@ApiModelProperty(value = "user name for the labor record", required = true)
	private String userName;
	
	@ApiModelProperty(value = "modified by for the labor record", required = true)
	private String modifiedBy;

	/*
	 * Default Constructor
	 */
	public LaborRecordUpdateInfo() {

	}

	public LaborRecordUpdateInfo(Long id, String endTime, Long appliedTime, String userName, String modifiedBy) {
		this.id = id;
		this.endTime = endTime;
		this.appliedTime = appliedTime;
		this.userName = userName;
		this.modifiedBy = modifiedBy;
	}


}
