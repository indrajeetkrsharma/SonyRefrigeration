package org.poc.laborservice.apis;

import org.springframework.hateoas.Identifiable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "LaborRecordInfo", description = "Labor Record data tranfer object ")
public class LaborRecordInfo implements Identifiable<Long> {

	@ApiModelProperty(value = "id of the labor record")
	private Long id;
	@ApiModelProperty(value = "segment actual id of the labor record")
	private Long segmentActualId;
	@ApiModelProperty(value = "start time for the labor record")
	private String startTime;
	@ApiModelProperty(value = "end time for the labor record")
	private String endTime;
	@ApiModelProperty(value = "applied time for the labor record")
	private Long appliedTime;
	@ApiModelProperty(value = "labor type id for the labor record")
	private Long laborTypeId;
	@ApiModelProperty(value = "user name for the labor record")
	private String userName;
	@ApiModelProperty(value = "created on date/time for the labor record")
	private String createdOn;
	@ApiModelProperty(value = "created by for the labor record")
	private String createdBy;
	@ApiModelProperty(value = "modified on date/time for the labor record")
	private String modifiedOn;
	@ApiModelProperty(value = "modified by for the labor record")
	private String modifiedBy;
	
	/*
	 * Default Constructor
	 */
	public LaborRecordInfo() {
	}

	public LaborRecordInfo(Long id, Long segmentActualId, String startTime, String endTime, 
			Long appliedTime, Long laborTypeId, String userName,
			String createdOn, String createdBy, String modifiedOn, String modifiedBy) {
		this.id = id;
		this.segmentActualId = segmentActualId;
		this.startTime = startTime;
		this.endTime = endTime;
		this.appliedTime = appliedTime;
		this.laborTypeId = laborTypeId;
		this.userName = userName;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.modifiedOn = modifiedOn;
		this.modifiedBy = modifiedBy;
	}


}