package org.poc.laborservice.apis;

import org.springframework.hateoas.Identifiable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "LaborRecordAddInfo", description = "Labor Record add data tranfer object ")
public class LaborRecordAddInfo implements Identifiable<Long> {

	@ApiModelProperty(value = "id of the laborRecord ", hidden = true)
	private Long id;
	
	@ApiModelProperty(value = "segment actual id of the labor record", required = true)
	private Long segmentActualId;
	@ApiModelProperty(value = "start time for the labor record", required = true)
	private String startTime;
	@ApiModelProperty(value = "end time for the labor record")
	private String endTime;
	@ApiModelProperty(value = "applied time for the labor record")
	private Long appliedTime;
	@ApiModelProperty(value = "labor type id for the labor record", required = true)
	private Long laborTypeId;
	@ApiModelProperty(value = "user name for the labor record", required = true)
	private String userName;
	@ApiModelProperty(value = "created by for the labor record", required = true)
	private String createdBy;
	
	/*
	 * Default Constructor
	 */
	public LaborRecordAddInfo() {
	}

	public LaborRecordAddInfo(Long id, Long segmentActualId, String startTime, String endTime, 
			Long appliedTime, Long laborTypeId, String userName, String createdBy) {
		this.id = id;
		this.segmentActualId = segmentActualId;
		this.startTime = startTime;
		this.endTime = endTime;
		this.appliedTime = appliedTime;
		this.laborTypeId = laborTypeId;
		this.userName = userName;
		this.createdBy = createdBy;
	}

	@Override
	public Long getId() {
		// TODO Auto-generated method stub
		return null;
	}


}