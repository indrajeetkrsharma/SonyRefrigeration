package org.poc.laborservice.manager;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import org.poc.laborservice.apis.LaborRecordAddInfo;
import org.poc.laborservice.apis.LaborRecordInfo;
import org.poc.laborservice.apis.LaborRecordUpdateInfo;
import org.poc.laborservice.constant.ControllerConstants;
import org.poc.laborservice.exceptions.DateTimeRangeException;
import org.poc.laborservice.exceptions.ResourceNotFoundException;
import org.poc.laborservice.mappers.builders.LaborRecordBuilder;
import org.poc.laborservice.models.LaborRecord;
import org.poc.laborservice.repository.ILaborRecordSearchRepository;
import org.poc.laborservice.repository.LaborRecordRepository;
import org.poc.laborservice.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

@Service
public class LaborRecordManager {
	private static final Logger LOGGER = LoggerFactory.getLogger(LaborRecordManager.class);

	@Autowired
	private LaborRecordRepository laborRecordRepository;

	@Autowired
	private LaborRecordBuilder laborRecordBuilder;

	@Autowired
	private ILaborRecordSearchRepository laborRecordSearchRepo;
	
	/**
	 * Update a labor record
	 * 
	 * @param laborRecordId   - Id of the labor record to update
	 * @param laborRecordInfo - updated labor record resource
	 * @return returns LaborRecordInfo object
	 * @throws DataIntegrityViolationException
	 */
	@Transactional
	public LaborRecordInfo updateLaborRecord(Long laborRecordId, LaborRecordUpdateInfo laborRecordUpdateInfo,
			Authentication auth) throws DataIntegrityViolationException {
		LaborRecord existedLaborRecord = laborRecordRepository.findOne(laborRecordId);
		LaborRecord laborRecord = null;
		if (existedLaborRecord == null) {
			String details = "LaborRecord=" + laborRecordId + " does not exist";
			LOGGER.info(details);
			throw new org.poc.laborservice.exceptions.ResourceNotFoundException(details);
		}
		//existedLaborRecord.setModifiedBy(auth.getName());
		existedLaborRecord.setModifiedBy(laborRecordUpdateInfo.getModifiedBy());
		Date startTime = existedLaborRecord.getStartTime();
		Date endTime = DateUtil.getDateObject("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", laborRecordUpdateInfo.getEndTime());
		if (endTime.compareTo(startTime)<0) {
			LOGGER.error(ControllerConstants.START_DATE_TIME_AND_END_DATE_TIME_CHECK_MESSAGE);
			throw new DateTimeRangeException();
		}
		existedLaborRecord.setEndTime(endTime);
		
		String userName = laborRecordUpdateInfo.getUserName();
		existedLaborRecord.setUserName(userName);
		
		long minutes;
		if(laborRecordUpdateInfo.getAppliedTime()==null) {
			Duration dur = Duration.between(startTime.toInstant(), endTime.toInstant());
			minutes = dur.toMinutes();
		} else {
			minutes=laborRecordUpdateInfo.getAppliedTime();
		}
		existedLaborRecord.setAppliedTime(minutes);
		
		Date modifiedOn = DateUtil.getDateObject("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Instant.now().toString());
		existedLaborRecord.setModifiedOn(modifiedOn);
	
		try {
			laborRecord = laborRecordRepository.save(existedLaborRecord);
		} catch (DataIntegrityViolationException e) {
			LOGGER.error(e.getMessage());
			throw e;
		}
		
		LOGGER.debug("----------------------------");
		LOGGER.debug("starttime " + startTime.toString());
		LOGGER.debug("endtime " + endTime.toString());
		LOGGER.debug("modifiedOn " + modifiedOn.toString());
		LOGGER.debug("----------------------------");
		
		
		return laborRecordBuilder.buildInfo(laborRecord);
	}

	/**
	 * Delete a specific labor record
	 *
	 * @param laborRecordId Id of the labor record to delete
	 */
	@Transactional
	public void deleteLaborRecord(Long laborRecordId) 
			throws DataIntegrityViolationException {
		LaborRecord laborRecordExisted = laborRecordRepository.findOne(laborRecordId);
		if (laborRecordExisted == null) {
			String details = "LaborRecord=" + laborRecordId + " does not exist";
			LOGGER.info(details);
			throw new ResourceNotFoundException(details);
		}
		laborRecordRepository.delete(laborRecordExisted);
		LOGGER.info("LaborRecord={}  deleted", laborRecordId);
	}

	/**
	 * This method calling using JPA repository and trying to persist labor record
	 * into the database.
	 * 
	 * @param laborRecordAddInfo 	- Labor Record Add Object
	 * @param auth            		- Authentication Object
	 * @return LaborRecordInfo
	 */
	@Transactional
	public LaborRecordInfo createLaborRecord(LaborRecordAddInfo laborRecordAddInfo, Authentication auth)
			throws DataIntegrityViolationException {
		LOGGER.debug("The createLaborRecord() - START");
		LaborRecord laborRecord = new LaborRecord();
		BeanUtils.copyProperties(laborRecordAddInfo, laborRecord, "id", "startTime", "endTime");
		Date startTime = DateUtil.getDateObject("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", laborRecordAddInfo.getStartTime());
		Date endTime = null;
		if (!StringUtils.isEmpty(laborRecordAddInfo.getEndTime())) {
			endTime = DateUtil.getDateObject("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", laborRecordAddInfo.getEndTime());
		}
		laborRecord.setStartTime(startTime);
		laborRecord.setEndTime(endTime);
		//laborRecord.setUserName(auth.getName());
			
		Date createdOn = DateUtil.getDateObject("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Instant.now().toString());
		laborRecord.setCreatedOn(createdOn);
		//laborRecord.setCreatedBy(auth.getName());
		try {

			laborRecord = laborRecordRepository.saveAndFlush(laborRecord);
		} catch (DataIntegrityViolationException e) {
			LOGGER.error(e.getMessage());
			throw e;
		}
		LOGGER.debug("----------------------------");
		LOGGER.debug("startTime " + startTime.toString());
		LOGGER.debug("createdOn " + createdOn.toString());
		LOGGER.debug("----------------------------");
			
		LOGGER.debug("The createLaborRecord() - END");
		return laborRecordBuilder.buildInfo(laborRecord);

	}
	
	/**
	 * Labor record querys
	 */
    public Page<LaborRecordInfo> getLaborRecordsByColumnSearchCriteria(List<String> userName, List<Long> laborTypeId, 
    		String likeOnColumn, String likeSearchValue, String orderByColumn, String orderBy,Pageable pageable)  {

    	Set_EmptyValue(userName, laborTypeId);
    	Page<LaborRecordInfo> filtered = laborRecordSearchRepo.findLaborRecordsByColumnSearch(
    			userName, laborTypeId, likeOnColumn,
    			likeSearchValue, orderByColumn, orderBy, pageable);
    	return filtered;

    }

	public void Set_EmptyValue(List<String> userName, List<Long> laborTypeId) {
		if (userName != null && userName.isEmpty()) {
			userName.add("");
		}
	}
	
	
	/**
	 * Get a labor record
	 * 
	 * @param laborRecordId
	 *            - Id of the labor record resource
	 * @return - A labor record resource
	 */
	public LaborRecordInfo getLaborRecord(long laborRecordId) {

		LaborRecord laborRecord = laborRecordRepository.findOne(laborRecordId);
		if (laborRecord == null) {
			String details = "LaborRecord=" + laborRecordId + " does not exist";
			LOGGER.info(details);
			throw new ResourceNotFoundException(details);
		}

		return laborRecordBuilder.buildInfo(laborRecord);
	}
}
