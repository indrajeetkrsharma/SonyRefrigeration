package org.poc.laborservice.springextension;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.springframework.hateoas.Identifiable;

import java.io.Serializable;

/**
 * Interface to mark objects that are identifiable by an ID of any type
 * and have an identifiable parent with an ID of the same type.
 */
public interface NestedIdentifiable<ID extends Serializable> extends Identifiable<ID> {
	/**
	 * Returns the id identifying the parent object.
	 *
	 * @return the identifier or {@literal null} if not available.
	 */
	@JsonIgnore
	ID getParentId();
}
