package org.poc.laborservice.springextension;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * This class supports the EntityTableListener - any application using the EntityTableBase
 * for managing created/modified users should create a bean for this class that returns the
 * singleton instance.
 *
 * The SpringApplicationContextInjector is atatic singleton that makes the spring application context
 * available to any class, including those not managed by the dependency container.
 *
 * DO NOT ABUSE THIS CLASS.
 *
 * You should use @Bean and @Autowire in 99% of cases. This class is to be used only in those rare cases
 * where there are objects that cannot be managed by the dependency container that still need injection.
 *
 * For example, EntityListeners on JPA model classes. The underlying JPA implementation handles the
 * creation of these classes, meaning we cannot get them into the DC. If those classes need access to
 * a bean managed by Spring DC, then we have no choice but to do something like this.
 */
public class SpringApplicationContextInjector implements ApplicationContextAware {
    private ApplicationContext context;

    private static SpringApplicationContextInjector INSTANCE = new SpringApplicationContextInjector();

    private SpringApplicationContextInjector() {}

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }

    /**
     * Gets singleton instance of SpringApplicationContextInjector
     * @return singleton
     */
    public static SpringApplicationContextInjector getInstance() {
        return INSTANCE;
    }

    /**
     * Gets a bean of the given class
     * @param clazz Class for the bean to load from context
     * @param <T> Type to return
     * @return Bean from context with the given type
     */
    public <T> T getBean(Class<T> clazz) {
        return context.getBean(clazz);
    }
}
