package org.poc.laborservice.springextension;

import org.modelmapper.ModelMapper;

/**
 * Adapter class for the Builder abstract class. Use this class if you do not need to fully
 * implement the interface defined by Builder, but do need some of the methods.
 */
public abstract class BuilderAdapter<M, I> extends Builder<M, I> {
    @Override
    protected void postMapInfo(M modelSource, I infoTarget) {

    }

    @Override
    protected void postMapModel(I infoSource, M modelTarget) {

    }

    @Override
    protected void enhanceMapper(ModelMapper mapper) {

    }
}

