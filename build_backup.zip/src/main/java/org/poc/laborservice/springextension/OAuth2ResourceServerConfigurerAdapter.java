package org.poc.laborservice.springextension;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;

/**
 * Provides OAuth2 configuration for resources. The UAA service host and port
 * should be defined in the 'uaa.service.origin' property.
 * Note that this class requires a {@link UaaTokenClient bean}.
 *
 * We only care that the request token originated from the configured UAA, for
 * that we verify the token against the UAA's public key.
 */
@ComponentScan
public abstract class OAuth2ResourceServerConfigurerAdapter extends ResourceServerConfigurerAdapter {
	/**
	 * Add resource-server specific properties (like a resource id).
	 *
	 * @param config configurer for the resource server
	 */
	@Override
	public void configure(ResourceServerSecurityConfigurer config) {
		// we don't want to check any resource ids because we don't fully
		// understand what they are used for and why, let alone finding a
		// resource id that works for our different flavors of UAA.
		config.resourceId(null);
	}

	/**
	 * Token store
	 *
	 * @return Token store bean
	 */
	@Bean
	public JwtTokenStore tokenStore() {
		return new JwtTokenStore(accessTokenConverter());
	}

	/**
	 * JwtAccessTokenConverter bean
	 *
	 * @return JwtAccessTokenConverter
	 */
	@Bean
	public JwtAccessTokenConverter accessTokenConverter() {
		return new LazyJwtTokenConverter();
	}
}
