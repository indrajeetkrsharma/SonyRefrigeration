package org.poc.laborservice.springextension;

import org.springframework.stereotype.Service;

/**
 * Class responsible for generating URLs to the WebHMI authentication microservice. Each method builds up the various URL parts from the given
 * arguments.
 *
 * Requirements for use:
 * In order for this class to properly pick up the location of the tomcat server:
 * 1) There must be a property 'uaa.service.origin' (or environment variable 'UAA_SERVICE_ORIGIN') set to indicate the
 *    host and port of the UAA service.
 * 2) In addition, this class must be autowired where it is used, so it can in turn pick up that property and use it.
 *    Note that this class is configured as a service, so as long as classpath scanning is properly set up in Spring, it will
 *    be created automatically and be available for autowiring.
 *
 * If either of these conditions is not met, the host and port will default to https://localhost:8443
 */
@Service
public class WebHmiUaaServiceUrlGenerator extends UaaServiceUrlGenerator {
	/* DOC - the WebHMI UAA is similar to the Predix UAA but uses slightly different paths. */

	private static final String tokenKeyUrl = "/oauth/token_key";

	@Override
	protected String getTokenKeyUrl() {
		return tokenKeyUrl;
	}
}

