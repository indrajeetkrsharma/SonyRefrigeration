package org.poc.laborservice.springextension;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

/**
 * Cache for builder instances. Used by Builder to retrieve instances of other builds when parsing
 * buildable child properties.
 */
@Service
public class BuilderCache {

    private Map<String, Builder> builderMap = new HashMap<>();

    /**
     * Gets builderMap
     *
     * @param builderName name of builder class
     * @return Builder matching given name
     */
    Builder getBuilder(String builderName) {
        return builderMap.get(builderName);
    }

    /**
     * Sets builderMap
     *
     * @param builder Builder to cache
     */
    void addBuilder(Builder builder) {
        builderMap.put(builder.getClass().getSimpleName(), builder);
    }
}
