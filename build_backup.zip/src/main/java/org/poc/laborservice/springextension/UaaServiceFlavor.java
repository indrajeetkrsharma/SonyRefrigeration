package org.poc.laborservice.springextension;

/**
 * Different implementation types of Oauth2 UAA services, each has slightly different API.
 */
public enum UaaServiceFlavor {
	/**
	 * Predix UAA (also known as CF or Historian)
	 */
	Predix,

	/**
	 * WebHMI UAA
	 */
	WebHMI;

	/**
	 * Convenience method to case-insensitively convert a string to a enum value.
	 *
	 * @param enumeration Enum class to convert to.
	 * @param suspect     Suspect string.
	 * @param <T>         Enum class type.
	 * @return Enum value or null if no match.
	 */
	public static <T extends Enum<?>> T searchEnum(Class<T> enumeration, String suspect) {
		for (T each : enumeration.getEnumConstants()) {
			if (each.name().compareToIgnoreCase(suspect) == 0) {
				return each;
			}
		}
		return null;
	}

	/**
	 * Convenience method to case-insensitively convert a string to a enum value.
	 *
	 * @param value Suspect string.
	 * @return Enum value
	 */
	public static UaaServiceFlavor caseInsensitiveValueOf(String value) {
		return searchEnum(UaaServiceFlavor.class, value);
	}
}

