package org.poc.laborservice.springextension;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;

/**
 * Extends JwtAccessTokenConverter to allow for the public key for the converter to be loaded lazily before it is needed
 * for the first time.
 * Note that this class requires a {@link UaaTokenClient bean}.
 */
public class LazyJwtTokenConverter extends JwtAccessTokenConverter {
	@Autowired
	private UaaTokenClient uaaTokenClient;

	/**
	 * Default constructor.
	 */
	public LazyJwtTokenConverter() { }

	/**
	 * Loads the contents of the public key
	 * @return contents of public key
	 */
	public String getPublicKey() {
		return uaaTokenClient.getTokenPublicKey();
	}

	@Override
	protected Map<String, Object> decode(String token) {
		lazyLoadPublicKey();

		return super.decode(token);
	}

	private void lazyLoadPublicKey() {
		if(!getKey().get("value").contains("PUBLIC KEY")) {
			String publicKey = getPublicKey();
			setVerifierKey(publicKey);

			//Null out the verifier so that running afterPropertiesSet will force a re-initialization using the base class'
			//logic.
			setVerifier(null);
			try {
				afterPropertiesSet();
			} catch(Exception ex) {
				throw new RuntimeException();
			}
		}
	}
}
