package org.poc.laborservice.springextension;

import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;

/**
 * Base class for UrlGenerator classes. Provides some common methods, handles service location and generates a UriComponentBuilder
 * that respects x-forwarded headers. This means it generates links correctly when behind a reverse proxy.
 */
public class UrlGenerator {
    private String serviceLocation;

    /**
     * Default constructor.
     */
    public UrlGenerator() {
    }

    /**
     * Alternate constructor.
     * @param serviceLocation service location
     */
    public UrlGenerator(String serviceLocation) {
        setServiceLocation(serviceLocation);
    }

    /**
     * Return the serviceLocation value.
     * @return The current service location.
     */
    public String getServiceLocation() {
        return serviceLocation;
    }

    /**
     * Set the serviceLocation.
     * @param serviceLocation The new service location.
     */
    public void setServiceLocation(String serviceLocation) {
        this.serviceLocation = serviceLocation;
    }

    /**
     * Generates URLs to multiple endpoints.
     * @param paths List of URL path segments
     * @return String representation of the requested URL
     */
    public String generateUrl(String... paths){
        UriComponentsBuilder builder = getBuilder().pathSegment(paths);
        return builder.build().toUriString();
    }

    /**
     * Creates a builder that will respect x-forwarded headers on the current request. If no request can be found, generates
     * a builder that will use serviceLocation as the host.
     * @return UriComponentsBuilder to use when generating links
     */
    protected UriComponentsBuilder getBuilder() {
        HttpServletRequest request = getRequest();

        //We want to use the request unless it doesn't exist or there's a manual override of the serviceLocation that
        //isn't the same as the request. So:

        //If serviceLocation has been set manually AND there is no request
        //OR serviceLocation has been set manually AND there IS a request AND the serviceLocation does not match the request
        if(!StringUtils.isEmpty(serviceLocation) &&
                ((request != null && !request.getRequestURL().toString().substring(0, request.getRequestURL().toString().indexOf(request.getRequestURI())).equals(serviceLocation)) ||
                (request == null))) {
            return UriComponentsBuilder.fromHttpUrl(serviceLocation);
        }
        //Otherwise if serviceLocation has been set manually AND there is a request AND it DOES match the serviceLocation
        //OR serviceLocation has NOT been set manually AND there is a request, then use the request.
        else if(request != null) {
            ServletServerHttpRequest httpRequest = new ServletServerHttpRequest(request);
            UriComponents uriComponents = UriComponentsBuilder.fromHttpRequest(httpRequest).build();

            //fromHttpRequest gets us *almost* everything we need, but it includes the context path in the builder's
            //path. http://localhost:443/[contextPath]. We don't want that here, so we have to build another builder
            //to lose it since there's no method to reset the context path on UriComponentsBuilder.
            String scheme = uriComponents.getScheme();
            String host = uriComponents.getHost();
            int port = uriComponents.getPort();

            UriComponentsBuilder builder = UriComponentsBuilder.newInstance();
            builder.scheme(scheme);
            builder.host(host);
            if (("http".equals(scheme) && port != 80) || ("https".equals(scheme) && port != 443)) {
                builder.port(port);
            }

            //fromHttpRequest appears to handle everything from X-Forwarded except ssl. Tack it on.
            String forwardedSsl = request.getHeader("X-Forwarded-Ssl");

            if (StringUtils.hasText(forwardedSsl) && forwardedSsl.equalsIgnoreCase("on")) {
                builder.scheme("https");
            }

            return builder;
        }
        //Finally, if no request exists and there hasn't been a serviceLocation provided, blow up.
        else {
            throw new IllegalArgumentException("Service location must be set");
        }
    }

    private HttpServletRequest getRequest() {
        try {
            return ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        } catch(IllegalStateException ex) {
            //This call will throw an IllegalStateException when there's no thread bound request. That's fine, just return null
            //the calling code can handle it
            return null;
        }
    }
}
