package org.poc.laborservice.springextension;

import java.nio.charset.Charset;
import java.time.Instant;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Supplier;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * Responsible for communicating with the UAA service for authentication support.
 *
 * Requirements for use:
 * In order for this class to properly pick up the location of the UAA service:
 * 1) There must be a property 'uaa.service.origin' (or environment variable 'UAA_SERVICE_ORIGIN') set to indicate the
 *    host and port of the UAA service.
 * 2) In addition, this class must be autowired where it is used, so it can in turn pick up that property and use it.
 *    Note that this class is configured as a service, so as long as classpath scanning is properly set up in Spring, it will
 *    be created automatically and be available for autowiring.
 *
 * If either of these conditions is not met, the host and port will default to https://localhost:8443
 */
@Service
public class UaaTokenClient {
	private static final String ACCESS_TOKEN_NAME = "access_token";
	private static final String REFRESH_TOKEN_NAME = "refresh_token";
	private static final String EXPIRY_NAME = "expires_in";

	private Logger log = LoggerFactory.getLogger(this.getClass());
	private ThreadPoolTaskScheduler backgroundScheduler = new ThreadPoolTaskScheduler();
	private RestTemplate restTemplate = new RestTemplate();
	private UaaServiceUrlGenerator uaaServiceUrlGenerator;
	private UaaToken cachedServiceUserToken;
	private Lock cachedDataLock = new ReentrantLock();
	private UaaServiceFlavor uaaServiceFlavor;

	/**
	 * Location of the UAA service.
	 * Read from Spring properties, environment variable, or the given default.
	 */
	@Value("${uaa.service.origin:https://localhost:8443}")
	private String uaaServiceOrigin;

	/**
	 * The UAA service type.
	 * Read from Spring properties, environment variable, or the given default.
	 */
	@Value("${uaa.service.type:predix}")
	private String uaaServiceFlavorString;

	/**
	 * Client id configured on the UAA service.
	 * Read from Spring properties, environment variable.
	 */
	@Value("${uaa.service.client.id:}")
	private String uaaServiceClientId;

	/**
	 * Client secret configured on the UAA service.
	 * Read from Spring properties, environment variable.
	 */
	@Value("${uaa.service.client.secret:}")
	private String uaaServiceClientSecret;

	/**
	 * UAA service user name used to obtain a token for REST requests when when no end-user token is supplied.
	 * Read from Spring properties, environment variable.
	 */
	@Value("${uaa.service.serviceuser.name:}")
	private String uaaServiceUserName;

	/**
	 * UAA service user password used to obtain a token for REST requests when when no end-user token is supplied.
	 * Read from Spring properties, environment variable.
	 */
	@Value("${uaa.service.serviceuser.password:}")
	private String uaaServiceUserPassword;

	/**
	 * Create and initialize the appropriate UAA url generator.
	 */
	@PostConstruct
	private void initServiceLocation() {
		uaaServiceFlavor = UaaServiceFlavor.caseInsensitiveValueOf(uaaServiceFlavorString);
		if (uaaServiceFlavor == null) {
			throw new RuntimeException("Unknown UAA service type '" + uaaServiceFlavorString + "'; please edit the 'uaa.service.type' property.");
		}
		switch (uaaServiceFlavor) {
			case Predix:
				uaaServiceUrlGenerator = new UaaServiceUrlGenerator();
				break;
			case WebHMI:
				uaaServiceUrlGenerator = new WebHmiUaaServiceUrlGenerator();
				break;
			default:
				throw new RuntimeException("Unexpected UAA service type '" + uaaServiceFlavor.name() + "'");
		}
		uaaServiceUrlGenerator.setServiceLocation(uaaServiceOrigin);
	}

	/**
	 * Default constructor
	 */
	public UaaTokenClient() {
		backgroundScheduler.initialize();
	}

	/**
	 * Set the rest template -- should be used only for testing purposes.
	 *
	 * @param restTemplate rest template
	 */
	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	/**
	 * Gets the token public key from the UAA service.
	 *
	 * Requires the following application properties (or equivalent environment variables):
	 *  'uaa.service.origin'  The base url of the UAA service, defaults to 'https://localhost:8443'.
	 *  'uaa.service.type'    The type of UAA, one of 'Predix' or 'WebHMI', defaults to 'Predix'.
	 *
	 * @return The token public key
	 */
	public String getTokenPublicKey() {
		String tokenKeyUrl = uaaServiceUrlGenerator.generateTokenKeyUrl();
		log.info("Loading public key from {}", getUaaServiceOriginForLogging());
		log.debug("Loading public key from {}", tokenKeyUrl);

		// issue the UAA request (exception thrown if it fails in any way)
		ParameterizedTypeReference<Map<String, Object>> typeRef = new ParameterizedTypeReference<Map<String, Object>>() {
		};
		ResponseEntity<Map<String, Object>> response =
				restTemplateWrapper("Failed to get token public key from UAA service",
				                    () -> restTemplate.exchange(tokenKeyUrl, HttpMethod.GET, null, typeRef));

		return response.getBody().get("value").toString();
	}

	/**
	 * Gets the token information for the configured service user account.
	 *
	 * Requires the following application properties (or equivalent environment variables):
	 *  'uaa.service.origin'                The base url of the UAA service, defaults to 'https://localhost:8443'.
	 *  'uaa.service.type'                  The type of UAA, one of 'Predix' or 'WebHMI', defaults to 'Predix'.
	 *  'uaa.service.client.id'             The id used to authenticate this calling application to the UAA.
	 *  'uaa.service.client.secret'         The secret used to authenticate this calling application to the UAA.
	 *  'uaa.service.serviceuser.name'      The service user account name for which to retrieve a token.
	 *  'uaa.service.serviceuser.password'  The service user account password for which to retrieve a token.
	 *
	 * Since the token will eventually expire we will take care of refreshing
	 * it automatically, in the background, so that you can always retrieve a
	 * valid token via this call.
	 *
	 * Throws UaaTokenException if no token cached and cannot reach the UAA.
	 * Throws UaaTokenExpiredException if cached token is expired (usually means there is an UAA outage).
	 *
	 * @return UaaToken information
	 */
	public UaaToken getServiceUserToken() {
		/* DEVELOPER ATTENTION - Not sure why we don't just return a {@link OAuth2AccessToken} here; chalking that up to ignorance. -- FL */
		cachedDataLock.lock();
		try {
			// if token is not cached then load it
			if (cachedServiceUserToken == null) {

				// get and cache the token
				log.info("Retrieving service user token from {}", getUaaServiceOriginForLogging());
				UaaToken token = getServiceUserTokenUsingCredentials();
				updateCachedServiceUserToken(token);

				// start a background thread to refresh the token before expiry
				startBackgroundServiceUserTokenRefresh(token.getExpirySeconds());
			}

			// throw an error if the cached token has already expired
			if (cachedServiceUserToken.isExpired()) {
				throw new UaaTokenExpiredException("Cached service user token is expired, perhaps the UAA cannot be reached.");
			}

			// return the cached token
			return cachedServiceUserToken;
		} finally {
			cachedDataLock.unlock();
		}
	}

	/**
	 * Gets a new token from the UAA using the password grant type with the
	 * specified client and user credentials.
	 * @param clientId The client ID
	 * @param clientSecret The client secret
	 * @param userName The user name
	 * @param password The user's password
	 * @return UaaToken information
	 */
	public UaaToken getNewTokenViaPasswordGrantType(String clientId, String clientSecret,
													String userName, String password) {
		//For below error add apache commons JAR
		Validate.notEmpty(clientId);
		Validate.notEmpty(clientSecret);
		Validate.notEmpty(userName);
		Validate.notEmpty(password);

		log.debug("Getting user token via password grant type ...");

		String uaaTokenUrl = uaaServiceUrlGenerator.generateGetTokenUrl(userName, password);
		return loadServiceUserToken(uaaTokenUrl, clientId, clientSecret);
	}

	/**
	 * Retrieves the token information for the configured service user from the UAA.
	 *
	 * @return UaaToken information
	 */
	private UaaToken getServiceUserTokenUsingCredentials() {
		if (StringUtils.isEmpty(uaaServiceUserName)) {
			throw new UaaTokenException("UAA service user name is not configured. Please set 'uaa.service.serviceuser.name' property.");
		}
		if (StringUtils.isEmpty(uaaServiceUserPassword)) {
			throw new UaaTokenException("UAA service user password is not configured. Please set 'uaa.service.serviceuser.password' property.");
		}
		if (StringUtils.isEmpty(uaaServiceClientId)) {
			throw new UaaTokenException("UAA service client id is not configured. Please set 'uaa.service.client.id' property.");
		}
		if (StringUtils.isEmpty(uaaServiceClientSecret)) {
			throw new UaaTokenException("UAA service client secret is not configured. Please set 'uaa.service.client.secret' property.");
		}

		log.debug("Getting service user token via credentials ...");
		String uaaTokenUrl = uaaServiceUrlGenerator.generateGetTokenUrl(uaaServiceUserName, uaaServiceUserPassword);
		return loadServiceUserToken(uaaTokenUrl, uaaServiceClientId, uaaServiceClientSecret);
	}

	/**
	 * Retrieves the token information for the configured service user from the UAA.
	 *
	 * @return UaaToken information
	 */
	private UaaToken getServiceUserTokenUsingRefresh() {
		String refreshToken;
		cachedDataLock.lock();
		try {
			if (cachedServiceUserToken == null) {
				throw new UaaTokenException("No refresh token available");
			}
			log.debug("Getting service user token via refresh token ...");
			refreshToken = cachedServiceUserToken.getRefreshToken();
		} finally {
			cachedDataLock.unlock();
		}

		String uaaTokenUrl = uaaServiceUrlGenerator.generateRefreshTokenUrl(refreshToken);
		return loadServiceUserToken(uaaTokenUrl, uaaServiceClientId, uaaServiceClientSecret);
	}

	/**
	 * Start a background task to repeatedly refresh the service user token before it expires.
	 * If the refresh fails then the cached data is not touched, it may be expired :(
	 *
	 * @param expirySeconds token expiry seconds
	 */
	private void startBackgroundServiceUserTokenRefresh(int expirySeconds) {
		// DOC - we assume the UAA will hand out tokens with an expiry > 0s

		// schedule a refresh one minute earlier than the expiry time
		final int oneMinute = 60;
		int refreshSeconds = expirySeconds - oneMinute;
		// ... with a minimum refresh of one minute
		if (refreshSeconds < oneMinute) {
			refreshSeconds = oneMinute;
		}
		// ... except for those with really short expiry time
		if (expirySeconds < oneMinute) {
			refreshSeconds = expirySeconds;
		}

		log.info("Scheduling service user token refresh every {} seconds (token expires in {})", refreshSeconds, expirySeconds);
		backgroundScheduler.scheduleAtFixedRate(this::refreshServiceUserToken,
		                                        Date.from(Instant.now().plusSeconds(refreshSeconds)),
		                                        refreshSeconds * 1000);
	}

	/**
	 * Replace the cached token.
	 *
	 * @param updatedToken updated token to cache
	 */
	private void updateCachedServiceUserToken(UaaToken updatedToken) {
		cachedDataLock.lock();
		try {
			cachedServiceUserToken = updatedToken;
		} finally {
			cachedDataLock.unlock();
		}
		log.debug("Updated cached service user token");
	}

	/**
	 * Refresh the cached service user token.
	 * This MUST NOT throw exceptions, as it is executed on a background thread, but may log in case of trouble.
	 */
	private void refreshServiceUserToken() {
		// DOC - First try to update the token using the existing refresh
		// token, if available, as this involves sending no sensitive data.
		// If this cannot be done (none or expired refresh token) then update
		// the token using the configured credentials. This ensures that we
		// can gracefully recover from a prolonged UAA outage
		log.info("Refreshing service user token ...");
		try {
			UaaToken updatedToken;
			try {
				// get updated token using refresh
				updatedToken = getServiceUserTokenUsingRefresh();
			} catch (UaaTokenException e) {

				// get updated token using credentials
				updatedToken = getServiceUserTokenUsingCredentials();
			}

			// cache the updated token
			updateCachedServiceUserToken(updatedToken);
		} catch (Exception e) {
			log.error("Failed to refresh service user token", e);
		}
	}

	/**
	 * Generate a request entity containing the given headers; required headers will be added.
	 *
	 * @param headers optional headers
	 * @param clientId The client ID
	 * @param clientSecret The client secret
	 * @return request entity
	 */
	private HttpEntity generateRequiredHttpEntity(HttpHeaders headers, String clientId, String clientSecret) {
		// generate the required headers (for client authentication)
		if (headers == null) {
			headers = new HttpHeaders();
		}
		headers.add(HttpHeaders.AUTHORIZATION, getBasicAuthenticationEncoding(clientId, clientSecret));
		headers.add(HttpHeaders.ACCEPT, "application/json");

		// return the entity
		return new HttpEntity<>(headers);
	}

	/**
	 * Generate an encoded basic authentication string suitable for use with HTTP Authorization header.
	 *
	 * @param user username
	 * @param pass password
	 * @return encoded basic authentication string.
	 */
	private String getBasicAuthenticationEncoding(String user, String pass) {
		String auth = user + ":" + pass;
		byte[] encodedAuth = Base64.getEncoder().encode(
				auth.getBytes(Charset.forName("ISO-8859-1")));
		return "Basic " + new String(encodedAuth, Charset.defaultCharset());
	}

	/**
	 * Retrieve the token from the UAA using the given auth url (this may be a new request or a refresh).
	 *
	 * @param authUrl authentication url
	 * @param clientId client ID
	 * @param clientSecret client secret
	 * @return token info
	 */
	private UaaToken loadServiceUserToken(String authUrl, String clientId, String clientSecret) {
		// generate the request entity
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, "application/x-www-form-urlencoded");
		HttpEntity entity = generateRequiredHttpEntity(headers, clientId, clientSecret);

		// issue the UAA request (exception thrown if it fails in any way)
		log.trace("Retrieving service user token from {}", getUaaServiceOriginForLogging());
		entity.getHeaders().forEach((x, y) -> y.forEach(z -> log.trace("Request header: {}={}", x, z)));
		ResponseEntity<LinkedHashMap> response =
				restTemplateWrapper("Failed to get token for service user from UAA service",
				                    () -> restTemplate.exchange(authUrl, HttpMethod.POST, entity, LinkedHashMap.class));

		// CLAIM - the response is valid

		// return the token information
		LinkedHashMap body = response.getBody();
		String accessToken = (String) body.get(ACCESS_TOKEN_NAME);
		String refreshToken = (String) body.get(REFRESH_TOKEN_NAME);
		int expirySeconds = (int) body.get(EXPIRY_NAME);
		return new UaaToken(accessToken, refreshToken, expirySeconds);
	}

	/**
	 * Issues the given @{link RestTemplate} call and handles exceptions in a consistent manner.
	 * If the call is successful then the response is returned, otherwise a {@link UaaTokenException} is thrown.
	 *
	 * @param failureMessage           failure message
	 * @param restTemplateExchangeCall rest call
	 * @return response
	 */
	private <T> ResponseEntity<T> restTemplateWrapper(String failureMessage, Supplier<ResponseEntity<T>> restTemplateExchangeCall) {
		ResponseEntity<T> response;
		try {
			response = restTemplateExchangeCall.get();
			if (response == null) {
				log.error(failureMessage + ": null response");
				throw new UaaTokenException(failureMessage);
			}
			if (response.getStatusCode() != HttpStatus.OK) {
				log.error(failureMessage + ": response status:{}", response.getStatusCode());
				throw new UaaTokenException(failureMessage, response);
			}
			if (response.getBody() == null) {
				log.error("Failed to get token for service user from UAA service: no response body");
				throw new UaaTokenException("Failed to get token for service user from UAA service", response);
			}
		} catch (HttpStatusCodeException e) {
			log.error(failureMessage + ": request failure:{}", e.getStatusCode(), e);
			throw new UaaTokenException(failureMessage, e);
		} catch (RestClientException e) {
			log.error(failureMessage + ": request failure", e);
			throw new UaaTokenException(failureMessage, e);
		}
		return response;
	}

	/**
	 * Gets the UAA location for logging purposes. Contains no sensitive information.
	 *
	 * @return UAA type and location
	 */
	private String getUaaServiceOriginForLogging() {
		return String.format("%s UAA at %s", uaaServiceFlavor.name(), uaaServiceUrlGenerator.getServiceLocation());
	}
}

