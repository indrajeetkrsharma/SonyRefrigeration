package org.poc.laborservice.springextension;


import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * Class responsible for generating URLs to the Predix authentication microservice. Each method builds up the various URL parts from the given
 * arguments.
 *
 * Requirements for use:
 * In order for this class to properly pick up the location of the tomcat server:
 * 1) There must be a property 'uaa.service.origin' (or environment variable 'UAA_SERVICE_ORIGIN') set to indicate the
 *    host and port of the UAA service.
 * 2) In addition, this class must be autowired where it is used, so it can in turn pick up that property and use it.
 *    Note that this class is configured as a service, so as long as classpath scanning is properly set up in Spring, it will
 *    be created automatically and be available for autowiring.
 *
 * If either of these conditions is not met, the host and port will default to https://localhost:8443
 */
@Service
public class UaaServiceUrlGenerator extends UrlGenerator {
	private static final String grantTypePart = "grant_type";
	private static final String grantTypeGetToken = "password";
	private static final String grantTypeRefreshToken = "refresh_token";
	private static final String usernamePart = "username";
	private static final String passwordPart = "password";
	private static final String refreshTokenPart = "refresh_token";

	private static final String getTokenUrl = "/oauth/token";
	private static final String refreshTokenUrl = "/oauth/token";
	private static final String tokenKeyUrl = "/token_key";

	/**
	 * Default constructor
	 */
	public UaaServiceUrlGenerator() {
	}

	/**
	 * Generates a URL to the get token root endpoint. Adds grant type, username, and  password.
	 * Intended to be used by a @LoadBalanced RestTemplate that knows how to talk to Eureka.
	 *
	 * @param username The client username
	 * @param password The client password
	 * @return A String representing the requested url to get a token
	 */
	public String generateGetTokenUrl(String username, String password) {
		UriComponentsBuilder builder = getBuilder();
		builder.path(getTokenUrl());
		builder.queryParam(grantTypePart, grantTypeGetToken);

		if (username != null && !username.isEmpty()) {
			builder.queryParam(usernamePart, username);
		}

		if (password != null && !password.isEmpty()) {
			builder.queryParam(passwordPart, password);
		}

		return builder.build().toUriString();
	}

	/**
	 * Generates a URL to the refresh token endpoint. Adds grant type and refresh token.
	 * Intended to be used by a @LoadBalanced RestTemplate that knows how to talk to Eureka.
	 *
	 * @param refreshToken The refresh token
	 * @return A String representing the requested url to get a token
	 */
	public String generateRefreshTokenUrl(String refreshToken) {
		UriComponentsBuilder builder = getBuilder();
		builder.path(getRefreshTokenUrl());
		builder.queryParam(grantTypePart, grantTypeRefreshToken);

		if (refreshToken != null && !refreshToken.isEmpty()) {
			builder.queryParam(refreshTokenPart, refreshToken);
		}

		return builder.build().toUriString();
	}

	/**
	 * Generates a URL to the token public key endpoint.
	 * Intended to be used by a @LoadBalanced RestTemplate that knows how to talk to Eureka.
	 *
	 * @return A String representing the requested url to check a token
	 */
	public String generateTokenKeyUrl() {
		UriComponentsBuilder builder = getBuilder();
		builder.path(getTokenKeyUrl());

		return builder.build().toUriString();
	}

	/**
	 * Get the UAA-specific token URL path.
	 * @return token url path
	 */
	protected String getTokenUrl() {
		return getTokenUrl;
	}

	/**
	 * Get the UAA-specific token refresh URL path
	 * @return token url refresh path
	 */
	protected String getRefreshTokenUrl() {
		return refreshTokenUrl;
	}

	/**
	 * Get the UAA-specific token key URL path
	 * @return token key url path
	 */
	protected String getTokenKeyUrl() {
		return tokenKeyUrl;
	}
}
