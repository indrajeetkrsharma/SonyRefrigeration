package org.poc.laborservice.springextension;

/**
 * Thrown when asking for a token that has already expired.
 */
public class UaaTokenExpiredException extends RuntimeException {
	/**
	 * Instantiate a new exception with a message.
	 *
	 * @param message message.
	 */
	public UaaTokenExpiredException(String message) {
		super(message);
	}
}
