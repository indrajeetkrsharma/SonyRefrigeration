package org.poc.laborservice.springextension;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Base class for all builder classes. Leverages ModelMapper and any additional rules specified by derived classes to convert
 * from Model to Info objects and vice versa.
 *
 * In general, ModelMapper should be used to do any conversions that can be performed using only data in the source object.
 * If additional data must be loaded in order to fully populate the target object, then the post* methods should be used
 * to load and then populate this data.
 *
 * The class provides a facility to load external data, postMapModel() and postMapInfo().
 * It also provides a means for derived classes to add additional mappings to the ModelMapper instance managed by
 * Spring, enhanceMapper(). This method should be used to add any deep mappings, or mappings between properties that do not
 * have the same type/name. The rule described above still applies though, ModelMapper should not be used to map external data
 * as this is not its responsibility.
 *
 * M: Model Class
 * I: Info Class
 */
public abstract class Builder<M, I> {
    @Autowired
    private ModelMapper mapper;

    @Autowired
    private BuilderCache builderCache;

    private Map<String, PropertyData> buildableModelProperties;

    private Map<String, PropertyData> buildableInfoProperties;

    private static final Logger LOGGER = LoggerFactory.getLogger(Builder.class);

    /**
     * Initializes the autowired mapper with any additional mappings specified by derived class
     */
    @PostConstruct
    public void init() {
        enhanceMapper(mapper);

        builderCache.addBuilder(this);

        buildableModelProperties = findBuildableProperties(getMClass());

        buildableInfoProperties = findBuildableProperties(getIClass());
    }

    /**
     * Accepts a list of model objects and builds a list of info objects using ModelMapper and any additional rules from
     * the derived class. Additional rules are provided by any derived class by implementing postMapInfo().
     * @param models List of model objects to convert
     * @return List of info objects mapped from the collection of models
     */
    public List<I> buildInfos(List<M> models) {
        return models.stream().map(this::buildInfo).collect(Collectors.toList());
    }

    /**
     * Accepts an info object and builds a model using ModelMapper and any additional rules from
     * the derived class. Additional rules are provided by any derived class by implementing postMapModel().
     * @param info Info object to convert to model type
     * @return Model object mapped from the Info
     */
    public M buildModel(I info) {
        M model = mapper.map(info, getMClass());

        postMapModelInternal(info, model);

        return model;
    }

    /**
     * Accepts a model object and builds an info object using ModelMapper and any additional rules from
     * the derived class. Additional rules are provided by any derived class by implementing postMapInfo().
     * @param model Model object to convert to info type
     * @return Info object mapped from the model
     */
    public I buildInfo(M model) {
        I info = mapper.map(model, getIClass());

        postMapInfoInternal(model, info);

        return info;
    }

    /**
     * Implement this method to populate the model with any additional data needed for the derived class' use case. Any
     * calls that need to be made to an external resource should occur here.
     * @param infoSource Info object being mapped to a model (for reference)
     * @param modelTarget Model object to populate with additional data
     */
    protected abstract void postMapModel(I infoSource, M modelTarget);

    /**
     * Implement this method to populate the info with any additional data needed for the derived class' use case. Any
     * calls that need to be made to an external resource should occur here.
     * @param modelSource Model object being mapped (for reference).
     * @param infoTarget Info object to populate with additional data
     */
    protected abstract void postMapInfo(M modelSource, I infoTarget);

    /**
     * Implement this method to specify the type of the Model class being used by the derived class.
     * We need this because of stupid type erasure.
     * @return Type of the Model class
     */
    protected abstract Class<M> getMClass();

    /**
     * Implement this method to specify the type of the Info class being used by the derived class.
     * We need this because of stupid type erasure.
     * @return Type of the Info class
     */
    protected abstract Class<I> getIClass();

    /**
     * Implement this method to specify any additional mappings for the Spring managed ModelMapper instance.
     * @param mapper Mapper to add mappings to.
     */
    protected abstract void enhanceMapper(ModelMapper mapper);

    /**
     * Used by unit tests ONLY
     * @param mapper test mapper
     */
    public void setMapper(ModelMapper mapper) {
        this.mapper = mapper;
    }

    /**
     * Used by unit tests ONLY
     * @param cache Test cache
     */
    public void setBuilderCache(BuilderCache cache) {
        this.builderCache = cache;
    }

    private Map<String, PropertyData> findBuildableProperties(Class<?> mClass) {
        return Arrays.asList(mClass.getMethods())
                .stream()
                .filter(method -> method.getName().startsWith("get"))
                .filter(method -> getAnnotation(method, Buildable.class) != null)
                .collect(Collectors.toMap(Method::getName,
                        method -> {
                            Buildable annotation = getAnnotation(method, Buildable.class);
                            String builderName = "Invalid";
                            if(annotation != null) {
                                builderName = annotation.value().getSimpleName();
                            }

                            return new PropertyData(builderName, method);
                        }));
    }

    private <A extends Annotation> A getAnnotation(Method method, Class<A> annotationClass) {
        if(!List.class.isAssignableFrom(method.getReturnType())) {
            return method.getReturnType().getAnnotation(annotationClass);
        }
        else {
            Type listType = ((ParameterizedType) method.getGenericReturnType()).getActualTypeArguments()[0];
            if(listType instanceof Class) {
                return ((Class<?>)listType).getAnnotation(annotationClass);
            }

            return null;
        }

    }


    @SuppressWarnings("unchecked")
    private void postMapModelInternal(I infoSource, M modelTarget) {
        postMapModel(infoSource, modelTarget);

        buildChildProperties(infoSource, modelTarget, buildableInfoProperties, buildableModelProperties, Builder::postMapModelInternal);
    }

    @SuppressWarnings("unchecked")
    private void postMapInfoInternal(M modelSource, I infoTarget) {
        postMapInfo(modelSource, infoTarget);

        //Iterate properties that are @Buildable and call postMapInfoInternal on them
        buildChildProperties(modelSource, infoTarget, buildableModelProperties, buildableInfoProperties, Builder::postMapInfoInternal);
    }

    @FunctionalInterface
    private interface Builderface{
        void build(Builder builder, Object source, Object target);
    }

    private void buildChildProperties(Object source, Object target, Map<String, PropertyData> sourceProperties, Map<String, PropertyData> targetProperties, Builderface buildFunction) {
        if(sourceProperties != null) {
            for (Map.Entry<String, PropertyData> entry : sourceProperties.entrySet()) {
                PropertyData sourcePropertyData = entry.getValue();
                String builderName = sourcePropertyData.getBuilderName();
                Builder builder = builderCache.getBuilder(builderName);
                //In spite of this property having had a type annotated with a builder, there
                //is no builder in the cache matching the annotation's value.
                if (builder == null) {
                    StringBuilder s = new StringBuilder();
                    s.append("Could not find builder '").append(builderName).append("' in the cache for property ");
                    s.append(source.getClass().getSimpleName()).append(".").append(sourcePropertyData.propertyMethod.getName()).append("() ");
                    s.append("of type ").append(sourcePropertyData.getPropertyMethod().getReturnType().getSimpleName()).append(". ");
                    s.append("This likely means you forgot to configure your builder as a service or provide it as a bean.");
                    throw new RuntimeException(s.toString());
                }

                PropertyData targetPropertyData = targetProperties.get(entry.getKey());
                if (targetPropertyData == null) {
                    LOGGER.debug("Found a buildable property (" + sourcePropertyData.getPropertyMethod().getName() + ") with no matching property on the target class. Only properties with matching getter names on source and target will be run through the builder");
                    continue;
                }

                try {
                    Method sourceGetter = sourcePropertyData.getPropertyMethod();
                    Method targetGetter = targetPropertyData.getPropertyMethod();

                    if (!List.class.isAssignableFrom(sourceGetter.getReturnType())) {
                        buildFunction.build(builder, sourceGetter.invoke(source), targetGetter.invoke(target));
                    } else {
                        List sourceList = (List) sourceGetter.invoke(source);
                        List targetList = (List) targetGetter.invoke(target);
                        if (sourceList == null || targetList == null) {
                            continue;
                        }

                        for (int i = 0; i < sourceList.size(); i++) {
                            Object sourceObject = sourceList.get(i);
                            Object targetObject = targetList.get(i);

                            buildFunction.build(builder, sourceObject, targetObject);
                        }
                    }
                } catch (IllegalAccessException iae) {
                    LOGGER.warn("Could not access getter method", iae);
                    throw new RuntimeException(iae);
                } catch (InvocationTargetException ex) {
                    LOGGER.error("Unexpected exception: ", ex);
                    throw new RuntimeException(ex);
                }
            }
        }
    }

    private class PropertyData {
        private String builderName;
        private Method propertyMethod;

        PropertyData(String builderName, Method propertyMethod) {
            this.builderName = builderName;
            this.propertyMethod = propertyMethod;
        }

        /**
         * Gets builderName
         *
         * @return value of builderName
         */
        String getBuilderName() {
            return builderName;
        }

        /**
         * Gets propertyMethod
         *
         * @return value of propertyMethod
         */
        Method getPropertyMethod() {
            return propertyMethod;
        }
    }
}