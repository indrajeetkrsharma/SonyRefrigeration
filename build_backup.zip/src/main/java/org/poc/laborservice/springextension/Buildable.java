package org.poc.laborservice.springextension;

import java.lang.annotation.*;

/**
 * Annotation used to mark up model and info classes that should be mapped using a builder class.
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface Buildable {
    /**
     * Class representing the builder for this model or info class
     * @return Builder class
     */
    Class<? extends Builder> value();
}