package org.poc.laborservice.springextension;

import org.springframework.http.ResponseEntity;

/**
 * Thrown when a failure response is received from the UAA service.
 */
public class UaaTokenException extends RuntimeException {
	private ResponseEntity uaaResponse;

	/**
	 * Instantiate a new exception with a message.
	 *
	 * @param message message
	 */
	public UaaTokenException(String message) {
		super(message);
	}

	/**
	 * Instantiate a new exception with a message and UAA response.
	 *
	 * @param message     message
	 * @param uaaResponse UAA response
	 */
	public UaaTokenException(String message, ResponseEntity uaaResponse) {
		super(message);
		this.uaaResponse = uaaResponse;
	}

	/**
	 * Instantiate a new exception with a message and a cause.
	 *
	 * @param message message
	 * @param cause   cause
	 */
	public UaaTokenException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Get the UAA response if available.
	 *
	 * @return ResponseEntity
	 */
	public ResponseEntity getUaaResponse() {
		return uaaResponse;
	}

	/**
	 * Returns a full description of this throwable.
	 *
	 * @return a string representation of this throwable.
	 */
	public String getDescription() {
		StringBuilder s = new StringBuilder();
		Throwable e = this;
		while (e != null) {
			if (s.length() != 0) {
				s.append(": ");
			}
			s.append(e.toString());
			e = e.getCause();
		}
		if (getUaaResponse() != null) {
			s.append(": [").append(getUaaResponse().getStatusCode()).append("]");
			s.append(getUaaResponse().toString());
		}
		return s.toString();
	}
}

