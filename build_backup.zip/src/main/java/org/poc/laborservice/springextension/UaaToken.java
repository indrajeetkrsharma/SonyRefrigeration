package org.poc.laborservice.springextension;

import java.time.Instant;

/**
 * Encapsulates UAA token information.
 */
public class UaaToken {
	/**
	 * Access token.
	 */
	private final String accessToken;

	/**
	 * Refresh token.
	 */
	private final String refreshToken;

	/**
	 * Time to expire in seconds.
	 */
	private final int expirySeconds;

	/**
	 * Time at which token was received.
	 */
	private final Instant timestamp;

	/**
	 * Create a new instance of UAA token information.
	 *
	 * @param accessToken   access token
	 * @param refreshToken  refresh token
	 * @param expirySeconds expiry time in seconds
	 */
	public UaaToken(String accessToken, String refreshToken, int expirySeconds) {
		this.accessToken = accessToken;
		this.refreshToken = refreshToken;
		this.expirySeconds = expirySeconds;
		this.timestamp = Instant.now();
	}

	/**
	 * Get the access token.
	 * @return access token
	 */
	public String getAccessToken() {
		return accessToken;
	}

	/**
	 * Get the refresh token.
	 * @return refresh token
	 */
	public String getRefreshToken() {
		return refreshToken;
	}

	/**
	 * Get the expiry time in seconds.
	 * @return expiry in seconds
	 */
	public int getExpirySeconds() {
		return expirySeconds;
	}

	/**
	 * Get the timestamp the token was generated.
	 * @return token generation timestamp
	 */
	public Instant getCreationTimestamp() {
		return timestamp;
	}

	/**
	 * Is this token expired?
	 * @return true if expired, false if still valid
	 */
	public boolean isExpired() {
		// DOC - RFC6749 (The OAuth 2.0 Authorization Framework) implies that expirySeconds > 0
		return Instant.now().isAfter(timestamp.plusSeconds(expirySeconds));
	}
}

