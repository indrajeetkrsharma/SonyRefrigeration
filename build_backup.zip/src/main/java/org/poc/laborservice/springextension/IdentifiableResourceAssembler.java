package org.poc.laborservice.springextension;

import org.springframework.hateoas.Identifiable;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.ResourceAssembler;
import org.springframework.util.Assert;

import java.io.Serializable;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

/**
 * Assembler to build a resource for the given entity.
 */
public class IdentifiableResourceAssembler<T extends Identifiable<?>> implements ResourceAssembler<T, Resource<T>> {

    private final Class<?> controllerClass;

    /**
     * Creates a new {@link IdentifiableResourceAssembler} using the given controller class and resource type.
     *
     * @param controllerClass must not be {@literal null}.
     */
    public IdentifiableResourceAssembler(Class<?> controllerClass) {
        this.controllerClass = controllerClass;
    }

    @Override
    public Resource<T> toResource(T entity) {
        return createResource(entity);
    }

    /**
     * Creates a new resource and adds a self link to it consisting using the {@link Identifiable}'s id.
     *
     * @param entity must not be {@literal null}.
     * @return resource
     */
    protected Resource<T> createResource(T entity) {
        return createResourceWithId(entity);
    }

    protected Resource<T> createResourceWithId(T entity) {

        Assert.notNull(entity);
        Assert.notNull(entity.getId());

        Resource<T> resource = new Resource<>(entity);

        if (entity instanceof NestedIdentifiable) {
            resource.add(linkTo(controllerClass, ((NestedIdentifiable<Serializable>)entity).getParentId()).slash(entity.getId()).withSelfRel());
        } else {
            resource.add(linkTo(controllerClass).slash(entity.getId()).withSelfRel());
        }
        return resource;
    }
}

