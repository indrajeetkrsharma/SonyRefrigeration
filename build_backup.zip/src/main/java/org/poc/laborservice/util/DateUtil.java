package org.poc.laborservice.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateUtil {


	/**
	 * Getting date in string format.
	 * 
	 * @param date   date
	 * @param format format
	 * @return String
	 */
	public static String getDateToStringDate(Date date, String format) {
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		return formatter.format(date);
	}

	/**
	 * Converts Date String of particular format to Date object.
	 *
	 * @param inFormat the in format
	 * @param inDate   the in date
	 * @return the date object
	 */
	public static Date getDateObject(String inFormat, String inDate) {
		Date dateObject = null;
		try {
			DateFormat format = new SimpleDateFormat(inFormat);
			format.setTimeZone(TimeZone.getTimeZone("UTC"));
			dateObject = format.parse(inDate);
		} catch (ParseException e) {

		}
		return dateObject;
	}

	public static boolean isValidISO8601DateString(String dateTimeString) {
		
		if (dateTimeString==null) return false;
		
		String iso860UtcRegExp = "\\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[1-2]\\d|3[0-1])T(?:[0-1]\\d|2[0-3]):[0-5]\\d:[0-5]\\d.[0-9][0-9][0-9]Z";
		Pattern pattern = Pattern.compile(iso860UtcRegExp);
		Matcher matcher = pattern.matcher(dateTimeString);
		if (!matcher.matches())
			return false;
		else
			return true;
	}

	public static boolean isValidDateRange(String startDate, String endDate) {
		Date startTime = DateUtil.getDateObject("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", startDate);
		Date endTime = DateUtil.getDateObject("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", endDate);
		// endTime should later or same as startTime
		if (endTime.compareTo(startTime)>=0) {
			return true;
		}
		return false;
	}
}
