package org.poc.laborservice.mappers.assemblers;

import org.poc.laborservice.apis.LaborRecordInfo;
import org.poc.laborservice.controllers.LaborRecordController;
import org.poc.laborservice.springextension.IdentifiableResourceAssembler;
import org.springframework.stereotype.Component;

@Component
public class LaborRecordResourceAssembler extends IdentifiableResourceAssembler<LaborRecordInfo> {

	/**
	     * Creates a new {@link LaborRecordResourceAssembler}.
	     */
    public LaborRecordResourceAssembler() {
        super(LaborRecordController.class);
    }    
}

