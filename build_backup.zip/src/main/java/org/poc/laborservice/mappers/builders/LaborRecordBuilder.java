package org.poc.laborservice.mappers.builders;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.poc.laborservice.apis.LaborRecordInfo;
import org.poc.laborservice.models.LaborRecord;
import org.poc.laborservice.springextension.BuilderAdapter;
import org.springframework.stereotype.Repository;

@Repository
public class LaborRecordBuilder extends BuilderAdapter<LaborRecord, LaborRecordInfo> {



	@Override
	protected void enhanceMapper(ModelMapper mapper) {
		TypeMap<LaborRecord, LaborRecordInfo> map = mapper.createTypeMap(LaborRecord.class, LaborRecordInfo.class);
		map.addMapping(LaborRecord::getId, LaborRecordInfo::setId);
	}

	/**
	 * Implement this method to specify the type of the Model class being used by
	 * the derived class. We need this because of stupid type erasure.
	 *
	 * @return Type of the Model class
	 */
	@Override
	protected Class<LaborRecord> getMClass() {
		return LaborRecord.class;
	}

	/**
	 * Implement this method to specify the type of the Info class being used by the
	 * derived class. We need this because of stupid type erasure.
	 *
	 * @return Type of the Info class
	 */
	@Override
	protected Class<LaborRecordInfo> getIClass() {
		return LaborRecordInfo.class;
	}

	@Override
	protected void postMapInfo(LaborRecord modelSource, LaborRecordInfo infoTarget) {
		infoTarget.setId(modelSource.getId());
	}

}
