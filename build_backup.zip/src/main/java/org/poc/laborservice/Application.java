package org.poc.laborservice;

import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.poc.laborservice.config.SwaggerMvcConfigurationAdapter;
import org.poc.laborservice.springextension.SpringApplicationContextInjector;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@SpringBootApplication
@EnableAutoConfiguration
public class Application {

	/**
	 * Set the service to run in UTC. Required in order for dates stored in the database to be stored in UTC
	 */
	@PostConstruct
	public void init() {
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
	}
	/**
	 * Rest Template for no authorization
	 * 
	 * @return RestTemplate
	 */
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

	@Bean
	WebMvcConfigurerAdapter webMvcConfigurerAdapter() {
		return new SwaggerMvcConfigurationAdapter();
	}


	public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
	
	/**
	 * Our Spring application context
	 * 
	 * @return singleton
	 */
	@Bean
	public SpringApplicationContextInjector springApplicationContextInjector() {
		return SpringApplicationContextInjector.getInstance();
	}

}
