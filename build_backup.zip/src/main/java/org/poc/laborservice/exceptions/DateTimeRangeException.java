package org.poc.laborservice.exceptions;

public class DateTimeRangeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DateTimeRangeException() {
		// TODO Auto-generated constructor stub
	}
	
	public DateTimeRangeException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
	public ErrorCode getErrorCode() {
		return ErrorCode.ResourceNotFound;
	}

}
