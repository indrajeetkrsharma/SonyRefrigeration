package org.poc.laborservice.exceptions;

public enum InvalidDataErrorType {

	InvalidSegmentDocument, InternalServerError, JSONParsingException, IOException;

	/**
	 * Convenience method to case-insensitively convert a string to a enum value.
	 * 
	 * @param enumeration
	 *            Enum class to convert to.
	 * @param suspect
	 *            Suspect string.
	 * @param <T>
	 *            Enum class type.
	 * @return Enum value or null if no match.
	 */
	public static <T extends Enum<?>> T searchEnum(Class<T> enumeration, String suspect) {
		for (T each : enumeration.getEnumConstants()) {
			if (each.name().compareToIgnoreCase(suspect) == 0) {
				return each;
			}
		}
		return null;
	}

}