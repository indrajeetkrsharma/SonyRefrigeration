package org.poc.laborservice.exceptions;

public enum ErrorCode {
	ResourceNotFound,
	InvalidInput
}
