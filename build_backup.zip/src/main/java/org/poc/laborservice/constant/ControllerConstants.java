package org.poc.laborservice.constant;

public class ControllerConstants {

	public static final String SEPARATOR = " - ";

	public static final String NO_CONTENT = "No Content";

	public static final String SERVER_ERROR_MSG = "Unable to process data! Please check the logs.";

	public static final String IO_EXCEPTION = "I/O Exception";

	public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";

	public static final String BAD_REQUEST = "Bad Request";

	public static final String CONNECTION_ERROR = "Connection Error";

	public static final String DELETE_LABOR_ERROR = "Error deleting labor record";

	public static final String ADD_LABOR_ERROR = "Error adding labor record";

	public static final String UPDATE_LABOR_ERROR = "Error updating labor record";
	
	public static final String QUERY_LABOR_ERROR = "Error querying labor record";

	public static final String DATE_TIME_FORMAT_ERROR = "DateTime field is not in format yyyy-MM-dd'T'HH:mm:ss.fffZ";

	public static final String DATA_ACCESS_VIOLATION_ERROR = "attempt to insert or update data results in violation of an integrity constraint";

	public static final String LABOR_TYPE_ID_NULLCHECK_MESSAGE = "laborTypeId can't be null or blank";

	public static final String START_DATE_TIME_NULLCHECK_MESSAGE = "startTime can't be null or blank";

	public static final String END_DATE_TIME_NULLCHECK_MESSAGE = "endTime can't be null or blank";

	public static final String SEGMENT_ACTUAL_ID_NULLCHECK_MESSAGE = "segmentActualId can't be null or blank";

	public static final String USER_NAME_NULLCHECK_MESSAGE = "userName can't be null or blank";

	public static final String CREATED_BY_NULLCHECK_MESSAGE = "createdBy can't be null or blank";

	public static final String MODIFIED_BY_NULLCHECK_MESSAGE = "modifiedBy can't be null or blank";

	public static final String START_DATE_TIME_AND_END_DATE_TIME_CHECK_MESSAGE = "endTime can't be less than startTime";
}