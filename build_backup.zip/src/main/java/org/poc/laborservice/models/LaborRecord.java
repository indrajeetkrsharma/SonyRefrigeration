package org.poc.laborservice.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
@Table(name = "Labor", schema = "abc")
public class LaborRecord {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull
	@Column(name = "LaborTypeId", nullable = false)
	private Long laborTypeId;

	@NotNull
	@Column(name = "SegmentActualId", nullable = false)
	private Long segmentActualId;

	@NotNull
	@Column(name = "StartTime", nullable = false)
	private Date startTime;

	@Column(name = "EndTime", nullable = true)
	private Date endTime;

	@Column(name = "AppliedTime", nullable = true)
	private Long appliedTime;

	@NotNull
	@Column(name = "UserName", nullable = false, length = 100)
	private String userName;

	@NotNull
	@Column(name = "CreatedOn", nullable = false)
	private Date createdOn;

	@NotNull
	@Column(name = "CreatedBy", nullable = false, length = 100)
	private String createdBy;

	@Column(name = "ModifiedOn", nullable = true)
	private Date modifiedOn;

	@Column(name = "ModifiedBy", nullable = true, length = 100)
	private String modifiedBy;

	public LaborRecord() {
		// Default constructor
	}

	public LaborRecord(Long id, Long laborTypeId, Long segmentActualId, Date startTime, Date endTime, Long appliedTime,
			String userName, Date createdOn, String createdBy, Date modifiedOn, String modifiedBy) {
		this.id = id;
		this.laborTypeId = laborTypeId;
		this.segmentActualId = segmentActualId;
		this.startTime = startTime;
		this.endTime = endTime;
		this.appliedTime = appliedTime;
		this.userName = userName;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.modifiedOn = modifiedOn;
		this.modifiedBy = modifiedBy;
	}


}
