package org.poc.laborservice.cache;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.hateoas.PagedResources;
import org.springframework.hateoas.Resource;
import org.springframework.stereotype.Service;

@Service
public class ProductCacheServiceImpl implements ProductCacheService {

	private static final String DATA_PULL = "Get all materials data from product service";
	private static final String ENGINEERING_UNIT_DATA_PULL = "Get engineering unit from product service";

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductCacheServiceImpl.class);

//	@Autowired
//	private ProductManager productManager;
//	
//	
//	/**
//	 * This method use to get all products from product service.
//	 * @param cacheId
//	 * @return PagedResources<Resource<ProductInfo>> 
//	 */
//	@Override
//	@Cacheable(value = "productsData", cacheManager = "sdsCacheManager", key = "{#cacheId}")
//	public PagedResources<Resource<ProductInfo>> getAllProducts(int cacheId) {
//		LOGGER.info(DATA_PULL);
//		return productManager.getProducts();
//	}
//
//	/**
//	 * This method use to get engineering unit from product service based on id.
//	 * @param  engineeringUnitId
//	 * @return EngineeringUnit
//	 */
//	@Override
//	@Cacheable(value = "engineeringUnitData", cacheManager = "sdsCacheManager", key = "{#engineeringUnitId}")
//	public EngineeringUnit getEnginneringUnit(Long engineeringUnitId) {
//		LOGGER.info(ENGINEERING_UNIT_DATA_PULL);
//		return productManager.getEnginneringUnit(engineeringUnitId);
//	}
}
