package org.poc.laborservice.cache;

import org.springframework.hateoas.PagedResources;
import org.springframework.hateoas.Resource;

public interface ProductCacheService {
	
	/**
	 * This method use to get all products from product service.
	 * @param int cacheId
	 * @return PagedResources<Resource<ProductInfo>> 
	 */
	//public PagedResources<Resource<ProductInfo>> getAllProducts(int cacheId);
	
	/**
	 * This method use to get engineering unit from product service based on id.
	 * @param  engineeringUnitId
	 * @return EngineeringUnit
	 */
	//public EngineeringUnit getEnginneringUnit(Long engineeringUnitId);

}
