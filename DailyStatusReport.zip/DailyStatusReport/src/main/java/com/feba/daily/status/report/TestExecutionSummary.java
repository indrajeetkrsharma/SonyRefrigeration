package com.feba.daily.status.report;

public class TestExecutionSummary {
	private int sev;
	private int open;
	private int clossed;
	private int rejected;
	private int deferred;
	private int reopen;
	public int getSev() {
		return sev;
	}
	public void setSev(int sev) {
		this.sev = sev;
	}
	public int getOpen() {
		return open;
	}
	public void setOpen(int open) {
		this.open = open;
	}
	public int getClossed() {
		return clossed;
	}
	public void setClossed(int clossed) {
		this.clossed = clossed;
	}
	public int getRejected() {
		return rejected;
	}
	public void setRejected(int rejected) {
		this.rejected = rejected;
	}
	public int getDeferred() {
		return deferred;
	}
	public void setDeferred(int deferred) {
		this.deferred = deferred;
	}
	public int getReopen() {
		return reopen;
	}
	public void setReopen(int reopen) {
		this.reopen = reopen;
	}
	

}
