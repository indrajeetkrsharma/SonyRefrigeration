package com.feba.daily.status.report;

public class TestDefectSummary {

}
