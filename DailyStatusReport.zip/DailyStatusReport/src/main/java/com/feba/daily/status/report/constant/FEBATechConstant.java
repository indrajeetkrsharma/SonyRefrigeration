package com.feba.daily.status.report.constant;

public class FEBATechConstant
{
	public static String updateActivity = "UPDATE";
	
	public static String saveActivity = "SAVE";
}
