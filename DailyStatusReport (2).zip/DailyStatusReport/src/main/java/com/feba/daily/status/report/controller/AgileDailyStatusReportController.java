package com.feba.daily.status.report.controller;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.NoResultException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.feba.daily.status.report.bean.AdmRaidLogBean;
import com.feba.daily.status.report.bean.AdmTestDesignSummaryBean;
import com.feba.daily.status.report.bean.AdmTestExecutionSummaryBean;
import com.feba.daily.status.report.bean.DailyStatusReportBean;
import com.feba.daily.status.report.bean.RtsTestDesignSummaryBean;
import com.feba.daily.status.report.bean.RtsTestExecutionSummaryBean;
import com.feba.daily.status.report.persistance.AdmDailyStatusReportNFT;
import com.feba.daily.status.report.service.CommonService;
import com.feba.daily.status.report.util.DailyStatusReportUtil;
import com.feba.daily.status.report.util.DropDownMenu;
import com.feba.daily.status.report.validator.InputValidator;


@Controller
public class AgileDailyStatusReportController 
{
	final static Logger logger = Logger.getLogger(AgileDailyStatusReportController.class);
		
	@Autowired
	CommonService commonService;
	
	@Autowired(required=true)
	InputValidator inputValidator;
	
	boolean isFirstTimeSearch = false;
	
	private String searchDate;
	
	private String searchSdpId;
	
	public AgileDailyStatusReportController()
	{
		BasicConfigurator.configure();
	}
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(inputValidator);
	}
	
	@RequestMapping(value = "/agileInput.html", method = RequestMethod.GET)
	public ModelAndView loadAgileDailyStatusReportNFT(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean)
	{
		logger.debug("loadAgileDailyStatusReportNFT() - START");
		DropDownMenu dropDownMenu = new DropDownMenu();
		ModelAndView modelAndView = new ModelAndView("agileInput");
		dailyStatusReportBean.setReportDate(new Date());
		String todayDate = DailyStatusReportUtil.getDateToStringDate(new Date(), "MM/dd/yyyy");
		modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
		modelAndView.addObject("todayDate", todayDate);
		logger.debug("loadAgileDailyStatusReportNFT() - END");
		return modelAndView;
	}
	
	@RequestMapping(value = "/submitAgileDailyStatusReport.html", method = RequestMethod.POST)
	public ModelAndView submitAgileDailyStatusReportNFT(@ModelAttribute("userForm") @Validated DailyStatusReportBean dailyStatusReportBean, 
			BindingResult result, Model model, final RedirectAttributes redirectAttributes, HttpServletRequest request)
	{
		logger.debug("submitAgileDailyStatusReportNFT() - START");
		ModelAndView modelAndView = null;
		if (result.hasErrors()) 
		{
			DropDownMenu dropDownMenu = new DropDownMenu();
			modelAndView = new ModelAndView("input");
			modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
		} 
		else 
		{
			try
			{
				List<AdmRaidLogBean> admRaidLogBeanList = new LinkedList<AdmRaidLogBean>();
				List<AdmTestExecutionSummaryBean> admTestExecutionSummaryBeansList = new LinkedList<AdmTestExecutionSummaryBean>();
				List<AdmTestDesignSummaryBean> admTestDesignSummaryBeansList = new LinkedList<AdmTestDesignSummaryBean>();
				List<RtsTestDesignSummaryBean> rtsTestDesignSummaryBeansList = new LinkedList<RtsTestDesignSummaryBean>();
				List<RtsTestExecutionSummaryBean> rtsTestExecutionSummaryBeansList = new LinkedList<RtsTestExecutionSummaryBean>();
				
				AdmRaidLogBean admRaidLogBean = null;
				AdmTestDesignSummaryBean admTestDesignSummaryBean = null;
				AdmTestExecutionSummaryBean admTestExecutionSummaryBean = null;
				RtsTestDesignSummaryBean rtsTestDesignSummaryBean = null;
				RtsTestExecutionSummaryBean rtsTestExecutionSummaryBean = null;
				
				if(request.getParameter("rowCount") != null && !"".equals(request.getParameter("rowCount")) && request.getParameter("rowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("rowCount"));
					System.out.println("Row Count Value "+rowCount);
					logger.debug("Row Count Value "+rowCount);
					for(int i = 1; i <= rowCount; i++)
					{
						System.out.println("Type Value : "+request.getParameter("type"+i));
						logger.debug("Type Value : "+request.getParameter("type"+i));
						admRaidLogBean = new AdmRaidLogBean();
						admRaidLogBean.setType(request.getParameter("type"+i));
						admRaidLogBean.setScrum(request.getParameter("scrum"+i));
						admRaidLogBean.setScrumManager(request.getParameter("scrumManager"+i));
						admRaidLogBean.setImpactedApp(request.getParameter("impactedApp"+i));
						admRaidLogBean.setIssueOwner(request.getParameter("issueOwner"+i));
						admRaidLogBean.setPriority(request.getParameter("priority"+i));
						admRaidLogBean.setDescription(request.getParameter("description"+i));
						admRaidLogBean.setStatus(request.getParameter("status"+i));
						admRaidLogBean.setPortfolioManager(request.getParameter("portfolioManager"+i));
						admRaidLogBean.setRadiOwner(request.getParameter("radiOwner"+i));
						admRaidLogBean.setRag(request.getParameter("rag"+i));
						logger.debug("Logged Date : "+request.getParameter("dateLogged"+i));
						Date loggedDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("dateLogged"+i));
						admRaidLogBean.setDateLogged(loggedDate);
						Date targetClosureDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("targetClosureDate"+i));
						admRaidLogBean.setTargetClosureDate(targetClosureDate);
						admRaidLogBean.setAge(request.getParameter("age"+i));
						admRaidLogBean.setMileStoneImpacted(request.getParameter("mileStoneImpacted"+i));
						admRaidLogBean.setRaidBackToGreenPlan(request.getParameter("raidBackToGreenPlan"+i));
						admRaidLogBeanList.add(admRaidLogBean);
					}
					dailyStatusReportBean.setAdmRaidLogBeanList(admRaidLogBeanList);
				}
				
				if(request.getParameter("admTestDesignSummaryRowCount") != null && !"".equals(request.getParameter("admTestDesignSummaryRowCount")) && request.getParameter("admTestDesignSummaryRowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("admTestDesignSummaryRowCount"));
					for(int i = 1; i <= rowCount; i++)
					{
						admTestDesignSummaryBean = new AdmTestDesignSummaryBean();
						admTestDesignSummaryBean.setSmtDirect((request.getParameter("admTdsSmtDirect"+i) == null ) ? "NA" : request.getParameter("admTdsSmtDirect"+i));
						admTestDesignSummaryBean.setRag((request.getParameter("admTdsRag"+i) == null ) ? "NA" : request.getParameter("admTdsRag"+i));
						admTestDesignSummaryBean.setTotal((request.getParameter("admTdsTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsTotal"+i)));
						admTestDesignSummaryBean.setInProgress((request.getParameter("admTdsInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsInProgress"+i)));
						admTestDesignSummaryBean.setOnHold((request.getParameter("admTdsOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsOnHold"+i)));
						admTestDesignSummaryBean.setCompleted((request.getParameter("admTdsCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsCompleted"+i)));						
						admTestDesignSummaryBean.setSeverity1((request.getParameter("admTdsSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev1"+i)));
						admTestDesignSummaryBean.setSeverity2((request.getParameter("admTdsSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev2"+i)));
						admTestDesignSummaryBean.setSeverity3((request.getParameter("admTdsSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev3"+i)));
						admTestDesignSummaryBean.setSeverity4((request.getParameter("admTdsSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev4"+i)));
						admTestDesignSummaryBean.setTotalSeverity((request.getParameter("admTdsTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsTotalSeverity"+i)));
						
						admTestDesignSummaryBeansList.add(admTestDesignSummaryBean);
					}
					dailyStatusReportBean.setAdmTestDesignSummaryList(admTestDesignSummaryBeansList);
				}
				
				if(request.getParameter("admTestExectuionSummaryRowCount") != null && !"".equals(request.getParameter("admTestExectuionSummaryRowCount")) && request.getParameter("admTestExectuionSummaryRowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("admTestExectuionSummaryRowCount"));
					for(int i = 1; i <= rowCount; i++)
					{
						admTestExecutionSummaryBean = new AdmTestExecutionSummaryBean();
						admTestExecutionSummaryBean.setSmtDirect((request.getParameter("admTesSmtDirect"+i) == null ) ? "NA" : request.getParameter("admTesSmtDirect"+i));
						admTestExecutionSummaryBean.setRag((request.getParameter("admTesRag"+i) == null ) ? "NA" : request.getParameter("admTesRag"+i));
						admTestExecutionSummaryBean.setTotal((request.getParameter("admTesTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesTotal"+i)));
						admTestExecutionSummaryBean.setInProgress((request.getParameter("admTesInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesInProgress"+i)));
						admTestExecutionSummaryBean.setOnHold((request.getParameter("admTesOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesOnHold"+i)));
						admTestExecutionSummaryBean.setCompleted((request.getParameter("admTesCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesCompleted"+i)));						
						admTestExecutionSummaryBean.setSeverity1((request.getParameter("admTesSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev1"+i)));
						admTestExecutionSummaryBean.setSeverity2((request.getParameter("admTesSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev2"+i)));
						admTestExecutionSummaryBean.setSeverity3((request.getParameter("admTesSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev3"+i)));
						admTestExecutionSummaryBean.setSeverity4((request.getParameter("admTesSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev4"+i)));
						admTestExecutionSummaryBean.setTotalSeverity((request.getParameter("admTesTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesTotalSeverity"+i)));
												
						admTestExecutionSummaryBeansList.add(admTestExecutionSummaryBean);
					}
					dailyStatusReportBean.setAdmTestExecutionSummaryList(admTestExecutionSummaryBeansList);
				}
				//RTS
				if(request.getParameter("rtsTestDesignSummaryRowCount") != null && !"".equals(request.getParameter("rtsTestDesignSummaryRowCount")) && request.getParameter("rtsTestDesignSummaryRowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("rtsTestDesignSummaryRowCount"));
					for(int i = 1; i <= rowCount; i++)
					{
						rtsTestDesignSummaryBean = new RtsTestDesignSummaryBean();
						rtsTestDesignSummaryBean.setSmtDirect((request.getParameter("rtsTdsSmtDirect"+i) == null ) ? "NA" : request.getParameter("rtsTdsSmtDirect"+i));
						rtsTestDesignSummaryBean.setRag((request.getParameter("rtsTdsRag"+i) == null ) ? "NA" : request.getParameter("rtsTdsRag"+i));
						rtsTestDesignSummaryBean.setTotal((request.getParameter("rtsTdsTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsTotal"+i)));
						rtsTestDesignSummaryBean.setInProgress((request.getParameter("rtsTdsInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsInProgress"+i)));
						rtsTestDesignSummaryBean.setOnHold((request.getParameter("rtsTdsOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsOnHold"+i)));
						rtsTestDesignSummaryBean.setCompleted((request.getParameter("rtsTdsCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsCompleted"+i)));						
						rtsTestDesignSummaryBean.setSeverity1((request.getParameter("rtsTdsSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev1"+i)));
						rtsTestDesignSummaryBean.setSeverity2((request.getParameter("rtsTdsSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev2"+i)));
						rtsTestDesignSummaryBean.setSeverity3((request.getParameter("rtsTdsSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev3"+i)));
						rtsTestDesignSummaryBean.setSeverity4((request.getParameter("rtsTdsSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev4"+i)));
						rtsTestDesignSummaryBean.setTotalSeverity((request.getParameter("rtsTdsTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsTotalSeverity"+i)));
						
						rtsTestDesignSummaryBeansList.add(rtsTestDesignSummaryBean);
					}
					dailyStatusReportBean.setRtsTestDesignSummaryList(rtsTestDesignSummaryBeansList);
				}
				
				if(request.getParameter("rtsTestExectuionSummaryRowCount") != null && !"".equals(request.getParameter("rtsTestExectuionSummaryRowCount")) && request.getParameter("rtsTestExectuionSummaryRowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("rtsTestExectuionSummaryRowCount"));
					for(int i = 1; i <= rowCount; i++)
					{
						rtsTestExecutionSummaryBean = new RtsTestExecutionSummaryBean();
						rtsTestExecutionSummaryBean.setSmtDirect((request.getParameter("rtsTesSmtDirect"+i) == null ) ? "NA" : request.getParameter("rtsTesSmtDirect"+i));
						rtsTestExecutionSummaryBean.setRag((request.getParameter("rtsTesRag"+i) == null ) ? "NA" : request.getParameter("rtsTesRag"+i));
						rtsTestExecutionSummaryBean.setTotal((request.getParameter("rtsTesTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesTotal"+i)));
						rtsTestExecutionSummaryBean.setInProgress((request.getParameter("rtsTesInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesInProgress"+i)));
						rtsTestExecutionSummaryBean.setOnHold((request.getParameter("rtsTesOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesOnHold"+i)));
						rtsTestExecutionSummaryBean.setCompleted((request.getParameter("rtsTesCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesCompleted"+i)));						
						rtsTestExecutionSummaryBean.setSeverity1((request.getParameter("rtsTesSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev1"+i)));
						rtsTestExecutionSummaryBean.setSeverity2((request.getParameter("rtsTesSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev2"+i)));
						rtsTestExecutionSummaryBean.setSeverity3((request.getParameter("rtsTesSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev3"+i)));
						rtsTestExecutionSummaryBean.setSeverity4((request.getParameter("rtsTesSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev4"+i)));
						rtsTestExecutionSummaryBean.setTotalSeverity((request.getParameter("rtsTesTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesTotalSeverity"+i)));
												
						rtsTestExecutionSummaryBeansList.add(rtsTestExecutionSummaryBean);
					}
					dailyStatusReportBean.setRtsTestExecutionSummaryList(rtsTestExecutionSummaryBeansList);
				}
				modelAndView = new ModelAndView("agileInput");
				commonService.saveAgileDailStatusReport(dailyStatusReportBean);
				modelAndView.addObject("css", "success");
				modelAndView.addObject("msg", "Record inserted successfully!");
				
				logger.debug("submitDailyStatusReportNFT() - END");
			} catch (Exception e)
			{
				logger.error("Error Occured during saving data : ", e);
				modelAndView = new ModelAndView("input");
				modelAndView.addObject("css", "success");
				modelAndView.addObject("msg", "Duplicate Entry please insert uniqueu record!");
			}
			
		}
		return modelAndView;
	}
	
	@RequestMapping(value = "/loadAgileDsrUpdateDelete.html", method = RequestMethod.GET)
	public ModelAndView loadAgileDsrUpdateDelete(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("loadDailyStatusReportNFT() - START");
		ModelAndView modelAndView = new ModelAndView("agileInputUpdate");
		try
		{
			String dateIn = request.getParameter("searchDate");
			String searchSdpId = request.getParameter("searchSdpId");
			Date searchDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", dateIn);
			this.searchDate = dateIn;
			this.searchSdpId = searchSdpId;
			
			List<AdmDailyStatusReportNFT> dailyStatusReportNFTs;
			dailyStatusReportNFTs =  commonService.searchByInsertedDateAndSPDIdForAgile(searchDate, searchSdpId);
			AdmDailyStatusReportNFT dailyStatusReportNFT = dailyStatusReportNFTs.get(0);
			BeanUtils.copyProperties(dailyStatusReportNFT, dailyStatusReportBean);
			
			System.out.println("loadAgileDsrUpdateDelete Object Id : "+ dailyStatusReportBean.getId());
			
			DropDownMenu dropDownMenu = new DropDownMenu();
			
			modelAndView.addObject("userForm", dailyStatusReportBean);
			modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
			modelAndView.addObject("raidLogStausDropDownList", dropDownMenu.raidLogStausDropDownList());
			logger.debug("RaidLog list size : "+dailyStatusReportNFT.getAdmRaidLogs().size());
			modelAndView.addObject("admRaidLogsList", dailyStatusReportNFT.getAdmRaidLogs());
			modelAndView.addObject("admTestDesignSummary", dailyStatusReportNFT.getAdmTestDesignSummaries());
			modelAndView.addObject("admTestExecutionSummary", dailyStatusReportNFT.getAdmTestExecutionSummaries());
			modelAndView.addObject("rtsTestDesignSummary", dailyStatusReportNFT.getRtsTestDesignSummary());
			modelAndView.addObject("rtsTestExecutionSummary", dailyStatusReportNFT.getRtsTestExecutionSummary());
			
		} catch (NoResultException e)
		{
			modelAndView.addObject("userForm", dailyStatusReportBean);
			modelAndView.addObject("css", "success");
			modelAndView.addObject("msg", "No Record Found!");
		} catch (BeansException e)
		{
		}
		
		logger.debug("loadDailyStatusReportNFT() - END");
		return modelAndView;
	}
	
	
	@RequestMapping(value = "/updateDeleteAgileDSR.html", method = {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView updateDeleteAgileDsr(@ModelAttribute("userForm") @Validated DailyStatusReportBean dailyStatusReportBean, 
			BindingResult result, Model model, final RedirectAttributes redirectAttributes, HttpServletRequest request)
	{
		logger.debug("updateDeleteAgileDsr() - START");
		logger.debug("updateOrDeleteDailyStatusReport Object Id : "+ dailyStatusReportBean.getId());
		ModelAndView modelAndView = new ModelAndView("agileInputUpdate");
		if (result.hasErrors()) 
		{
			DropDownMenu dropDownMenu = new DropDownMenu();
			modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
			return modelAndView;
		} 
		else 
		{
			try
			{
				String addAsANewRecord = request.getParameter("addAsANewRecord");
				if("Yes".equals(addAsANewRecord))
				{
					List<AdmRaidLogBean> admRaidLogBeanList = new LinkedList<AdmRaidLogBean>();
					List<AdmTestExecutionSummaryBean> admTestExecutionSummaryBeansList = new LinkedList<AdmTestExecutionSummaryBean>();
					List<AdmTestDesignSummaryBean> admTestDesignSummaryBeansList = new LinkedList<AdmTestDesignSummaryBean>();
					List<RtsTestDesignSummaryBean> rtsTestDesignSummaryBeansList = new LinkedList<RtsTestDesignSummaryBean>();
					List<RtsTestExecutionSummaryBean> rtsTestExecutionSummaryBeansList = new LinkedList<RtsTestExecutionSummaryBean>();
					
					AdmRaidLogBean admRaidLogBean = null;
					AdmTestDesignSummaryBean admTestDesignSummaryBean = null;
					AdmTestExecutionSummaryBean admTestExecutionSummaryBean = null;
					RtsTestDesignSummaryBean rtsTestDesignSummaryBean = null;
					RtsTestExecutionSummaryBean rtsTestExecutionSummaryBean = null;
					
					if(request.getParameter("rowCount") != null && !"".equals(request.getParameter("rowCount")) && request.getParameter("rowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("rowCount"));
						System.out.println("Row Count Value "+rowCount);
						logger.debug("Row Count Value "+rowCount);
						for(int i = 1; i <= rowCount; i++)
						{
							System.out.println("Type Value : "+request.getParameter("type"+i));
							logger.debug("Type Value : "+request.getParameter("type"+i));
							admRaidLogBean = new AdmRaidLogBean();
							admRaidLogBean.setType(request.getParameter("type"+i));
							admRaidLogBean.setScrum(request.getParameter("scrum"+i));
							admRaidLogBean.setScrumManager(request.getParameter("scrumManager"+i));
							admRaidLogBean.setImpactedApp(request.getParameter("impactedApp"+i));
							admRaidLogBean.setIssueOwner(request.getParameter("issueOwner"+i));
							admRaidLogBean.setPriority(request.getParameter("priority"+i));
							admRaidLogBean.setDescription(request.getParameter("description"+i));
							admRaidLogBean.setStatus(request.getParameter("status"+i));
							admRaidLogBean.setPortfolioManager(request.getParameter("portfolioManager"+i));
							admRaidLogBean.setRadiOwner(request.getParameter("radiOwner"+i));
							admRaidLogBean.setRag(request.getParameter("rag"+i));
							logger.debug("Logged Date : "+request.getParameter("dateLogged"+i));
							Date loggedDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("dateLogged"+i));
							admRaidLogBean.setDateLogged(loggedDate);
							Date targetClosureDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("targetClosureDate"+i));
							admRaidLogBean.setTargetClosureDate(targetClosureDate);
							admRaidLogBean.setAge(request.getParameter("age"+i));
							admRaidLogBean.setMileStoneImpacted(request.getParameter("mileStoneImpacted"+i));
							admRaidLogBean.setRaidBackToGreenPlan(request.getParameter("raidBackToGreenPlan"+i));
							admRaidLogBeanList.add(admRaidLogBean);
						}
						dailyStatusReportBean.setAdmRaidLogBeanList(admRaidLogBeanList);
					}
					
					if(request.getParameter("admTestDesignSummaryRowCount") != null && !"".equals(request.getParameter("admTestDesignSummaryRowCount")) && request.getParameter("admTestDesignSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("admTestDesignSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							admTestDesignSummaryBean = new AdmTestDesignSummaryBean();
							admTestDesignSummaryBean.setSmtDirect((request.getParameter("admTdsSmtDirect"+i) == null ) ? "NA" : request.getParameter("admTdsSmtDirect"+i));
							admTestDesignSummaryBean.setRag((request.getParameter("admTdsRag"+i) == null ) ? "NA" : request.getParameter("admTdsRag"+i));
							admTestDesignSummaryBean.setTotal((request.getParameter("admTdsTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsTotal"+i)));
							admTestDesignSummaryBean.setInProgress((request.getParameter("admTdsInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsInProgress"+i)));
							admTestDesignSummaryBean.setOnHold((request.getParameter("admTdsOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsOnHold"+i)));
							admTestDesignSummaryBean.setCompleted((request.getParameter("admTdsCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsCompleted"+i)));						
							admTestDesignSummaryBean.setSeverity1((request.getParameter("admTdsSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev1"+i)));
							admTestDesignSummaryBean.setSeverity2((request.getParameter("admTdsSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev2"+i)));
							admTestDesignSummaryBean.setSeverity3((request.getParameter("admTdsSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev3"+i)));
							admTestDesignSummaryBean.setSeverity4((request.getParameter("admTdsSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsSev4"+i)));
							admTestDesignSummaryBean.setTotalSeverity((request.getParameter("admTdsTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTdsTotalSeverity"+i)));
							
							admTestDesignSummaryBeansList.add(admTestDesignSummaryBean);
						}
						dailyStatusReportBean.setAdmTestDesignSummaryList(admTestDesignSummaryBeansList);
					}
					
					if(request.getParameter("admTestExectuionSummaryRowCount") != null && !"".equals(request.getParameter("admTestExectuionSummaryRowCount")) && request.getParameter("admTestExectuionSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("admTestExectuionSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							admTestExecutionSummaryBean = new AdmTestExecutionSummaryBean();
							admTestExecutionSummaryBean.setSmtDirect((request.getParameter("admTesSmtDirect"+i) == null ) ? "NA" : request.getParameter("admTesSmtDirect"+i));
							admTestExecutionSummaryBean.setRag((request.getParameter("admTesRag"+i) == null ) ? "NA" : request.getParameter("admTesRag"+i));
							admTestExecutionSummaryBean.setTotal((request.getParameter("admTesTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesTotal"+i)));
							admTestExecutionSummaryBean.setInProgress((request.getParameter("admTesInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesInProgress"+i)));
							admTestExecutionSummaryBean.setOnHold((request.getParameter("admTesOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesOnHold"+i)));
							admTestExecutionSummaryBean.setCompleted((request.getParameter("admTesCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesCompleted"+i)));						
							admTestExecutionSummaryBean.setSeverity1((request.getParameter("admTesSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev1"+i)));
							admTestExecutionSummaryBean.setSeverity2((request.getParameter("admTesSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev2"+i)));
							admTestExecutionSummaryBean.setSeverity3((request.getParameter("admTesSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev3"+i)));
							admTestExecutionSummaryBean.setSeverity4((request.getParameter("admTesSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesSev4"+i)));
							admTestExecutionSummaryBean.setTotalSeverity((request.getParameter("admTesTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("admTesTotalSeverity"+i)));
													
							admTestExecutionSummaryBeansList.add(admTestExecutionSummaryBean);
						}
						dailyStatusReportBean.setAdmTestExecutionSummaryList(admTestExecutionSummaryBeansList);
					}
					//RTS
					if(request.getParameter("rtsTestDesignSummaryRowCount") != null && !"".equals(request.getParameter("rtsTestDesignSummaryRowCount")) && request.getParameter("rtsTestDesignSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("rtsTestDesignSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							rtsTestDesignSummaryBean = new RtsTestDesignSummaryBean();
							rtsTestDesignSummaryBean.setSmtDirect((request.getParameter("rtsTdsSmtDirect"+i) == null ) ? "NA" : request.getParameter("rtsTdsSmtDirect"+i));
							rtsTestDesignSummaryBean.setRag((request.getParameter("rtsTdsRag"+i) == null ) ? "NA" : request.getParameter("rtsTdsRag"+i));
							rtsTestDesignSummaryBean.setTotal((request.getParameter("rtsTdsTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsTotal"+i)));
							rtsTestDesignSummaryBean.setInProgress((request.getParameter("rtsTdsInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsInProgress"+i)));
							rtsTestDesignSummaryBean.setOnHold((request.getParameter("rtsTdsOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsOnHold"+i)));
							rtsTestDesignSummaryBean.setCompleted((request.getParameter("rtsTdsCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsCompleted"+i)));						
							rtsTestDesignSummaryBean.setSeverity1((request.getParameter("rtsTdsSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev1"+i)));
							rtsTestDesignSummaryBean.setSeverity2((request.getParameter("rtsTdsSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev2"+i)));
							rtsTestDesignSummaryBean.setSeverity3((request.getParameter("rtsTdsSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev3"+i)));
							rtsTestDesignSummaryBean.setSeverity4((request.getParameter("rtsTdsSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsSev4"+i)));
							rtsTestDesignSummaryBean.setTotalSeverity((request.getParameter("rtsTdsTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTdsTotalSeverity"+i)));
							
							rtsTestDesignSummaryBeansList.add(rtsTestDesignSummaryBean);
						}
						dailyStatusReportBean.setRtsTestDesignSummaryList(rtsTestDesignSummaryBeansList);
					}
					
					if(request.getParameter("rtsTestExectuionSummaryRowCount") != null && !"".equals(request.getParameter("rtsTestExectuionSummaryRowCount")) && request.getParameter("rtsTestExectuionSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("rtsTestExectuionSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							rtsTestExecutionSummaryBean = new RtsTestExecutionSummaryBean();
							rtsTestExecutionSummaryBean.setSmtDirect((request.getParameter("rtsTesSmtDirect"+i) == null ) ? "NA" : request.getParameter("rtsTesSmtDirect"+i));
							rtsTestExecutionSummaryBean.setRag((request.getParameter("rtsTesRag"+i) == null ) ? "NA" : request.getParameter("rtsTesRag"+i));
							rtsTestExecutionSummaryBean.setTotal((request.getParameter("rtsTesTotal"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesTotal"+i)));
							rtsTestExecutionSummaryBean.setInProgress((request.getParameter("rtsTesInProgress"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesInProgress"+i)));
							rtsTestExecutionSummaryBean.setOnHold((request.getParameter("rtsTesOnHold"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesOnHold"+i)));
							rtsTestExecutionSummaryBean.setCompleted((request.getParameter("rtsTesCompleted"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesCompleted"+i)));						
							rtsTestExecutionSummaryBean.setSeverity1((request.getParameter("rtsTesSev1"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev1"+i)));
							rtsTestExecutionSummaryBean.setSeverity2((request.getParameter("rtsTesSev2"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev2"+i)));
							rtsTestExecutionSummaryBean.setSeverity3((request.getParameter("rtsTesSev3"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev3"+i)));
							rtsTestExecutionSummaryBean.setSeverity4((request.getParameter("rtsTesSev4"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesSev4"+i)));
							rtsTestExecutionSummaryBean.setTotalSeverity((request.getParameter("rtsTesTotalSeverity"+i) == null ) ? 0 : Integer.parseInt(request.getParameter("rtsTesTotalSeverity"+i)));
													
							rtsTestExecutionSummaryBeansList.add(rtsTestExecutionSummaryBean);
						}
						dailyStatusReportBean.setRtsTestExecutionSummaryList(rtsTestExecutionSummaryBeansList);
					}
					modelAndView = new ModelAndView("agileInput");
					commonService.saveAgileDailStatusReport(dailyStatusReportBean);
					modelAndView.addObject("css", "success");
					modelAndView.addObject("msg", "Record inserted successfully!");
					
					logger.debug("updateDeleteAgileDsr Add as new record() - END");
				}
				else
				{
					List<AdmRaidLogBean> raidLogBeanList = new LinkedList<AdmRaidLogBean>();
					List<AdmTestExecutionSummaryBean> admTestExecutionSummaryBeansList = new LinkedList<AdmTestExecutionSummaryBean>();
					List<AdmTestDesignSummaryBean> admTestDesignSummaryBeansList = new LinkedList<AdmTestDesignSummaryBean>();
					List<RtsTestExecutionSummaryBean> rtsTestExecutionSummaryBeansList = new LinkedList<RtsTestExecutionSummaryBean>();
					List<RtsTestDesignSummaryBean> rtsTestDesignSummaryBeansList = new LinkedList<RtsTestDesignSummaryBean>();
					
					AdmRaidLogBean admRaidLogBean = null;
					AdmTestDesignSummaryBean admTestDesignSummaryBean = null;
					AdmTestExecutionSummaryBean admTestExecutionSummaryBean = null;
					RtsTestDesignSummaryBean rtsTestDesignSummaryBean = null;
					RtsTestExecutionSummaryBean rtsTestExecutionSummaryBean = null;
					
					if(request.getParameter("rowCount") != null && !"".equals(request.getParameter("rowCount")) && request.getParameter("rowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("rowCount"));
						System.out.println("Row Count Value "+rowCount);
						logger.debug("Row Count Value "+rowCount);
						for(int i = 1; i <= rowCount; i++)
						{
							System.out.println("Type Value : "+request.getParameter("type"+i));
							logger.debug("Type Value : "+request.getParameter("type"+i));
							admRaidLogBean = new AdmRaidLogBean();
							logger.debug("RaidLog Id : "+request.getParameter("id"+i));
							System.out.println("RaidLog Id : "+request.getParameter("id"+i));
							if(request.getParameter("admRaidLogId"+i) != null && !request.getParameter("admRaidLogId"+i).equals("") && request.getParameter("admRaidLogId"+i).length() > 0)
							{
								admRaidLogBean.setId(Long.parseLong(request.getParameter("admRaidLogId"+i)));
							}
							admRaidLogBean.setType(request.getParameter("type"+i));
							admRaidLogBean.setScrum(request.getParameter("scrum"+i));
							admRaidLogBean.setScrumManager(request.getParameter("scrumManager"+i));
							admRaidLogBean.setImpactedApp(request.getParameter("impactedApp"+i));
							admRaidLogBean.setIssueOwner(request.getParameter("issueOwner"+i));
							admRaidLogBean.setPriority(request.getParameter("priority"+i));
							admRaidLogBean.setDescription(request.getParameter("description"+i));
							admRaidLogBean.setStatus(request.getParameter("status"+i));
							admRaidLogBean.setPortfolioManager(request.getParameter("portfolioManager"+i));
							admRaidLogBean.setRadiOwner(request.getParameter("radiOwner"+i));
							admRaidLogBean.setRag(request.getParameter("rag"+i));
							logger.debug("Logged Date : "+request.getParameter("dateLogged"+i));
							Date loggedDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("dateLogged"+i));
							admRaidLogBean.setDateLogged(loggedDate);
							Date targetClosureDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("targetClosureDate"+i));
							admRaidLogBean.setTargetClosureDate(targetClosureDate);
							admRaidLogBean.setAge(request.getParameter("age"+i));
							admRaidLogBean.setMileStoneImpacted(request.getParameter("mileStoneImpacted"+i));
							admRaidLogBean.setRaidBackToGreenPlan(request.getParameter("raidBackToGreenPlan"+i));
							raidLogBeanList.add(admRaidLogBean);
						}
						dailyStatusReportBean.setAdmRaidLogBeanList(raidLogBeanList);
					}
					//ADM TDS
					if(request.getParameter("admTestDesignSummaryRowCount") != null && !"".equals(request.getParameter("admTestDesignSummaryRowCount")) && request.getParameter("admTestDesignSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("admTestDesignSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							admTestDesignSummaryBean = new AdmTestDesignSummaryBean();
							if(request.getParameter("admTdsId"+i) != null && !request.getParameter("admTdsId"+i).equals("") && request.getParameter("admTdsId"+i).length() > 0)
							{
								admTestDesignSummaryBean.setId(Long.parseLong(request.getParameter("admTdsId"+i)));
							}
							
							admTestDesignSummaryBean.setSmtDirect((request.getParameter("admTdsSmtDirect"+i) == null ) ? "NA" : request.getParameter("admTdsSmtDirect"+i));
							admTestDesignSummaryBean.setRag((request.getParameter("admTdsRag"+i) == null ) ? "NA" : request.getParameter("admTdsRag"+i));
							admTestDesignSummaryBean.setTotal((request.getParameter("admTdsTotal"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsTotal"+i)));
							admTestDesignSummaryBean.setInProgress((request.getParameter("admTdsInProgress"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsInProgress"+i)));
							admTestDesignSummaryBean.setOnHold((request.getParameter("admTdsOnHold"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsOnHold"+i)));
							admTestDesignSummaryBean.setCompleted((request.getParameter("admTdsCompleted"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsCompleted"+i)));
							admTestDesignSummaryBean.setSeverity1((request.getParameter("admTdsSev1"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsSev1"+i)));
							admTestDesignSummaryBean.setSeverity2((request.getParameter("admTdsSev2"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsSev2"+i)));
							admTestDesignSummaryBean.setSeverity3((request.getParameter("admTdsSev3"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsSev3"+i)));
							admTestDesignSummaryBean.setSeverity4((request.getParameter("admTdsSev4"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsSev4"+i)));
							admTestDesignSummaryBean.setTotalSeverity((request.getParameter("admTdsTotalSeverity"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsTotalSeverity"+i)));
							admTestDesignSummaryBeansList.add(admTestDesignSummaryBean);
						}
						dailyStatusReportBean.setAdmTestDesignSummaryList(admTestDesignSummaryBeansList);
					}
					//ADM TES
					if(request.getParameter("admTestExectuionSummaryRowCount") != null && !"".equals(request.getParameter("admTestExectuionSummaryRowCount")) && request.getParameter("admTestExectuionSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("admTestExectuionSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							admTestExecutionSummaryBean = new AdmTestExecutionSummaryBean();
							if(request.getParameter("admTesId"+i) != null && !request.getParameter("admTesId"+i).equals("") && request.getParameter("admTesId"+i).length() > 0)
							{
								admTestExecutionSummaryBean.setId(Long.parseLong(request.getParameter("admTesId"+i)));
							}
							
							admTestExecutionSummaryBean.setSmtDirect((request.getParameter("admTesSmtDirect"+i) == null ) ? "NA" : request.getParameter("admTesSmtDirect"+i));
							admTestExecutionSummaryBean.setRag((request.getParameter("admTesRag"+i) == null ) ? "NA" : request.getParameter("admTesRag"+i));
							admTestExecutionSummaryBean.setTotal((request.getParameter("admTesTotal"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesTotal"+i)));
							admTestExecutionSummaryBean.setInProgress((request.getParameter("admTesInProgress"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesInProgress"+i)));
							admTestExecutionSummaryBean.setOnHold((request.getParameter("admTesOnHold"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesOnHold"+i)));
							admTestExecutionSummaryBean.setCompleted((request.getParameter("admTesCompleted"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesCompleted"+i)));
							admTestExecutionSummaryBean.setSeverity1((request.getParameter("admTesSev1"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesSev1"+i)));
							admTestExecutionSummaryBean.setSeverity2((request.getParameter("admTesSev2"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesSev2"+i)));
							admTestExecutionSummaryBean.setSeverity3((request.getParameter("admTesSev3"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesSev3"+i)));
							admTestExecutionSummaryBean.setSeverity4((request.getParameter("admTesSev4"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesSev4"+i)));
							admTestExecutionSummaryBean.setTotalSeverity((request.getParameter("admTesTotalSeverity"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesTotalSeverity"+i)));
							admTestExecutionSummaryBeansList.add(admTestExecutionSummaryBean);
						}
						dailyStatusReportBean.setAdmTestExecutionSummaryList(admTestExecutionSummaryBeansList);
					}
					
					//RTS TDS
					if(request.getParameter("rtsTestDesignSummaryRowCount") != null && !"".equals(request.getParameter("rtsTestDesignSummaryRowCount")) && request.getParameter("rtsTestDesignSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("rtsTestDesignSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							rtsTestDesignSummaryBean = new RtsTestDesignSummaryBean();
							if(request.getParameter("rtsTdsId"+i) != null && !request.getParameter("rtsTdsId"+i).equals("") && request.getParameter("rtsTdsId"+i).length() > 0)
							{
								rtsTestDesignSummaryBean.setId(Long.parseLong(request.getParameter("rtsTdsId"+i)));
							}
							
							rtsTestDesignSummaryBean.setSmtDirect((request.getParameter("admTdsSmtDirect"+i) == null ) ? "NA" : request.getParameter("admTdsSmtDirect"+i));
							rtsTestDesignSummaryBean.setRag((request.getParameter("admTdsRag"+i) == null ) ? "NA" : request.getParameter("admTdsRag"+i));
							rtsTestDesignSummaryBean.setTotal((request.getParameter("admTdsTotal"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsTotal"+i)));
							rtsTestDesignSummaryBean.setInProgress((request.getParameter("admTdsInProgress"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsInProgress"+i)));
							rtsTestDesignSummaryBean.setOnHold((request.getParameter("admTdsOnHold"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsOnHold"+i)));
							rtsTestDesignSummaryBean.setCompleted((request.getParameter("admTdsCompleted"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsCompleted"+i)));
							rtsTestDesignSummaryBean.setSeverity1((request.getParameter("admTdsSev1"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsSev1"+i)));
							rtsTestDesignSummaryBean.setSeverity2((request.getParameter("admTdsSev2"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsSev2"+i)));
							rtsTestDesignSummaryBean.setSeverity3((request.getParameter("admTdsSev3"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsSev3"+i)));
							rtsTestDesignSummaryBean.setSeverity4((request.getParameter("admTdsSev4"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsSev4"+i)));
							rtsTestDesignSummaryBean.setTotalSeverity((request.getParameter("admTdsTotalSeverity"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTdsTotalSeverity"+i)));
							rtsTestDesignSummaryBeansList.add(rtsTestDesignSummaryBean);
						}
						dailyStatusReportBean.setRtsTestDesignSummaryList(rtsTestDesignSummaryBeansList);
					}
					//RTS TES
					if(request.getParameter("rtsTestExectuionSummaryRowCount") != null && !"".equals(request.getParameter("rtsTestExectuionSummaryRowCount")) && request.getParameter("rtsTestExectuionSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("rtsTestExectuionSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							rtsTestExecutionSummaryBean = new RtsTestExecutionSummaryBean();
							if(request.getParameter("rtsTesId"+i) != null && !request.getParameter("rtsTesId"+i).equals("") && request.getParameter("rtsTesId"+i).length() > 0)
							{
								rtsTestExecutionSummaryBean.setId(Long.parseLong(request.getParameter("rtsTesId"+i)));
							}
							
							rtsTestExecutionSummaryBean.setSmtDirect((request.getParameter("admTesSmtDirect"+i) == null ) ? "NA" : request.getParameter("admTesSmtDirect"+i));
							rtsTestExecutionSummaryBean.setRag((request.getParameter("admTesRag"+i) == null ) ? "NA" : request.getParameter("admTesRag"+i));
							rtsTestExecutionSummaryBean.setTotal((request.getParameter("admTesTotal"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesTotal"+i)));
							rtsTestExecutionSummaryBean.setInProgress((request.getParameter("admTesInProgress"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesInProgress"+i)));
							rtsTestExecutionSummaryBean.setOnHold((request.getParameter("admTesOnHold"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesOnHold"+i)));
							rtsTestExecutionSummaryBean.setCompleted((request.getParameter("admTesCompleted"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesCompleted"+i)));
							rtsTestExecutionSummaryBean.setSeverity1((request.getParameter("admTesSev1"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesSev1"+i)));
							rtsTestExecutionSummaryBean.setSeverity2((request.getParameter("admTesSev2"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesSev2"+i)));
							rtsTestExecutionSummaryBean.setSeverity3((request.getParameter("admTesSev3"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesSev3"+i)));
							rtsTestExecutionSummaryBean.setSeverity4((request.getParameter("admTesSev4"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesSev4"+i)));
							rtsTestExecutionSummaryBean.setTotalSeverity((request.getParameter("admTesTotalSeverity"+i) == null ) ? 0 : Long.parseLong(request.getParameter("admTesTotalSeverity"+i)));
							rtsTestExecutionSummaryBeansList.add(rtsTestExecutionSummaryBean);
						}
						dailyStatusReportBean.setRtsTestExecutionSummaryList(rtsTestExecutionSummaryBeansList);
					}
					
					commonService.updateAgileDailyStatusReport(dailyStatusReportBean);
					modelAndView.addObject("css", "success");
					modelAndView.addObject("msg", "Record has been updated!");
				}
			
			} 
			catch (Exception e)
			{
				modelAndView.addObject("css", "fail");
				modelAndView.addObject("msg", "Duplicate Entry please insert uniqueu record!");
				e.printStackTrace();
			}
		}
		
		logger.debug("updateOrDeleteDailyStatusReport() - START");
		
		return modelAndView;
	}
	
	@RequestMapping(value = "/deleteAgileDailyStatusReport.html", method = RequestMethod.GET)
	public ModelAndView deleteAgileDailyStatusReport(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("deleteAgileDailyStatusReport() - START");
		logger.debug("Object Id : "+ request.getParameter("objectId"));
		String objectId = request.getParameter("objectId");
		Long longObjectId = Long.parseLong(objectId);
		commonService.deleteAgileDailySatuReport(longObjectId);
		ModelAndView modelAndView = new ModelAndView("updateDelete");
		modelAndView.addObject("css", "success");
		modelAndView.addObject("msg", "Record has been deleted!");
		logger.debug("deleteAgileDailyStatusReport() - END");
		return modelAndView;
	}
	
	/*@RequestMapping(value = "/deleteAgileRaidLogById.html", method = RequestMethod.GET)
	public String deleteAgileRaidLogById(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("deleteDailyStatusReport() - START");
		logger.debug("Object Id : "+ request.getParameter("objectId"));
		String raidLogIdStr = request.getParameter("raidLogId");
		Long raidLogId = Long.parseLong(raidLogIdStr);
		commonService.deleteRaidLogById(raidLogId);
		ModelAndView modelAndView = new ModelAndView("updateDelete");
//		modelAndView.addObject("css", "success");
//		modelAndView.addObject("msg", "Record has been deleted!");
		logger.debug("deleteDailyStatusReport() - END");
		return "redirect:loadUpdateDelete.html?searchDate="+searchDate+"&searchSdpId="+searchSdpId+"";
	}
	
	@RequestMapping(value = "/deleteAgileTestDesignSummaryById.html", method = RequestMethod.GET)
	public String deleteAgileTestDesignSummaryById(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("deleteDailyStatusReport() - START");
		String tdsIdStr = request.getParameter("tdsId");
		Long tdsId = Long.parseLong(tdsIdStr);
		commonService.deleteTestDesignSummaryById(tdsId);
		ModelAndView modelAndView = new ModelAndView("updateDelete");
//		modelAndView.addObject("css", "success");
//		modelAndView.addObject("msg", "Record has been deleted!");
		logger.debug("deleteDailyStatusReport() - END");
		return "redirect:loadUpdateDelete.html?searchDate="+searchDate+"&searchSdpId="+searchSdpId+"";
	}
	
	@RequestMapping(value = "/deleteAgileTestExecutionSummaryById.html", method = RequestMethod.GET)
	public String deleteAgileTestExecutionSummaryById(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		//loadUpdateDelete.html?searchDate=2018-05-07&searchSdpId=4444
		logger.debug("deleteDailyStatusReport() - START");
		String tedIdStr = request.getParameter("tedId");
		Long tedId = Long.parseLong(tedIdStr);
		commonService.deleteTestExecutionSummaryById(tedId);
		ModelAndView modelAndView = new ModelAndView("updateDelete");
//		modelAndView.addObject("css", "success");
//		modelAndView.addObject("msg", "Record has been deleted!");
		logger.debug("deleteDailyStatusReport() - END");
		return "redirect:loadUpdateDelete.html?searchDate="+searchDate+"&searchSdpId="+searchSdpId+"";
	}*/
	
}
