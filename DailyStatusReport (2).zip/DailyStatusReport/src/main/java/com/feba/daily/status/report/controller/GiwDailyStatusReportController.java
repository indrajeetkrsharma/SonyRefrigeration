package com.feba.daily.status.report.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.persistence.NoResultException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.feba.daily.status.report.bean.DailyStatusReportBean;
import com.feba.daily.status.report.bean.RaidLogBean;
import com.feba.daily.status.report.bean.TestDesignSummaryBean;
import com.feba.daily.status.report.bean.TestExecutionSummaryBean;
import com.feba.daily.status.report.persistance.GIWDailyStatusReport;
import com.feba.daily.status.report.persistance.GIWExecutionSummary;
import com.feba.daily.status.report.persistance.GiwTestDefectSummary;
import com.feba.daily.status.report.persistance.TestDefectSummary;
import com.feba.daily.status.report.service.CommonService;
import com.feba.daily.status.report.util.DailyStatusReportUtil;
import com.feba.daily.status.report.util.DropDownMenu;
import com.feba.daily.status.report.validator.InputValidator;


@Controller
public class GiwDailyStatusReportController 
{
	final static Logger logger = Logger.getLogger(GiwDailyStatusReportController.class);
		
	@Autowired
	CommonService commonService;
	
	@Autowired(required=true)
	InputValidator inputValidator;
	
	private boolean isFirstTimeSearch = false;
	
	private String searchDate;
	
	private String searchLob;
	
	public GiwDailyStatusReportController()
	{
		BasicConfigurator.configure();
	}
	
//	@InitBinder
//	protected void initBinder(WebDataBinder binder) {
//		binder.setValidator(inputValidator);
//	}
	
	
	@RequestMapping(value = "/loadGiwInputPage.html", method = RequestMethod.GET)
	public ModelAndView loadGiwInputPage(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean)
	{
		logger.debug("loadGiwInputPage() - START");
		DropDownMenu dropDownMenu = new DropDownMenu();
		ModelAndView modelAndView = new ModelAndView("giwInput");
		dailyStatusReportBean.setReportDate(new Date());
		String todayDate = DailyStatusReportUtil.getDateToStringDate(new Date(), "MM/dd/yyyy");
		modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
		modelAndView.addObject("todayDate", todayDate);
		logger.debug("loadGiwInputPage() - END");
		return modelAndView;
	}
	
	@RequestMapping(value = "/submitGiwInputData.html", method = RequestMethod.POST)
	public ModelAndView submitGiwInputData(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, 
			 Model model, final RedirectAttributes redirectAttributes, HttpServletRequest request)
	{
		logger.debug("submitGiwInputData() - START");
		ModelAndView modelAndView = null;
		if (false) 
		{
			DropDownMenu dropDownMenu = new DropDownMenu();
			modelAndView = new ModelAndView("giwInput");
			modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
		} 
		else 
		{
			try
			{
				List<RaidLogBean> raidLogBeanList = new LinkedList<RaidLogBean>();
				List<GIWExecutionSummary> testExecutionSummaryBeansList = new LinkedList<GIWExecutionSummary>();
				
				RaidLogBean raidLogBean = null;
				GIWExecutionSummary giwExecutionSummary = null;
				
				if(request.getParameter("rowCount") != null && !"".equals(request.getParameter("rowCount")) && request.getParameter("rowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("rowCount"));
					System.out.println("Row Count Value "+rowCount);
					logger.debug("Row Count Value "+rowCount);
					for(int i = 1; i <= rowCount; i++)
					{
						System.out.println("Type Value : "+request.getParameter("type"+i));
						logger.debug("Type Value : "+request.getParameter("type"+i));
						raidLogBean = new RaidLogBean();
						raidLogBean.setType(request.getParameter("type"+i));
						raidLogBean.setTrack(request.getParameter("raidLogTrack"+i));
						raidLogBean.setDescription(request.getParameter("raidLogDescription"+i));
						raidLogBean.setStatus(request.getParameter("releaseName"+i));
//						raidLogBean.setPortfolioManager(request.getParameter("portfolioManager"+i));
						raidLogBean.setRadiOwner(request.getParameter("radiOwner"+i));
						raidLogBean.setRag(request.getParameter("rag"+i));
						logger.debug("Logged Date : "+request.getParameter("dateLogged"+i));
						Date loggedDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("dateLogged"+i));
						raidLogBean.setDateLogged(loggedDate);
						Date targetClosureDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("targetClosureDate"+i));
						raidLogBean.setTargetClosureDate(targetClosureDate);
						raidLogBean.setAge(request.getParameter("age"+i));
						raidLogBean.setMileStoneImpacted(request.getParameter("mileStoneImpacted"+i));
						raidLogBean.setRaidBackToGreenPlan(request.getParameter("raidBackToGreenPlan"+i));
						raidLogBeanList.add(raidLogBean);
					}
					dailyStatusReportBean.setRaidLogBeanList(raidLogBeanList);
				}
				
				if(request.getParameter("giwExecutionSummaryRowCount") != null && !"".equals(request.getParameter("giwExecutionSummaryRowCount")) && request.getParameter("giwExecutionSummaryRowCount").length() > 0)
				{
					int rowCount = Integer.parseInt(request.getParameter("giwExecutionSummaryRowCount"));
					for(int i = 1; i <= rowCount; i++)
					{
						giwExecutionSummary = new GIWExecutionSummary();
						giwExecutionSummary.setTrack(request.getParameter("track"+i));
						giwExecutionSummary.setProjectId(request.getParameter("projectId"+i));
						giwExecutionSummary.setSnTicket(request.getParameter("snTicket"+i));
						giwExecutionSummary.setSdpReq(request.getParameter("sdpReqCol"+i));
						giwExecutionSummary.setDescription(request.getParameter("description"+i));
						Date goLiveDate1 = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("goLiveDateOfExecSmry"+i));
						giwExecutionSummary.setGoLiveDate(goLiveDate1);
						Date reqReceiveOn = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("reqReceiveOn"+i));
						giwExecutionSummary.setReqReceiveOn(reqReceiveOn);
						Date entativeStartDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("tentativeStartDate"+i));
						giwExecutionSummary.setTentativeStartDate(entativeStartDate);
						Date entativeEndDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("tentativeEndDate"+i));
						giwExecutionSummary.setTentativeEndDate(entativeEndDate);
						giwExecutionSummary.setDeploymentBy(request.getParameter("deploymentBy"+i));
						giwExecutionSummary.setRagStatus(request.getParameter("ragStatus"+i));
						giwExecutionSummary.setStatus(request.getParameter("status"+i));
						giwExecutionSummary.setCompletion(request.getParameter("completion"+i));
						giwExecutionSummary.setComments(request.getParameter("comments"+i));
						giwExecutionSummary.setBackToGreenPlan(request.getParameter("backToGreenPlan"+i));
						giwExecutionSummary.setOwner(request.getParameter("owner"+i));
						testExecutionSummaryBeansList.add(giwExecutionSummary);
					}
					dailyStatusReportBean.setGiwExecutionSummayList(testExecutionSummaryBeansList);
				}
				modelAndView = new ModelAndView("giwInput");
				commonService.saveGiwInputDetails(dailyStatusReportBean);
				modelAndView.addObject("css", "success");
				modelAndView.addObject("msg", "Record inserted successfully!");
				
			} catch (Exception e)
			{
				logger.error("Error Occured during saving data : ", e);
				modelAndView = new ModelAndView("input");
				modelAndView.addObject("css", "success");
				modelAndView.addObject("msg", "Duplicate Entry please insert uniqueu record!");
			}
			
		}
		logger.debug("submitGiwInputData() - END");
		return modelAndView;
	}
	
	@RequestMapping(value = "/loadGiwUpdateDeleteForm.html", method = RequestMethod.GET)
	public ModelAndView loadGiwUpdateDeleteForm(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("loadGiwUpdateDeleteForm() - START");
		ModelAndView modelAndView = new ModelAndView("giwUpdateDelete");
		try
		{
			String dateIn = request.getParameter("searchDate");
			String searchByLOB = request.getParameter("searchByLOB");
			Date searchDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", dateIn);
			this.searchDate = dateIn;
			this.searchLob = searchByLOB;
			
			List<GIWDailyStatusReport> dailyStatusReportNFTs;
			dailyStatusReportNFTs =  commonService.searchGiwDailyStatusReport(searchDate, searchLob);
			GIWDailyStatusReport dailyStatusReportNFT = dailyStatusReportNFTs.get(0);
			BeanUtils.copyProperties(dailyStatusReportNFT, dailyStatusReportBean);
			
			System.out.println("loadGiwUpdateDeleteForm Object Id : "+ dailyStatusReportBean.getId());
			
			
			//======================================
			Set<GiwTestDefectSummary> testDefectSummarySet = dailyStatusReportNFT.getGiwtestDefectSummaries();
			Iterator<GiwTestDefectSummary> testDefectSummaryIterator = testDefectSummarySet.iterator();
			List<GiwTestDefectSummary> testDefectSummaryList = new ArrayList<GiwTestDefectSummary>();
			while(testDefectSummaryIterator.hasNext())
			{
				testDefectSummaryList.add(testDefectSummaryIterator.next());
			}
			for(GiwTestDefectSummary var : testDefectSummaryList)
			{
				if(var.getSeverity() == 1L)
				{
					dailyStatusReportBean.setFirstRowId(var.getId());
					dailyStatusReportBean.setFirstRowOpen(var.getOpne());
					dailyStatusReportBean.setFirstRowClosed(var.getClosed());
					dailyStatusReportBean.setFirstRowRejected(var.getRejected());
					dailyStatusReportBean.setFirstRowDefered(var.getDefered());
					dailyStatusReportBean.setFirstRowReOpned(var.getReOpened());
				}
				if(var.getSeverity() == 2L)
				{
					dailyStatusReportBean.setSecondRowId(var.getId());
					dailyStatusReportBean.setSecondRowOpen(var.getOpne());
					dailyStatusReportBean.setSecondRowClosed(var.getClosed());
					dailyStatusReportBean.setSecondRowRejected(var.getRejected());
					dailyStatusReportBean.setSecondRowDefered(var.getDefered());
					dailyStatusReportBean.setSecondRowReOpned(var.getReOpened());
				}
				if(var.getSeverity() == 3L)
				{
					dailyStatusReportBean.setThirdRowId(var.getId());
					dailyStatusReportBean.setThirdRowOpen(var.getOpne());
					dailyStatusReportBean.setThirdRowClosed(var.getClosed());
					dailyStatusReportBean.setThirdRowRejected(var.getRejected());
					dailyStatusReportBean.setThirdRowDefered(var.getDefered());
					dailyStatusReportBean.setThirdRowReOpned(var.getReOpened());
				}
				if(var.getSeverity() == 4L)
				{
					dailyStatusReportBean.setFourthRowId(var.getId());
					dailyStatusReportBean.setFourthRowOpen(var.getOpne());
					dailyStatusReportBean.setFourthRowClosed(var.getClosed());
					dailyStatusReportBean.setFourthRowRejected(var.getRejected());
					dailyStatusReportBean.setFourthRowDefered(var.getDefered());
					dailyStatusReportBean.setFourthRowReOpned(var.getReOpened());
				}
			}
			
			DropDownMenu dropDownMenu = new DropDownMenu();
			
			modelAndView.addObject("userForm", dailyStatusReportBean);
			modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
			modelAndView.addObject("raidLogStausDropDownList", dropDownMenu.raidLogStausDropDownList());
			logger.debug("RaidLog list size : "+dailyStatusReportNFT.getGiwRaidLogs().size());
			modelAndView.addObject("raidLogsList", dailyStatusReportNFT.getGiwRaidLogs());
			modelAndView.addObject("giwExecutionSummary", dailyStatusReportNFT.getGiwExecutionSummaries());
			
		} catch (NoResultException e)
		{
			modelAndView.addObject("userForm", dailyStatusReportBean);
			modelAndView.addObject("css", "success");
			modelAndView.addObject("msg", "No Record Found!");
		} catch (BeansException e)
		{
		}
		
		logger.debug("loadDailyStatusReportNFT() - END");
		return modelAndView;
	}
	
	@RequestMapping(value = "/updateGiwDailyStausReport.html", method = {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView updateGiwDailyStausReport(@ModelAttribute("userForm") @Validated DailyStatusReportBean dailyStatusReportBean, 
			BindingResult result, Model model, final RedirectAttributes redirectAttributes, HttpServletRequest request)
	{
		logger.debug("updateGiwDailyStausReport() - START");
		logger.debug("updateGiwDailyStausReport Object Id : "+ dailyStatusReportBean.getId());
		ModelAndView modelAndView = new ModelAndView("giwUpdateDelete");
		if (false) 
		{
			DropDownMenu dropDownMenu = new DropDownMenu();
			modelAndView.addObject("trackWiseStausDropDownList", dropDownMenu.trackWiseStausDropDownList());
			return modelAndView;
		} 
		else 
		{
			try
			{
				String addAsANewRecord = request.getParameter("addAsANewRecord");
				if("Yes".equals(addAsANewRecord))
				{
					List<RaidLogBean> raidLogBeanList = new LinkedList<RaidLogBean>();
					List<GIWExecutionSummary> testExecutionSummaryBeansList = new LinkedList<GIWExecutionSummary>();
					
					RaidLogBean raidLogBean = null;
					GIWExecutionSummary giwExecutionSummary = null;
					
					if(request.getParameter("rowCount") != null && !"".equals(request.getParameter("rowCount")) && request.getParameter("rowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("rowCount"));
						System.out.println("Row Count Value "+rowCount);
						logger.debug("Row Count Value "+rowCount);
						for(int i = 1; i <= rowCount; i++)
						{
							System.out.println("Type Value : "+request.getParameter("type"+i));
							logger.debug("Type Value : "+request.getParameter("type"+i));
							raidLogBean = new RaidLogBean();
							raidLogBean.setType(request.getParameter("type"+i));
							raidLogBean.setTrack(request.getParameter("raidLogTrack"+i));
							raidLogBean.setDescription(request.getParameter("raidLogDescription"+i));
							raidLogBean.setStatus(request.getParameter("releaseName"+i));
	//								raidLogBean.setPortfolioManager(request.getParameter("portfolioManager"+i));
							raidLogBean.setRadiOwner(request.getParameter("radiOwner"+i));
							raidLogBean.setRag(request.getParameter("rag"+i));
							logger.debug("Logged Date : "+request.getParameter("dateLogged"+i));
							Date loggedDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("dateLogged"+i));
							raidLogBean.setDateLogged(loggedDate);
							Date targetClosureDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("targetClosureDate"+i));
							raidLogBean.setTargetClosureDate(targetClosureDate);
							raidLogBean.setAge(request.getParameter("age"+i));
							raidLogBean.setMileStoneImpacted(request.getParameter("mileStoneImpacted"+i));
							raidLogBean.setRaidBackToGreenPlan(request.getParameter("raidBackToGreenPlan"+i));
							raidLogBeanList.add(raidLogBean);
						}
						dailyStatusReportBean.setRaidLogBeanList(raidLogBeanList);
					}
					
					if(request.getParameter("giwExecutionSummaryRowCount") != null && !"".equals(request.getParameter("giwExecutionSummaryRowCount")) && request.getParameter("giwExecutionSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("giwExecutionSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							giwExecutionSummary = new GIWExecutionSummary();
							giwExecutionSummary.setTrack(request.getParameter("track"+i));
							giwExecutionSummary.setProjectId(request.getParameter("projectId"+i));
							giwExecutionSummary.setSnTicket(request.getParameter("snTicket"+i));
							giwExecutionSummary.setSdpReq(request.getParameter("sdpReqCol"+i));
							giwExecutionSummary.setDescription(request.getParameter("description"+i));
							Date goLiveDate1 = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("goLiveDateOfExecSmry"+i));
							giwExecutionSummary.setGoLiveDate(goLiveDate1);
							Date reqReceiveOn = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("reqReceiveOn"+i));
							giwExecutionSummary.setReqReceiveOn(reqReceiveOn);
							Date entativeStartDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("tentativeStartDate"+i));
							giwExecutionSummary.setTentativeStartDate(entativeStartDate);
							Date entativeEndDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("tentativeEndDate"+i));
							giwExecutionSummary.setTentativeEndDate(entativeEndDate);
							giwExecutionSummary.setDeploymentBy(request.getParameter("deploymentBy"+i));
							giwExecutionSummary.setRagStatus(request.getParameter("ragStatus"+i));
							giwExecutionSummary.setStatus(request.getParameter("status"+i));
							giwExecutionSummary.setCompletion(request.getParameter("completion"+i));
							giwExecutionSummary.setComments(request.getParameter("comments"+i));
							giwExecutionSummary.setBackToGreenPlan(request.getParameter("backToGreenPlan"+i));
							giwExecutionSummary.setOwner(request.getParameter("owner"+i));
							testExecutionSummaryBeansList.add(giwExecutionSummary);
						}
						dailyStatusReportBean.setGiwExecutionSummayList(testExecutionSummaryBeansList);
					}
					modelAndView = new ModelAndView("giwInput");
					commonService.saveGiwInputDetails(dailyStatusReportBean);
					modelAndView.addObject("css", "success");
					modelAndView.addObject("msg", "Record inserted successfully!");
				}
				else
				{
					List<RaidLogBean> raidLogBeanList = new LinkedList<RaidLogBean>();
					List<GIWExecutionSummary> giwExecutionSummaries = new LinkedList<GIWExecutionSummary>();
					
					RaidLogBean raidLogBean = null;
					GIWExecutionSummary giwExecutionSummary = null;
					
					if(request.getParameter("rowCount") != null && !"".equals(request.getParameter("rowCount")) && request.getParameter("rowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("rowCount"));
						System.out.println("Row Count Value "+rowCount);
						logger.debug("Row Count Value "+rowCount);
						for(int i = 1; i <= rowCount; i++)
						{
							System.out.println("Type Value : "+request.getParameter("type"+i));
							logger.debug("Type Value : "+request.getParameter("type"+i));
							raidLogBean = new RaidLogBean();
							logger.debug("RaidLog Id : "+request.getParameter("id"+i));
							System.out.println("RaidLog Id : "+request.getParameter("id"+i));
							if(request.getParameter("id"+i) != null && !request.getParameter("id"+i).equals("") && request.getParameter("id"+i).length() > 0)
							{
								raidLogBean.setId(Long.parseLong(request.getParameter("id"+i)));
							}
							System.out.println("Type Value : "+request.getParameter("type"+i));
							logger.debug("Type Value : "+request.getParameter("type"+i));
							raidLogBean = new RaidLogBean();
							raidLogBean.setType(request.getParameter("type"+i));
							raidLogBean.setTrack(request.getParameter("raidLogTrack"+i));
							raidLogBean.setDescription(request.getParameter("raidLogDescription"+i));
							raidLogBean.setStatus(request.getParameter("status"+i));
							raidLogBean.setRadiOwner(request.getParameter("radiOwner"+i));
							raidLogBean.setRag(request.getParameter("rag"+i));
							logger.debug("Logged Date : "+request.getParameter("dateLogged"+i));
							Date loggedDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("dateLogged"+i));
							raidLogBean.setDateLogged(loggedDate);
							Date targetClosureDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("targetClosureDate"+i));
							raidLogBean.setTargetClosureDate(targetClosureDate);
							raidLogBean.setAge(request.getParameter("age"+i));
							raidLogBean.setMileStoneImpacted(request.getParameter("mileStoneImpacted"+i));
							raidLogBean.setRaidBackToGreenPlan(request.getParameter("raidBackToGreenPlan"+i));
							raidLogBeanList.add(raidLogBean);
						}
						dailyStatusReportBean.setRaidLogBeanList(raidLogBeanList);
					}
					
					if(request.getParameter("giwExecutionSummaryRowCount") != null && !"".equals(request.getParameter("giwExecutionSummaryRowCount")) && request.getParameter("giwExecutionSummaryRowCount").length() > 0)
					{
						int rowCount = Integer.parseInt(request.getParameter("giwExecutionSummaryRowCount"));
						for(int i = 1; i <= rowCount; i++)
						{
							giwExecutionSummary = new GIWExecutionSummary();
							if(request.getParameter("giwTestExecutionSummaryId"+i) != null && !request.getParameter("giwTestExecutionSummaryId"+i).equals("") && request.getParameter("giwTestExecutionSummaryId"+i).length() > 0)
							{
								giwExecutionSummary.setId(Long.parseLong(request.getParameter("giwTestExecutionSummaryId"+i)));
							}
							giwExecutionSummary.setTrack(request.getParameter("track"+i));
							giwExecutionSummary.setProjectId(request.getParameter("projectId"+i));
							giwExecutionSummary.setSnTicket(request.getParameter("snTicket"+i));
							giwExecutionSummary.setSdpReq(request.getParameter("sdpReqCol"+i));
							giwExecutionSummary.setDescription(request.getParameter("description"+i));
							Date goLiveDate1 = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("goLiveDateOfExecSmry"+i));
							giwExecutionSummary.setGoLiveDate(goLiveDate1);
							Date reqReceiveOn = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("reqReceiveOn"+i));
							giwExecutionSummary.setReqReceiveOn(reqReceiveOn);
							Date entativeStartDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("tentativeStartDate"+i));
							giwExecutionSummary.setTentativeStartDate(entativeStartDate);
							Date entativeEndDate = DailyStatusReportUtil.getDateObject("yyyy-MM-dd", request.getParameter("tentativeEndDate"+i));
							giwExecutionSummary.setTentativeEndDate(entativeEndDate);
							giwExecutionSummary.setDeploymentBy(request.getParameter("deploymentBy"+i));
							giwExecutionSummary.setRagStatus(request.getParameter("ragStatus"+i));
							giwExecutionSummary.setStatus(request.getParameter("status"+i));
							giwExecutionSummary.setCompletion(request.getParameter("completion"+i));
							giwExecutionSummary.setComments(request.getParameter("comments"+i));
							giwExecutionSummary.setBackToGreenPlan(request.getParameter("backToGreenPlan"+i));
							giwExecutionSummary.setOwner(request.getParameter("owner"+i));
							giwExecutionSummaries.add(giwExecutionSummary);
						}
						dailyStatusReportBean.setGiwExecutionSummayList(giwExecutionSummaries);
					}
					commonService.updateGiwDailyStausReport(dailyStatusReportBean);
					modelAndView.addObject("css", "success");
					modelAndView.addObject("msg", "Record has been updated!");
				}
			
			} 
			catch (Exception e)
			{
				modelAndView.addObject("css", "fail");
				modelAndView.addObject("msg", "Duplicate Entry please insert uniqueu record!");
				e.printStackTrace();
			}
		}
		
		logger.debug("updateGiwDailyStausReport() - START");
		
		return modelAndView;
	}
	
	@RequestMapping(value = "/deleteGiwDailyStatusReport.html", method = RequestMethod.GET)
	public ModelAndView deleteGiwDailyStatusReport(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("deleteGiwDailyStatusReport() - START");
		logger.debug("Object Id : "+ request.getParameter("objectId"));
		String objectId = request.getParameter("objectId");
		Long longObjectId = Long.parseLong(objectId);
		commonService.deleteGiwDailyStatusReport(longObjectId);
		ModelAndView modelAndView = new ModelAndView("updateDelete");
		modelAndView.addObject("css", "success");
		modelAndView.addObject("msg", "Record has been deleted!");
		logger.debug("deleteGiwDailyStatusReport() - END");
		return modelAndView;
	}
	
	@RequestMapping(value = "/deleteGiwTestExecutionSummaryById.html", method = RequestMethod.GET)
	public String deleteGiwTestExecutionSummaryById(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("deleteGiwTestExecutionSummaryById() - START");
		String tedIdStr = request.getParameter("giwTestExecutionSummaryId");
		Long tedId = Long.parseLong(tedIdStr);
		commonService.deleteGiwTestExecutionSummaryById(tedId);
		ModelAndView modelAndView = new ModelAndView("giwUpdateDelete");
		logger.debug("deleteGiwTestExecutionSummaryById() - END");
		return "redirect:loadGiwUpdateDeleteForm.html?searchDate="+searchDate+"&searchByLOB="+searchLob+"";
	}
	
	@RequestMapping(value = "/deleteGiwRaidLogById.html", method = RequestMethod.GET)
	public String deleteGiwRaidLogById(@ModelAttribute("userForm") DailyStatusReportBean dailyStatusReportBean, HttpServletRequest request)
	{
		logger.debug("deleteGiwRaidLogById() - START");
		logger.debug("Object Id : "+ request.getParameter("objectId"));
		String raidLogIdStr = request.getParameter("raidLogId");
		Long raidLogId = Long.parseLong(raidLogIdStr);
		commonService.deleteGiwRaidLogById(raidLogId);
		ModelAndView modelAndView = new ModelAndView("updateDelete");
		logger.debug("deleteGiwRaidLogById() - END");
		return "redirect:loadGiwUpdateDeleteForm.html?searchDate="+searchDate+"&searchByLOB="+searchLob+"";
	}
	
}
